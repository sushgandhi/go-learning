# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project setup with directory structure
- Created documentation files (UNDERSTANDING.md, REQUIREMENTS.md, PLAN.md, IMPLEMENTATION.md)
- Added project architecture documentation in ARCHITECTURE.md
- Included sample implementation in sample.py
- Implemented Data Management Layer with DataFrameManager and StateManager
- Created utils for error handling and data formatting
- Implemented initial set of tools (load_data, filter_data, summarize_*)
- Created Agent Core with LLM integration (Gemini API)
- Defined tool schemas for LLM function calling
- Implemented API Layer with FastAPI endpoints for file upload, chat, and status
- Created Pydantic models for API requests and responses

### Changed
- N/A

### Deprecated
- N/A

### Removed
- N/A

### Fixed
- N/A

### Security
- N/A 