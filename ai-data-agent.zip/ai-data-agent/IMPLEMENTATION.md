# Implementation Details

## Project Structure
```
ai-data-agent/
├── app/                       # Main application code
│   ├── api/                   # API Layer
│   │   ├── __init__.py
│   │   ├── main.py            # FastAPI application
│   │   ├── routes/
│   │   │   ├── __init__.py
│   │   │   ├── chat.py        # Chat endpoint
│   │   │   ├── files.py       # File upload endpoint
│   │   │   └── status.py      # Status checking endpoint
│   │   └── models/            # Pydantic models for API
│   │       ├── __init__.py
│   │       ├── requests.py
│   │       └── responses.py
│   ├── agent/                 # Agent Core
│   │   ├── __init__.py
│   │   ├── llm_connector.py   # LLM API connection
│   │   ├── orchestrator.py    # Tool execution orchestrator
│   │   └── tool_schemas.py    # Tool definitions for LLM
│   ├── data/                  # Data Management Layer
│   │   ├── __init__.py
│   │   ├── dataframe_manager.py
│   │   └── state_manager.py
│   ├── tools/                 # Tooling Layer
│   │   ├── __init__.py
│   │   ├── data_loading.py
│   │   ├── filtering.py
│   │   ├── aggregation.py
│   │   ├── visualization.py
│   │   ├── comparison.py
│   │   └── summarization.py
│   └── utils/
│       ├── __init__.py
│       ├── exceptions.py
│       └── helpers.py
├── storage/                   # Storage for uploads and generated plots
│   ├── uploads/
│   └── plots/
├── tests/                     # Test suite
├── .env                       # Environment variables
├── requirements.txt           # Dependencies
├── Dockerfile                 # For containerization
├── docker-compose.yml
└── README.md
```

## Key Components

### Data Management Layer
**DataFrameManager**
```python
class DataFrameManager:
    """
    Manages DataFrames and their metadata.
    """
    def __init__(self):
        # Track active DataFrames with session IDs
        self.dataframes = {}
        # Track DataFrame histories for each session
        self.history = {}
        
    def load_file(self, file_path, session_id, sheet_name=None):
        """Load a CSV or Excel file into a DataFrame"""
        # Implementation details
        
    def get_dataframe(self, session_id, version='current'):
        """Get the current or a specific version of DataFrame"""
        # Implementation details
        
    def update_dataframe(self, session_id, new_df, operation_name):
        """Save a new version of DataFrame after an operation"""
        # Implementation details
```

**StateManager**
```python
class StateManager:
    """
    Manages conversation context and operational state.
    """
    def __init__(self):
        # Track conversation history by session
        self.conversations = {}
        # Track current file/DataFrame reference
        self.active_files = {}
        # Track user-defined aliases
        self.aliases = {}
        
    def add_message(self, session_id, role, content):
        """Add a message to the conversation history"""
        # Implementation details
        
    def get_conversation(self, session_id, last_n=None):
        """Get conversation history, optionally limited to last n messages"""
        # Implementation details
        
    def set_active_file(self, session_id, file_id):
        """Set the active file for a session"""
        # Implementation details
```

### Tooling Layer
Each tool follows a consistent structure:
- Input validation
- Core functionality 
- Error handling
- Result formatting

Example tool implementation:
```python
def filter_data(df, filter_criteria):
    """
    Filters a DataFrame based on multiple criteria.
    
    Args:
        df: The DataFrame to filter
        filter_criteria: List of criteria dicts with column, operator, value
        
    Returns:
        Filtered DataFrame and metadata
    """
    # Input validation
    if not isinstance(filter_criteria, list):
        raise ValueError("filter_criteria must be a list")
    
    # Core functionality
    filtered_df = df.copy()
    for criterion in filter_criteria:
        col = criterion.get('column')
        op = criterion.get('operator')
        val = criterion.get('value')
        
        # Validate criterion
        if not all([col, op, val is not None]):
            raise ValueError(f"Invalid filter criterion: {criterion}")
        
        # Apply filter based on operator
        # Implementation details for different operators
    
    # Result formatting
    result = {
        "filtered_df": filtered_df,
        "metadata": {
            "original_rows": len(df),
            "filtered_rows": len(filtered_df),
            "filter_criteria": filter_criteria
        }
    }
    
    return result
```

### Agent Core
**LLMConnector**
```python
class LLMConnector:
    """
    Handles communication with the LLM API.
    """
    def __init__(self, api_key, model_name="gemini-1.5-pro"):
        # Initialize LLM client
        
    def get_tool_response(self, user_message, conversation_history, available_tools):
        """
        Send a message to the LLM and get a tool calling response.
        """
        # Implementation details
```

**Orchestrator**
```python
class Orchestrator:
    """
    Coordinates tool execution based on LLM requests.
    """
    def __init__(self, df_manager, state_manager, llm_connector):
        self.df_manager = df_manager
        self.state_manager = state_manager
        self.llm = llm_connector
        # Register available tools
        self.tools = self._register_tools()
        
    def _register_tools(self):
        """Register all available tools"""
        # Implementation details
        
    def process_query(self, session_id, user_query):
        """
        Process a user query through the LLM and execute any tool calls.
        """
        # Get conversation history
        conversation = self.state_manager.get_conversation(session_id)
        
        # Get LLM response
        llm_response = self.llm.get_tool_response(
            user_query, 
            conversation, 
            self.tools
        )
        
        # Check if the LLM wants to call a tool
        if llm_response.has_tool_call:
            # Extract tool details
            tool_name = llm_response.tool_name
            tool_args = llm_response.tool_args
            
            # Check if tool exists
            if tool_name not in self.tools:
                # Handle unknown tool error
                pass
                
            # Execute the tool
            try:
                # Get the current DataFrame if needed
                current_df = None
                if tool_name != 'load_data':  # load_data doesn't need a DataFrame
                    current_df = self.df_manager.get_dataframe(session_id)
                
                # Call the tool with appropriate arguments
                if tool_name == 'load_data':
                    result = self.tools[tool_name](**tool_args)
                else:
                    result = self.tools[tool_name](df=current_df, **tool_args)
                
                # If the tool returns a new DataFrame, update it
                if 'result_df' in result:
                    self.df_manager.update_dataframe(
                        session_id, 
                        result['result_df'],
                        tool_name
                    )
                
                # Send the tool result back to the LLM
                final_response = self.llm.get_final_response(
                    tool_name,
                    result,
                    conversation
                )
                
                # Update conversation history
                self.state_manager.add_message(session_id, 'user', user_query)
                self.state_manager.add_message(session_id, 'assistant', final_response)
                
                return final_response
                
            except Exception as e:
                # Handle tool execution error
                # Report back to LLM
                pass
        else:
            # LLM responded directly without a tool call
            # Update conversation history and return the response
            pass
```

### API Layer
**FastAPI Application**
```python
# app/api/main.py
from fastapi import FastAPI, File, UploadFile, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from app.api.models.requests import ChatRequest
from app.api.models.responses import ChatResponse
# Other imports

app = FastAPI(title="AI Data Agent API")

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # For development; restrict in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(files_router, prefix="/files", tags=["files"])
app.include_router(chat_router, prefix="/chat", tags=["chat"])
app.include_router(status_router, prefix="/status", tags=["status"])
```

**File Upload Endpoint**
```python
# app/api/routes/files.py
@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    session_id: str = Query(None),
    orchestrator: Orchestrator = Depends(get_orchestrator)
):
    """
    Upload a CSV or Excel file for analysis.
    If no session_id is provided, a new one will be created.
    """
    # Implementation details
```

**Chat Endpoint**
```python
# app/api/routes/chat.py
@router.post("", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    orchestrator: Orchestrator = Depends(get_orchestrator)
):
    """
    Process a natural language query for a data analysis task.
    """
    try:
        response = orchestrator.process_query(
            request.session_id,
            request.message
        )
        
        return ChatResponse(
            response=response.text,
            data_table=response.data_table,
            plot_url=response.plot_url
        )
    except Exception as e:
        # Error handling
        raise HTTPException(status_code=500, detail=str(e))
```

## API Models
**Request Models**
```python
# app/api/models/requests.py
from pydantic import BaseModel, Field

class ChatRequest(BaseModel):
    """
    Model for chat requests.
    """
    session_id: str = Field(..., description="Session identifier")
    message: str = Field(..., description="User message")
```

**Response Models**
```python
# app/api/models/responses.py
from pydantic import BaseModel, Field
from typing import Optional

class ChatResponse(BaseModel):
    """
    Model for chat responses.
    """
    response: str = Field(..., description="Text response")
    data_table: Optional[str] = Field(None, description="Formatted data table (if applicable)")
    plot_url: Optional[str] = Field(None, description="URL to visualization (if applicable)")
``` 