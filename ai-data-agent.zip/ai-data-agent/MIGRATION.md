# Google Generative AI to Google GenAI Migration Guide

This document outlines the migration steps taken to update the AI Data Agent from the deprecated `google-generativeai` library to the new `google-genai` Python SDK.

## Background

Google has released a new Python SDK for its generative AI models, transitioning from `google-generativeai` to `google-genai`. The new SDK provides a simpler and more consistent interface for interacting with Gemini models, including better support for function calling.

## Changes Made

1. **Updated Dependencies**:
   - Changed from `google-generativeai==0.3.1` to `google-genai>=1.0.0` in `requirements.txt`

2. **Tool Schemas (`app/agent/tool_schemas.py`)**:
   - Replaced `genai.protos.FunctionDeclaration` with simple Python dictionaries
   - Updated schema formats to match the new JSON Schema format
   - Simplified the tool schema structure

3. **LLM Connector (`app/agent/llm_connector.py`)**:
   - Updated the client initialization from `genai.configure()` to `genai.Client()`
   - Changed chat session handling to use the new chat API
   - Updated the tool calling format to match the new API
   - Modified the function response handling

## Key API Changes

### Client Initialization
**Before**:
```python
import google.generativeai as genai
genai.configure(api_key=api_key)
model = genai.GenerativeModel(model_name, tools=tools)
```

**After**:
```python
from google import genai
client = genai.Client(api_key=api_key)
```

### Chat Sessions
**Before**:
```python
chat = model.start_chat()
response = chat.send_message(message)
```

**After**:
```python
chat = client.chats.create(model=model_name)
response = chat.send_message(message, tools=tools)
```

### Tool Schemas
**Before**:
```python
tool_schema = genai.protos.FunctionDeclaration(
    name='tool_name',
    description='Tool description',
    parameters=genai.protos.Schema(
        type=genai.protos.Schema.Type.OBJECT,
        properties={
            'param': genai.protos.Schema(
                type=genai.protos.Schema.Type.STRING,
                description='Parameter description'
            )
        }
    )
)
```

**After**:
```python
tool_schema = {
    "name": "tool_name",
    "description": "Tool description",
    "parameters": {
        "type": "object",
        "properties": {
            "param": {
                "type": "string",
                "description": "Parameter description"
            }
        }
    }
}
```

### Tool Responses
**Before**:
```python
response = chat.send_message(
    genai.protos.ToolFunctionResponse(
        name=tool_name,
        response=result
    )
)
```

**After**:
```python
response = chat.send_message(
    content={
        "tool_response": {
            "function_response": {
                "name": tool_name,
                "response": result
            }
        }
    }
)
```

## References

- [Google GenAI Python SDK](https://github.com/googleapis/python-genai)
- [Google GenAI API Reference](https://googleapis.github.io/python-genai/) 