# AI Data Agent

AI Data Agent is a system that allows users to interact with Excel/CSV data using natural language. The system leverages LLM capabilities to understand user requests and perform data operations like filtering, visualization, and analysis.

## Features

- **Natural Language Interface**: Interact with your data using conversational language
- **Data Operations**: Filter, group, pivot, and analyze your data
- **Visualization**: Create charts and graphs based on your data
- **Data Comparison**: Compare columns or files
- **Summarization**: Get insights at column, row, sheet, or workbook level

## Installation

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/ai-data-agent.git
   cd ai-data-agent
   ```

2. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Set up environment variables:
   ```bash
   cp .env.example .env
   ```
   Then edit the `.env` file and add your Gemini API key.

## Usage

1. Start the server:
   ```bash
   uvicorn app.api.main:app --reload
   ```

2. The API will be available at `http://localhost:8000`

3. You can interact with the API using:
   - The Swagger UI at `http://localhost:8000/docs`
   - The ReDoc UI at `http://localhost:8000/redoc`
   - Direct API calls to the endpoints

## API Endpoints

- **POST /files/upload**: Upload a CSV or Excel file
- **POST /chat**: Send a natural language query about your data
- **GET /status/{session_id}**: Check the status of processing
- **GET /data/{session_id}**: Retrieve the current state of processed data
- **GET /plot/{plot_id}**: Retrieve a generated visualization

## Development

### Project Structure
```
ai-data-agent/
├── app/                       # Main application code
│   ├── api/                   # API Layer
│   ├── agent/                 # Agent Core (LLM)
│   ├── data/                  # Data Management Layer
│   ├── tools/                 # Tooling Layer
│   └── utils/                 # Utilities
├── storage/                   # Storage for uploads and plots
├── tests/                     # Test suite
└── ...
```

### Running Tests
```bash
pytest
```

## License

[MIT](LICENSE)

## Acknowledgements

- Google's Gemini API for LLM capabilities
- FastAPI for the web framework
- Pandas for data manipulation 