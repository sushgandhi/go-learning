# Project Structure

This document describes the structure of the AI Data Agent project.

```
ai-data-agent/
├── app/                       # Main application code
│   ├── api/                   # API Layer
│   │   ├── __init__.py
│   │   ├── main.py            # FastAPI application
│   │   ├── routes/            # API routes
│   │   │   ├── __init__.py
│   │   │   ├── chat.py        # Chat endpoint
│   │   │   ├── files.py       # File upload endpoint
│   │   │   └── status.py      # Status checking endpoint
│   │   └── models/            # Pydantic models for API
│   │       ├── __init__.py
│   │       ├── requests.py    # Request models
│   │       └── responses.py   # Response models
│   ├── agent/                 # Agent Core
│   │   ├── __init__.py
│   │   ├── llm_connector.py   # LLM API connection (Gemini)
│   │   ├── orchestrator.py    # Tool execution orchestrator
│   │   └── tool_schemas.py    # Tool definitions for LLM
│   ├── data/                  # Data Management Layer
│   │   ├── __init__.py
│   │   ├── dataframe_manager.py  # Manages DataFrames
│   │   └── state_manager.py   # Manages conversation state
│   ├── tools/                 # Tooling Layer
│   │   ├── __init__.py
│   │   ├── data_loading.py    # Tools for loading data
│   │   ├── filtering.py       # Tools for filtering data
│   │   ├── summarization.py   # Tools for summarizing data
│   │   ├── aggregation.py     # Tools for aggregating data (to be implemented)
│   │   ├── visualization.py   # Tools for visualizing data (to be implemented)
│   │   └── comparison.py      # Tools for comparing data (to be implemented)
│   └── utils/                 # Utilities
│       ├── __init__.py
│       ├── exceptions.py      # Custom exceptions
│       └── helpers.py         # Helper functions
├── storage/                   # Storage for uploads and generated plots
│   ├── uploads/               # Uploaded data files
│   └── plots/                 # Generated visualizations
├── test_data/                 # Sample data for testing
│   └── sample.csv             # Sample CSV file
├── tests/                     # Test suite (to be implemented)
├── .env.example               # Example environment variables
├── requirements.txt           # Python dependencies
├── run.py                     # Script to run the application
├── README.md                  # Project overview and instructions
├── ARCHITECTURE.md            # Detailed architecture description
├── CHANGELOG.md               # Project changelog
├── IMPLEMENTATION.md          # Implementation details
├── PLAN.md                    # Development plan
├── REQUIREMENTS.md            # Project requirements
├── STRUCTURE.md               # This file
└── UNDERSTANDING.md           # Problem understanding
```

## Core Components

### API Layer
The API Layer provides external interfaces for uploading data files and processing natural language queries. It uses FastAPI for creating RESTful endpoints.

### Agent Core
The Agent Core is responsible for understanding user intent, selecting the appropriate tools, and orchestrating their execution. It uses the LLM (Gemini) to parse natural language queries.

### Data Management Layer
The Data Management Layer handles the storage, retrieval, and versioning of DataFrames and maintains the conversation state.

### Tooling Layer
The Tooling Layer contains specialized functions for data operations like loading, filtering, summarizing, aggregating, visualizing, and comparing data.

### Utils
The Utils module provides utility functions and custom exceptions used throughout the application. 