# Project Understanding: AI Data Agent

## Core Concept
The AI Data Agent is a system that acts as an intelligent assistant for data analysis tasks. It accepts Excel/CSV files as input and allows users to interact with their data through natural language conversations. The system uses a combination of LLM capabilities and specialized data processing tools to perform complex data operations without requiring users to know programming or data analysis techniques.

## Key Components
1. **User Interface/API Layer**: Handles file uploads and natural language interactions
2. **Agent Core (LLM)**: The intelligent component that understands user requests and orchestrates the appropriate tools
3. **Tooling Layer**: Collection of specialized functions for data operations (filtering, visualization, etc.)
4. **Data Management Layer**: Manages loaded DataFrames and their states
5. **State Management**: Tracks conversation context and data operation history

## User Flow
1. User uploads a CSV/Excel file
2. User interacts with the system using natural language queries
3. The LLM understands the intent and calls appropriate tools
4. The system executes the tools and returns results
5. The LLM formulates a natural language response based on the tool results

## External Dependencies
- **LLM API**: Initially using Google's Gemini API 
- **Data Processing**: Using Pandas for DataFrame manipulations
- **Visualization**: Using libraries like Matplotlib, Seaborn, or Plotly
- **API Framework**: Using FastAPI for exposing endpoints

## Key Features
- File upload and processing
- Natural language interaction
- Data filtering and grouping
- Data visualization
- Pivot table creation
- Column and file comparison
- Data summarization at various levels (column, row, sheet, workbook)

## Integration Capabilities
- REST API endpoints
- Potential integration with LangGraph or AutoGen for complex workflows 