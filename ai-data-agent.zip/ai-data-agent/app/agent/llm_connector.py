import os
from google import genai
from google.genai import types
from typing import List, Dict, Any, Optional, Union
from app.utils.exceptions import LLMError
from app.utils.logging import log_error, log_info


class LLMConnector:
    """
    Handles communication with the LLM API (Google's Gemini).
    """
    def __init__(self, api_key: Optional[str] = None, model_name: str = "gemini-2.0-flash"):
        """
        Initialize the LLM connector.
        
        Args:
            api_key: Gemini API key (if None, uses GEMINI_API_KEY environment variable)
            model_name: Model to use (e.g., "gemini-1.5-pro", "gemini-1.5-flash")
        """
        # Get API key from argument or environment
        self.api_key = api_key or os.getenv("GEMINI_API_KEY")
        if not self.api_key:
            raise LLMError("Gemini API key not provided or found in environment variables")
        
        self.model_name = model_name
        
        # Configure the Gemini API
        self.client = genai.Client(api_key=self.api_key)
        
        # Chat sessions will be initialized when needed
        self.chat_sessions = {}  # Track chat sessions by session_id
    
    def get_tool_response(self, 
                         session_id: str, 
                         user_message: str, 
                         conversation_history: List[Dict[str, Any]],
                         tools) -> Dict[str, Any]:
        """
        Send a message to the LLM and get a response that may include a tool call.
        
        Args:
            session_id: Session ID
            user_message: User message
            conversation_history: Previous conversation messages
            tools: Tool definitions for the model
            
        Returns:
            Dictionary with LLM response information
        """
        try:
            log_info(f"Processing message for session {session_id}", {"message": user_message})
            
            # Process the conversation history
            system_messages = []
            user_model_messages = []
            
            for message in conversation_history:
                role = message['role']
                content = message['content']
                
                if role == 'system':
                    # Collect system messages to combine later
                    system_messages.append(content)
                else:
                    # Add user and model messages as they are
                    chat_role = "user" if role == 'user' else "model"
                    user_model_messages.append({"role": chat_role, "parts": [{"text": content}]})
            
            # If there are system messages, add them as a special context message at the beginning
            history = []
            if system_messages:
                system_context = "\n".join(system_messages)
                
                # Make the system context more prominent
                formatted_context = f"""
=== IMPORTANT SYSTEM CONTEXT ===
{system_context}
=== END OF SYSTEM CONTEXT ===

Please use this context information for your response and all processing.
"""
                # Add as a system message for the chat
                history.append({"role": "user", "parts": [{"text": formatted_context}]})
                # Add model acknowledgment
                history.append({"role": "model", "parts": [{"text": "I'll use this context information for the conversation."}]})
            
            # Add the rest of the conversation
            history.extend(user_model_messages)
            
            # Create a new chat session for each request with the history
            chat = self.client.chats.create(
                model=self.model_name,
                history=history
            )
            
            # Store the chat session
            self.chat_sessions[session_id] = chat
            
            # Send the message with tool definitions
            # Create the proper config with tools using the Gemini API format
            
            config = types.GenerateContentConfig(tools=tools)
            
            log_info(f"Sending message to Gemini", {"config": str(config)[:500] + "..."})
            
            # Send the message with the config parameter
            try:
                response = chat.send_message(
                    user_message,
                    config=config
                )
            except Exception as api_error:
                # Check if the error is related to function_call vs text attribute
                error_msg = str(api_error)
                log_error("API error", api_error, {"error_message": error_msg})
                
                # Check if the error message contains function call info that we can extract
                if "function_call" in error_msg and "args=" in error_msg and "name=" in error_msg:
                    log_info("Found function call in error message, attempting to extract", {"error": error_msg})
                    
                    # Direct match for FunctionCall pattern seen in the error
                    if "function_call=FunctionCall" in error_msg:
                        try:
                            # Parse FunctionCall format: function_call=FunctionCall(id=None, args={'column': 'Sales'}, name='summarize_column')
                            fc_part = error_msg.split("function_call=FunctionCall")[1].strip()
                            
                            # Extract args
                            if "args={" in fc_part:
                                args_start = fc_part.find("args=") + 5
                                args_end = fc_part.find("}", args_start) + 1  # Include the closing brace
                                args_str = fc_part[args_start:args_end]
                                
                                # Use ast.literal_eval for safer evaluation of the dict string
                                import ast
                                extracted_args = ast.literal_eval(args_str)
                            else:
                                extracted_args = {}
                                
                            # Extract name
                            if "name='" in fc_part:
                                name_start = fc_part.find("name='") + 6
                                name_end = fc_part.find("'", name_start)
                                function_name = fc_part[name_start:name_end]
                            elif 'name="' in fc_part:
                                name_start = fc_part.find('name="') + 6
                                name_end = fc_part.find('"', name_start)
                                function_name = fc_part[name_start:name_end]
                            else:
                                function_name = None
                            
                            # If we successfully extracted both name and args, return them
                            if function_name and extracted_args is not None:
                                log_info("Successfully extracted function call from FunctionCall format", {
                                    "function_name": function_name,
                                    "args": extracted_args
                                })
                                
                                return {
                                    'has_tool_call': True,
                                    'tool_name': function_name,
                                    'tool_args': extracted_args,
                                    'raw_response': None
                                }
                        except Exception as e:
                            log_error("Error extracting from FunctionCall format", e, {"error_msg": error_msg})
                            # Continue to other extraction methods
                    
                    # Extract function name
                    name_start = error_msg.find("name='") + 6
                    name_end = error_msg.find("'", name_start)
                    function_name = error_msg[name_start:name_end].strip("'") if name_start > 5 and name_end > name_start else None
                    
                    # Extract args - these will be in a more complex format, but we can attempt to parse the key parts
                    args_str = error_msg.split("args=", 1)[1].split(", name=", 1)[0] if "args=" in error_msg else "{}"
                    
                    # Use a more targeted approach to extract keys from the args string
                    extracted_args = {}
                    
                    # Parse out group_by_cols if present
                    if "'group_by_cols': [" in args_str:
                        group_cols_start = args_str.find("'group_by_cols': [") + len("'group_by_cols': [")
                        group_cols_end = args_str.find("]", group_cols_start)
                        group_cols_str = args_str[group_cols_start:group_cols_end]
                        group_cols = [col.strip("'\" ") for col in group_cols_str.split(",")]
                        extracted_args["group_by_cols"] = group_cols
                    
                    # Parse out agg_definitions if present
                    if "'agg_definitions':" in args_str:
                        # This is more complex, but we can make a reasonable attempt
                        # For simplicity, we'll create a basic structure
                        extracted_args["agg_definitions"] = []
                        
                        # Look for column names in the agg_definitions section
                        if "'column': " in args_str:
                            col_start = args_str.find("'column': ") + len("'column': ")
                            col_end = args_str.find("'", col_start + 1)
                            col_name = args_str[col_start:col_end].strip("'")
                            
                            # Look for the function
                            func_name = "sum"  # Default
                            if "'function': " in args_str:
                                func_start = args_str.find("'function': ") + len("'function': ")
                                func_end = args_str.find("'", func_start + 1)
                                func_name = args_str[func_start:func_end].strip("'")
                            
                            # Look for new_column_name
                            new_name = f"{func_name.capitalize()} of {col_name}"  # Default
                            if "'new_column_name': " in args_str:
                                name_start = args_str.find("'new_column_name': ") + len("'new_column_name': ")
                                name_end = args_str.find("'", name_start + 1)
                                new_name = args_str[name_start:name_end].strip("'")
                            
                            # Add to agg_definitions
                            extracted_args["agg_definitions"].append({
                                "column": col_name,
                                "function": func_name,
                                "new_column_name": new_name
                            })
                    
                    if function_name and extracted_args:
                        log_info("Successfully extracted function call from error", {
                            "function_name": function_name,
                            "args": extracted_args
                        })
                        
                        return {
                            'has_tool_call': True,
                            'tool_name': function_name,
                            'tool_args': extracted_args,
                            'raw_response': None  # We don't have the full response object
                        }
                
                # If we couldn't extract a function call, re-raise the error
                raise api_error
            
            # Log the response structure for debugging
            response_debug = {}
            for attr in dir(response):
                if not attr.startswith('_') and not callable(getattr(response, attr)):
                    try:
                        value = getattr(response, attr)
                        if isinstance(value, (str, int, float, bool, list, dict)):
                            response_debug[attr] = value
                        else:
                            response_debug[attr] = str(type(value))
                    except Exception as e:
                        response_debug[attr] = f"Error: {str(e)}"
            
            log_info(f"Response structure", {"debug": str(response_debug)[:1000] + "..."})
            
            # Check if the response has function_call parts
            has_function_call = False
            tool_name = None
            tool_args = None
            
            # Check if response has candidates with content.parts[0].function_call (new SDK format)
            if hasattr(response, 'candidates') and response.candidates:
                candidate = response.candidates[0]
                if hasattr(candidate, 'content') and hasattr(candidate.content, 'parts') and candidate.content.parts:
                    part = candidate.content.parts[0]
                    if hasattr(part, 'function_call') and part.function_call:
                        has_function_call = True
                        tool_name = part.function_call.name
                        tool_args = part.function_call.args
                        log_info(f"Found function call in candidate.content.parts[0]", {
                            "tool_name": tool_name,
                            "tool_args": str(tool_args)
                        })
            
            # Check for direct function_call attribute (backup)
            if not has_function_call and hasattr(response, 'function_call') and response.function_call:
                has_function_call = True
                tool_name = response.function_call.name
                tool_args = response.function_call.args
            
            # Check for function_call in parts (backup)
            elif not has_function_call and hasattr(response, 'parts'):
                for part in response.parts:
                    if hasattr(part, 'function_call') and part.function_call:
                        has_function_call = True
                        tool_name = part.function_call.name
                        tool_args = part.function_call.args
                        break
            
            # If we found a function call, return it
            if has_function_call and tool_name and tool_args is not None:
                log_info(f"Got tool call response", {
                    "tool_name": tool_name,
                    "tool_args": str(tool_args)
                })
                
                return {
                    'has_tool_call': True,
                    'tool_name': tool_name,
                    'tool_args': tool_args,
                    'raw_response': response
                }
            
            # Safely get text response, handling possible attribute errors
            response_text = ""
            try:
                # Try direct text attribute first
                if hasattr(response, 'text'):
                    response_text = response.text
                # If that fails, look in parts
                elif hasattr(response, 'parts'):
                    for part in response.parts:
                        if hasattr(part, 'text') and part.text:
                            response_text += part.text
                # If still no text, look in candidates
                elif hasattr(response, 'candidates') and response.candidates:
                    for candidate in response.candidates:
                        if 'content' in candidate and 'parts' in candidate['content']:
                            for part in candidate['content']['parts']:
                                if 'text' in part:
                                    response_text += part['text']
            except AttributeError:
                # If we can't get text in the standard ways, create a default message
                response_text = "I'm sorry, I couldn't process your request in the expected way."
            
            # No tool call, just a regular response
            log_info(f"Got regular response", {"response_text": response_text[:100] + "..." if len(response_text) > 100 else response_text})
            return {
                'has_tool_call': False,
                'text': response_text,
                'raw_response': response
            }
        
        except Exception as e:
            log_error("Error getting response from Gemini", e, {
                "session_id": session_id,
                "user_message": user_message
            })
            raise LLMError(f"Error getting response from Gemini: {str(e)}")
    
    def get_final_response(self, 
                          session_id: str,
                          tool_name: str, 
                          tool_result: Dict[str, Any],
                          tools) -> str:
        """
        Send a tool result back to the LLM and get the final response.
        
        Args:
            session_id: Session ID
            tool_name: Name of the tool that was called
            tool_result: Result of the tool execution
            tools: Tool definitions for the model
            
        Returns:
            Final LLM response text
        """
        try:
            # Try to get the chat session - this should have the latest history
            chat = None
            if session_id in self.chat_sessions:
                chat = self.chat_sessions[session_id]
            
            # If no chat session exists, create a new one (shouldn't normally happen)
            if chat is None:
                log_info(f"Creating new chat session for tool response - unusual case", {
                    "session_id": session_id,
                    "tool_name": tool_name
                })
                chat = self.client.chats.create(model=self.model_name)
                self.chat_sessions[session_id] = chat
            
            # Extract relevant parts of the tool result
            result_content = {
                "success": True,
                "message": tool_result.get("message", ""),
                "metadata": tool_result.get("metadata", {})
            }
            
            # Add data table info if present
            if "result_df" in tool_result:
                df = tool_result["result_df"]
                result_content["rows"] = len(df)
                result_content["columns"] = len(df.columns)
                
                # Include a preview if the DataFrame is not too large
                if len(df) <= 10 and len(df.columns) <= 10:
                    result_content["preview"] = df.to_dict(orient="records")
            
            # Add plot URL if present
            if "plot_url" in tool_result:
                result_content["plot_url"] = tool_result["plot_url"]
            
            # Create the proper function response format for Gemini
            from google.genai import types
            function_response = types.FunctionResponse(
                name=tool_name,
                response=result_content
            )
            
            log_info(f"Sending tool result to Gemini", {
                "tool_name": tool_name,
                "result_summary": str(result_content)[:200] + "..."
            })
            
            # Send tool result back to the model using the format from the documentation
            try:
                response = chat.send_message(
                    function_response=function_response
                )
                
                # Safely get the text
                response_text = ""
                try:
                    response_text = response.text
                except AttributeError:
                    # If text isn't directly available, try to extract it from parts
                    if hasattr(response, 'parts'):
                        for part in response.parts:
                            if hasattr(part, 'text') and part.text:
                                response_text += part.text
                    elif hasattr(response, 'candidates') and response.candidates:
                        for candidate in response.candidates:
                            if 'content' in candidate and 'parts' in candidate['content']:
                                for part in candidate['content']['parts']:
                                    if 'text' in part:
                                        response_text += part['text']
                
                if not response_text:
                    # If we still couldn't extract text, provide a default
                    log_info("Couldn't extract text from response, using default", {"response": str(response)[:500]})
                    response_text = "I've processed your request and computed the results."
                
                log_info(f"Got final response", {"response_text": response_text[:100] + "..." if len(response_text) > 100 else response_text})
                
                return response_text
                
            except Exception as e:
                log_error("Error sending final response", e, {"tool_name": tool_name})
                # Provide a fallback response
                return f"I've processed your data using {tool_name}. Here are the results you requested."
        
        except Exception as e:
            log_error("Error getting final response from Gemini", e, {
                "session_id": session_id, 
                "tool_name": tool_name
            })
            raise LLMError(f"Error getting final response from Gemini: {str(e)}") 