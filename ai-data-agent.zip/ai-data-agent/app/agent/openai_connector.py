import os
import json
from typing import List, Dict, Any, Optional
from openai import OpenAI
from app.utils.exceptions import LLMError
from app.utils.logging import log_error, log_info


class OpenAIConnector:
    """
    Handles communication with the OpenAI API.
    """
    def __init__(self, api_key: Optional[str] = None, model_name: str = "gpt-3.5-turbo"):
        """
        Initialize the OpenAI connector.
        
        Args:
            api_key: OpenAI API key (if None, uses OPENAI_API_KEY environment variable)
            model_name: Model to use (e.g., "gpt-3.5-turbo", "gpt-4")
        """
        # Get API key from argument or environment
        self.api_key = api_key or os.getenv("OPENAI_API_KEY")
        if not self.api_key:
            raise LLMError("OpenAI API key not provided or found in environment variables")
        
        self.model_name = model_name
        
        # Initialize the OpenAI client
        self.client = OpenAI(api_key=self.api_key)
        
    def get_tool_response(self, 
                         session_id: str, 
                         user_message: str, 
                         conversation_history: List[Dict[str, Any]],
                         tools) -> Dict[str, Any]:
        """
        Send a message to OpenAI and get a response that may include a tool call.
        
        Args:
            session_id: Session ID
            user_message: User message
            conversation_history: Previous conversation messages
            tools: Tool definitions for the model
            
        Returns:
            Dictionary with LLM response information
        """
        try:
            log_info(f"Processing message with OpenAI for session {session_id}", {"message": user_message})
            
            # Convert conversation history to OpenAI format
            messages = []
            
            # Add a clear system message with tool selection guidelines
            tool_selection_guide = """You are a data analysis assistant that helps users analyze their data. 
Your job is to select the most appropriate tool based on the user's request.

IMPORTANT TOOL SELECTION GUIDELINES:
1. For calculating sums, totals, averages, or any aggregation of data, ALWAYS use 'group_and_aggregate', not 'summarize_column' or 'summarize_sheet'.
   - For global aggregations (e.g., "total sales"), use 'group_and_aggregate' with empty group_by_cols: []
   - For grouped aggregations (e.g., "sales by region"), use 'group_and_aggregate' with group_by_cols: ["region"]
2. For understanding data structure and general statistics, use 'summarize_sheet'.
3. For detailed analysis of a specific column, use 'summarize_column'.
4. For filtering data, use 'filter_data'.
5. For creating charts, use 'visualize_data'.
6. For comparing two columns, use 'compare_columns'.
7. For looking at pivot views of data, use 'create_pivot_table'.

EXAMPLES:
- "What is the sum of sales?" → Use 'group_and_aggregate' with empty group_by_cols: [] and agg_definitions: [{"column": "sales", "function": "sum", "new_column_name": "Total Sales"}]
- "Show me total revenue by region" → Use 'group_and_aggregate' with group_by_cols: ["region"], agg_definitions: [{"column": "revenue", "function": "sum", "new_column_name": "Total Revenue"}]
- "Average price by category" → Use 'group_and_aggregate' with group_by_cols: ["category"], agg_definitions: [{"column": "price", "function": "mean", "new_column_name": "Average Price"}]
- "Tell me about the sales column" → Use 'summarize_column' with column: "sales"
- "What does my data look like?" → Use 'summarize_sheet'
- "Show me a histogram of ages" → Use 'visualize_data' with plot_type: "histogram", x: "age"
- "Compare price and rating" → Use 'compare_columns' with col1: "price", col2: "rating"

MOST IMPORTANT: Pay close attention to whether the user wants to calculate a value (sum, average, etc.) or just understand column statistics. For calculations, use group_and_aggregate."""
            
            # Add the system message first
            messages.append({"role": "system", "content": tool_selection_guide})
            
            # Process the conversation history
            for message in conversation_history:
                role = message['role']
                content = message['content']
                
                # Skip system messages as we've added our own
                if role == 'system':
                    continue
                
                # Map roles to OpenAI format
                if role == 'user':
                    openai_role = 'user'
                else:  # assistant or model
                    openai_role = 'assistant'
                
                messages.append({"role": openai_role, "content": content})
            
            # Add the current user message
            messages.append({"role": "user", "content": user_message})
            
            # Log the complete conversation
            log_info(f"Sending conversation to OpenAI", {
                "model": self.model_name,
                "message_count": len(messages),
                "system_prompt_length": len(messages[0]["content"]) if messages and messages[0]["role"] == "system" else 0,
                "last_user_message": user_message[:100] + "..." if len(user_message) > 100 else user_message
            })
            
            # Log a detailed version of the first few and last few messages 
            conversation_sample = []
            if len(messages) > 0:
                for i, msg in enumerate(messages[:2]):  # First 2 messages
                    conversation_sample.append({
                        "index": i,
                        "role": msg["role"],
                        "content_preview": msg["content"][:200] + "..." if len(msg["content"]) > 200 else msg["content"]
                    })
                
                if len(messages) > 4:  # Add ellipsis if there are many messages
                    conversation_sample.append({"index": "...", "role": "...", "content_preview": "..."})
                
                for i, msg in enumerate(messages[-2:]):  # Last 2 messages
                    conversation_sample.append({
                        "index": len(messages) - 2 + i,
                        "role": msg["role"],
                        "content_preview": msg["content"][:200] + "..." if len(msg["content"]) > 200 else msg["content"]
                    })
            
            log_info(f"Conversation sample", {"messages": conversation_sample})
            
            # Log the tools structure
            log_info(f"Tools structure", {
                "tools_count": len(tools),
                "tools_sample": str(tools[0])[:500] + "..." if tools and len(str(tools[0])) > 500 else str(tools[0]) if tools else "No tools"
            })
            
            # Send the request to OpenAI
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                tools=tools,
                tool_choice="auto"  # Let the model decide when to use tools
            )
            
            # Get the first response message
            response_message = response.choices[0].message
            
            # Check if there's a tool call in the response
            if response_message.tool_calls:
                tool_call = response_message.tool_calls[0]  # Get the first tool call
                tool_name = tool_call.function.name
                
                # Parse tool arguments from JSON string
                try:
                    tool_args = json.loads(tool_call.function.arguments)
                except json.JSONDecodeError:
                    # Fallback if the JSON is invalid
                    log_error("Invalid JSON in tool arguments", None, {
                        "arguments": tool_call.function.arguments
                    })
                    tool_args = {}
                
                log_info(f"Got tool call response from OpenAI", {
                    "tool_name": tool_name, 
                    "tool_args": str(tool_args)
                })
                
                return {
                    'has_tool_call': True,
                    'tool_name': tool_name,
                    'tool_args': tool_args,
                    'raw_response': response
                }
            else:
                # Regular text response
                response_text = response_message.content
                
                log_info(f"Got regular response from OpenAI", {
                    "response_text": response_text[:100] + "..." if len(response_text) > 100 else response_text
                })
                
                return {
                    'has_tool_call': False,
                    'text': response_text,
                    'raw_response': response
                }
                
        except Exception as e:
            log_error("Error getting response from OpenAI", e, {
                "session_id": session_id,
                "user_message": user_message
            })
            raise LLMError(f"Error getting response from OpenAI: {str(e)}")
    
    def get_final_response(self, 
                          session_id: str,
                          tool_name: str, 
                          tool_result: Dict[str, Any],
                          tools) -> Dict[str, Any]:
        """
        Send a tool result back to OpenAI and get the final response.
        
        Args:
            session_id: Session ID
            tool_name: Name of the tool that was called
            tool_result: Result of the tool execution
            tools: Tool definitions for the model
            
        Returns:
            Dict containing the final response information, including data_table if available
        """
        try:
            log_info(f"Processing tool result with OpenAI for session {session_id}", {
                "tool_name": tool_name,
                "result_summary": str(tool_result)[:200] + "..." if len(str(tool_result)) > 200 else str(tool_result)
            })
            
            # Extract relevant parts of the tool result
            result_content = {
                "success": True,
                "message": tool_result.get("message", ""),
                "metadata": tool_result.get("metadata", {})
            }
            
            # Add data table info if present
            if "result_df" in tool_result:
                df = tool_result["result_df"]
                result_content["rows"] = len(df)
                result_content["columns"] = len(df.columns)
                
                # Include a preview if the DataFrame is not too large
                if len(df) <= 10 and len(df.columns) <= 10:
                    result_content["preview"] = df.to_dict(orient="records")
            
            # Add data_table if present
            if "data_table" in tool_result:
                result_content["data_table"] = tool_result["data_table"]
            
            # Add plot URL if present
            if "plot_url" in tool_result:
                result_content["plot_url"] = tool_result["plot_url"]
            
            # Convert to JSON string for the function response
            result_json = json.dumps(result_content)
            
            # Generate a more helpful system prompt based on the tool
            system_prompt = "You are a helpful data analysis assistant. "
            
            if tool_name == 'summarize_sheet':
                system_prompt += "You're providing a summary of a data sheet. Include key statistics and insights."
            elif tool_name == 'summarize_column':
                system_prompt += "You're analyzing a specific column. Describe the distribution, statistics, and noteworthy patterns."
            elif tool_name == 'group_and_aggregate':
                system_prompt += "You're presenting grouped and aggregated data. Explain the grouping logic and highlight key findings."
            elif tool_name == 'visualize_data':
                system_prompt += "You're describing a visualization. Explain what the chart shows and any visible patterns or insights."
            
            # Create a more helpful user prompt based on the tool
            user_prompt = "I need you to interpret these analysis results and provide insights in a clear, concise way."
            
            # Log the tools structure
            log_info(f"Tools structure for final response", {
                "tools_count": len(tools),
                "tools_sample": str(tools[0]) if tools else "No tools"
            })
            
            # First we retrieve the conversation from the last API call
            # Note: In a real implementation, you would store the conversation history
            # Here we just create a simple continuation
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
                {"role": "assistant", "content": None, "tool_calls": [
                    {
                        "id": "call_123",
                        "type": "function",
                        "function": {
                            "name": tool_name,
                            "arguments": "{}"
                        }
                    }
                ]},
                {"role": "tool", "tool_call_id": "call_123", "content": result_json}
            ]
            
            # Send the request to OpenAI with the tool result
            response = self.client.chat.completions.create(
                model=self.model_name,
                messages=messages,
                tools=tools,
                tool_choice="auto"
            )
            
            # Get the response text
            response_text = response.choices[0].message.content or ""
            
            log_info(f"Got final response from OpenAI", {
                "response_text": response_text[:100] + "..." if len(response_text) > 100 else response_text
            })
            
            # If we got an empty or very short response, create a better one based on tool results
            if not response_text or len(response_text) < 20:
                log_info("Response too short, creating a better fallback response")
                fallback_response = self._create_fallback_response(tool_name, tool_result)
                # Return a dict with both text and data_table
                return {
                    'text': fallback_response,
                    'data_table': tool_result.get('data_table'),
                    'plot_url': tool_result.get('plot_url')
                }
            
            # Return a dict with both text and data_table
            return {
                'text': response_text,
                'data_table': tool_result.get('data_table'),
                'plot_url': tool_result.get('plot_url')
            }
                
        except Exception as e:
            log_error("Error getting final response from OpenAI", e, {
                "session_id": session_id,
                "tool_name": tool_name
            })
            # Create a better fallback response based on tool result
            fallback_response = self._create_fallback_response(tool_name, tool_result)
            # Return a dict with both text and data_table
            return {
                'text': fallback_response,
                'data_table': tool_result.get('data_table'),
                'plot_url': tool_result.get('plot_url')
            }
    
    def _create_fallback_response(self, tool_name: str, tool_result: Dict[str, Any]) -> str:
        """
        Create a fallback response based on tool results when the LLM doesn't provide a good response.
        
        Args:
            tool_name: Name of the tool that was called
            tool_result: Result of the tool execution
            
        Returns:
            A generated fallback response with actual data
        """
        if tool_name == "summarize_sheet":
            message = "Here's a summary of your data:\n\n"
            
            if "metadata" in tool_result:
                metadata = tool_result["metadata"]
                if "rows" in metadata and "columns" in metadata:
                    message += f"Your dataset has {metadata['rows']} rows and {metadata['columns']} columns. "
                
                if "numeric_columns" in metadata:
                    message += f"It contains {len(metadata['numeric_columns'])} numeric columns. "
                
                if "categorical_columns" in metadata:
                    message += f"It contains {len(metadata['categorical_columns'])} categorical columns. "
            
            if "message" in tool_result:
                message += "\n\n" + tool_result["message"]
                
            return message
            
        elif tool_name == "summarize_column":
            column = tool_result.get("column_name", "The column")
            message = f"Here's a summary of the '{column}' column:\n\n"
            
            if "numeric_stats" in tool_result:
                stats = tool_result["numeric_stats"]
                message += f"Mean: {stats.get('mean')}\n"
                message += f"Median: {stats.get('median')}\n"
                message += f"Min: {stats.get('min')}\n"
                message += f"Max: {stats.get('max')}\n"
            
            if "categorical_stats" in tool_result:
                message += "\nTop values:\n"
                for value, count in tool_result["categorical_stats"].get("top_values", {}).items():
                    message += f"- {value}: {count}\n"
            
            if "message" in tool_result:
                message += "\n" + tool_result["message"]
                
            return message
            
        elif tool_name == "group_and_aggregate":
            message = "Here are the aggregation results:\n\n"
            
            if "metadata" in tool_result:
                metadata = tool_result["metadata"]
                if "group_by_columns" in metadata:
                    message += f"Data grouped by: {', '.join(metadata['group_by_columns'])}\n"
                
                if "aggregation_definitions" in metadata:
                    message += "Aggregations performed:\n"
                    for agg in metadata["aggregation_definitions"]:
                        col = agg.get("column", "")
                        func = agg.get("function", "")
                        name = agg.get("new_column_name", f"{func} of {col}")
                        message += f"- {name} ({func} of {col})\n"
            
            if "message" in tool_result:
                message += "\n" + tool_result["message"]
            
            if "data_table" in tool_result:
                message += "\n\nResults:\n" + tool_result["data_table"]
                
            return message
            
        else:
            # Generic fallback for other tools
            message = f"I've processed your data using {tool_name}.\n\n"
            
            if "message" in tool_result:
                message += tool_result["message"]
            
            if "data_table" in tool_result:
                message += "\n\n" + tool_result["data_table"]
                
            return message 