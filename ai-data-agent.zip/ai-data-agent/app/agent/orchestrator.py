from typing import Dict, Any, Optional, List
import os
import importlib
import inspect

from app.data.dataframe_manager import DataFrameManager
from app.data.state_manager import StateManager
from app.agent.llm_connector import LLMConnector
from app.agent.openai_connector import OpenAIConnector
from app.agent.tool_schemas import get_tool_schemas
from app.agent.tool_schemas_openai import get_tool_schemas_openai
from app.utils.exceptions import (
    ToolExecutionError,
    DataframeNotFoundError,
    SessionNotFoundError,
    LLMError
)

from app.tools.data_loading import load_data
from app.tools.filtering import filter_data
from app.tools.summarization import (
    summarize_column,
    summarize_row,
    summarize_sheet,
    summarize_workbook
)
# Import the newly implemented tools
from app.tools.aggregation import group_and_aggregate, create_pivot_table
from app.tools.visualization import visualize_data
from app.tools.comparison import compare_columns, compare_files
from app.utils.helpers import format_data_table
from app.utils.logging import log_info, log_error


class Orchestrator:
    """
    Coordinates tool execution based on LLM requests.
    Acts as the bridge between the LLM and the tools.
    """
    def __init__(
        self,
        df_manager: Optional[DataFrameManager] = None,
        state_manager: Optional[StateManager] = None,
        llm_connector: Optional[Any] = None
    ):
        """
        Initialize the Orchestrator.
        
        Args:
            df_manager: DataFrameManager instance (will create if None)
            state_manager: StateManager instance (will create if None)
            llm_connector: LLMConnector or OpenAIConnector instance (will create if None)
        """
        # Initialize components or use provided ones
        self.df_manager = df_manager or DataFrameManager()
        self.state_manager = state_manager or StateManager()
        
        # Get API key from environment if not directly provided
        if llm_connector is None:
            # Default to Gemini if no connector provided
            api_key = os.getenv("GEMINI_API_KEY")
            llm_connector = LLMConnector(api_key=api_key)
        
        self.llm = llm_connector
        
        # Get tool schemas based on the type of connector
        if isinstance(self.llm, OpenAIConnector):
            self.tool_schemas = get_tool_schemas_openai()
            log_info("Using OpenAI tool schemas")
        else:
            self.tool_schemas = get_tool_schemas()
            log_info("Using Gemini tool schemas")
        
        # Register available tools
        self.tools = self._register_tools()
    
    def _register_tools(self) -> Dict[str, Any]:
        """
        Register all available tools.
        
        Returns:
            Dictionary mapping tool names to their functions
        """
        tool_registry = {
            # Data loading tools
            'load_data': load_data,
            
            # Filtering tools
            'filter_data': filter_data,
            
            # Summarization tools
            'summarize_column': summarize_column,
            'summarize_row': summarize_row,
            'summarize_sheet': summarize_sheet,
            'summarize_workbook': summarize_workbook,
            
            # Aggregation tools
            'group_and_aggregate': group_and_aggregate,
            'create_pivot_table': create_pivot_table,
            
            # Visualization tools
            'visualize_data': visualize_data,
            
            # Comparison tools
            'compare_columns': compare_columns,
            'compare_files': compare_files,
        }
        
        return tool_registry
    
    def process_query(self, session_id: str, user_query: str) -> Dict[str, Any]:
        """
        Process a user query through the LLM and execute any tool calls.
        
        Args:
            session_id: Session ID
            user_query: User message
            
        Returns:
            Dictionary with response information
        """
        # First, check if the session exists
        if not self._session_exists(session_id):
            # Create a new session
            session_id = self.df_manager.create_session()
        
        # Record the start of this operation
        self.state_manager.start_operation(
            session_id, 
            'process_query',
            {'query': user_query}
        )
        
        # Add detailed logs for troubleshooting
        log_info(f"Processing query started", {
            "session_id": session_id,
            "query": user_query,
            "llm_type": type(self.llm).__name__,
            "tool_schemas_count": len(self.tool_schemas) if isinstance(self.tool_schemas, list) else "unknown"
        })
        
        try:
            # Get conversation history
            conversation = self.state_manager.get_conversation(session_id)
            
            # Get active file information if available
            active_file_path = self.state_manager.get_active_file(session_id)
            active_file_context = ""
            
            if active_file_path:
                try:
                    # Try to get file metadata from the DataFrame manager
                    file_metadata = self.df_manager.get_file_metadata(session_id)
                    if file_metadata:
                        # Create context message about the active file
                        file_name = file_metadata.get('file_name', os.path.basename(active_file_path))
                        file_type = file_metadata.get('file_type', 'unknown')
                        sheet_name = file_metadata.get('sheet_name')
                        
                        # Get DataFrame info for more context
                        try:
                            df = self.df_manager.get_dataframe(session_id)
                            df_info = self.df_manager.get_dataframe_info(session_id)
                            
                            # Create a more detailed and explicit context message
                            active_file_context = f"System context information about the current data:\n"
                            active_file_context += f"- Current file: {file_name}\n"
                            active_file_context += f"- File type: {file_type}\n"
                            if sheet_name:
                                active_file_context += f"- Current sheet: {sheet_name}\n"
                            
                            active_file_context += f"- Number of rows: {df_info.get('rows', '?')}\n"
                            active_file_context += f"- Number of columns: {df_info.get('columns', '?')}\n"
                            
                            # Add column names and types explicitly
                            if 'column_names' in df_info and df_info['column_names']:
                                active_file_context += f"- Column names: {', '.join(df_info.get('column_names', []))}\n"
                                
                                # Add data types for better context
                                if 'dtypes' in df_info:
                                    active_file_context += "- Column data types:\n"
                                    for col, dtype in df_info['dtypes'].items():
                                        active_file_context += f"  * {col}: {dtype}\n"
                                
                                # Add sample data (first few rows) for better context
                                if len(df) > 0:
                                    active_file_context += "\nSample data (first 3 rows):\n"
                                    sample_rows = df.head(3)
                                    for i, row in sample_rows.iterrows():
                                        active_file_context += f"Row {i}: {dict(row)}\n"
                        except Exception as e:
                            # If there's an error getting DataFrame info, create a simpler message
                            active_file_context = f"Currently working with file: {file_name}"
                            if sheet_name:
                                active_file_context += f" (sheet: {sheet_name})"
                        
                        # Add context to the query
                        if active_file_context:
                            # Add a system message with the context
                            self.state_manager.add_message(session_id, 'system', active_file_context)
                except Exception as e:
                    # If there's any error getting file metadata, continue without context
                    pass
            
            # Get updated conversation with context
            conversation = self.state_manager.get_conversation(session_id)
            
            # Enhance the user query with context reminder if we have file information
            enhanced_user_query = user_query
            if active_file_path and file_metadata:
                file_name = file_metadata.get('file_name', os.path.basename(active_file_path))
                enhanced_user_query = f"Using the dataset in file '{file_name}': {user_query}"
            
            # Get LLM response
            try:
                log_info(f"Sending query to LLM", {
                    "session_id": session_id,
                    "enhanced_query": enhanced_user_query,
                    "llm_type": type(self.llm).__name__,
                    "conversation_length": len(conversation)
                })
                
                llm_response = self.llm.get_tool_response(
                    session_id=session_id,
                    user_message=enhanced_user_query,
                    conversation_history=conversation,
                    tools=self.tool_schemas
                )
                
                # Log the LLM response
                log_info(f"LLM response received", {
                    "has_tool_call": llm_response.get('has_tool_call', False),
                    "tool_name": llm_response.get('tool_name', 'N/A') if llm_response.get('has_tool_call', False) else 'N/A',
                    "response_type": "tool_call" if llm_response.get('has_tool_call', False) else "text"
                })
            except LLMError as llm_err:
                # Check if the error message contains function call information
                error_msg = str(llm_err)
                if "function_call" in error_msg and "args=" in error_msg and "name=" in error_msg:
                    # Try to extract the function call from the error message
                    try:
                        # Extract function name
                        name_start = error_msg.find("name='") + 6
                        name_end = error_msg.find("'", name_start)
                        function_name = error_msg[name_start:name_end] if name_start > 5 and name_end > name_start else None
                        
                        # Extract args - these will be in a more complex format, but we can attempt to parse them
                        args_str = ""
                        if "args={" in error_msg:
                            args_start = error_msg.find("args={") + 5
                            args_end = error_msg.find("}", args_start)
                            if args_end > args_start:
                                args_str = error_msg[args_start:args_end+1]
                        
                        # Extract specific arguments based on common patterns
                        extracted_args = {}
                        
                        # Extract group_by_cols
                        if "'group_by_cols': [" in error_msg:
                            cols_start = error_msg.find("'group_by_cols': [") + len("'group_by_cols': [")
                            cols_end = error_msg.find("]", cols_start)
                            cols_str = error_msg[cols_start:cols_end]
                            # Extract column names
                            cols = []
                            for col in cols_str.split(","):
                                # Extract the column name from quotes, handling nested quotes better
                                col = col.strip()
                                if (col.startswith("'") and col.endswith("'")) or (col.startswith('"') and col.endswith('"')):
                                    # Remove the outermost quotes
                                    cols.append(col[1:-1])
                                else:
                                    cols.append(col)
                            
                            extracted_args["group_by_cols"] = cols
                        
                        # Extract agg_definitions
                        if "'agg_definitions': [" in error_msg:
                            agg_start = error_msg.find("'agg_definitions': [") + len("'agg_definitions': [")
                            agg_end = error_msg.find("]", agg_start)
                            agg_str = error_msg[agg_start:agg_end]
                            
                            # Parse the agg_definitions
                            agg_defs = []
                            
                            # Handle multiple agg definitions by finding dictionary patterns
                            current_pos = 0
                            while current_pos < len(agg_str):
                                dict_start = agg_str.find("{", current_pos)
                                if dict_start == -1:
                                    break
                                
                                dict_end = agg_str.find("}", dict_start)
                                if dict_end == -1:
                                    break
                                
                                agg_dict_str = agg_str[dict_start:dict_end+1]
                                current_pos = dict_end + 1
                                
                                # Extract individual fields from this dictionary
                                new_col_name = None
                                func = None
                                col = None
                                
                                # Extract new_column_name
                                if "'new_column_name':" in agg_dict_str:
                                    name_start = agg_dict_str.find("'new_column_name': ") + len("'new_column_name': ")
                                    
                                    # Handle both single and double quotes
                                    if agg_dict_str[name_start] == "'":
                                        name_start += 1
                                        name_end = agg_dict_str.find("'", name_start)
                                    elif agg_dict_str[name_start] == '"':
                                        name_start += 1
                                        name_end = agg_dict_str.find('"', name_start)
                                    else:
                                        # Not quoted, find end by comma or closing brace
                                        name_end = min(
                                            agg_dict_str.find(",", name_start) if agg_dict_str.find(",", name_start) != -1 else float('inf'),
                                            agg_dict_str.find("}", name_start) if agg_dict_str.find("}", name_start) != -1 else float('inf')
                                        )
                                    
                                    if name_end > name_start:
                                        new_col_name = agg_dict_str[name_start:name_end]
                                
                                # Extract function
                                if "'function':" in agg_dict_str:
                                    func_start = agg_dict_str.find("'function': ") + len("'function': ")
                                    
                                    # Handle both single and double quotes
                                    if agg_dict_str[func_start] == "'":
                                        func_start += 1
                                        func_end = agg_dict_str.find("'", func_start)
                                    elif agg_dict_str[func_start] == '"':
                                        func_start += 1
                                        func_end = agg_dict_str.find('"', func_start)
                                    else:
                                        # Not quoted, find end by comma or closing brace
                                        func_end = min(
                                            agg_dict_str.find(",", func_start) if agg_dict_str.find(",", func_start) != -1 else float('inf'),
                                            agg_dict_str.find("}", func_start) if agg_dict_str.find("}", func_start) != -1 else float('inf')
                                        )
                                    
                                    if func_end > func_start:
                                        func = agg_dict_str[func_start:func_end]
                                
                                # Extract column
                                if "'column':" in agg_dict_str:
                                    col_start = agg_dict_str.find("'column': ") + len("'column': ")
                                    
                                    # Handle both single and double quotes
                                    if agg_dict_str[col_start] == "'":
                                        col_start += 1
                                        col_end = agg_dict_str.find("'", col_start)
                                    elif agg_dict_str[col_start] == '"':
                                        col_start += 1
                                        col_end = agg_dict_str.find('"', col_start)
                                    else:
                                        # Not quoted, find end by comma or closing brace
                                        col_end = min(
                                            agg_dict_str.find(",", col_start) if agg_dict_str.find(",", col_start) != -1 else float('inf'),
                                            agg_dict_str.find("}", col_start) if agg_dict_str.find("}", col_start) != -1 else float('inf')
                                        )
                                    
                                    if col_end > col_start:
                                        col = agg_dict_str[col_start:col_end]
                                
                                # Only add if we have at least a column and function
                                if col and func:
                                    agg_def = {
                                        "column": col,
                                        "function": func
                                    }
                                    
                                    if new_col_name:
                                        agg_def["new_column_name"] = new_col_name
                                    else:
                                        agg_def["new_column_name"] = f"{func.capitalize()} of {col}"
                                    
                                    agg_defs.append(agg_def)
                            
                            if agg_defs:
                                extracted_args["agg_definitions"] = agg_defs
                        
                        if function_name and extracted_args:
                            # Log the successful extraction
                            print(f"Successfully extracted function call from error: {function_name} with args: {extracted_args}")
                            
                            # Set llm_response to simulate a valid tool call
                            llm_response = {
                                'has_tool_call': True,
                                'tool_name': function_name,
                                'tool_args': extracted_args,
                                'raw_response': None
                            }
                        else:
                            # If we couldn't extract a complete function call, re-raise the error
                            raise llm_err
                    except Exception:
                        # If something goes wrong in extraction, just re-raise the original error
                        raise llm_err
                else:
                    # No function call in the error, re-raise
                    raise llm_err
            
            # Add the original user query to conversation history (not the enhanced one)
            self.state_manager.add_message(session_id, 'user', user_query)
            
            # Check if the LLM wants to call a tool
            if llm_response.get('has_tool_call', False):
                # Extract tool details
                tool_name = llm_response['tool_name']
                tool_args = llm_response['tool_args']
                
                # Check if tool exists
                if tool_name not in self.tools:
                    raise ToolExecutionError(
                        tool_name,
                        f"Unknown tool: {tool_name}"
                    )
                
                # Execute the tool
                try:
                    # Get the current DataFrame if needed
                    current_df = None
                    if tool_name != 'load_data' and tool_name != 'compare_files':  # These tools don't need a DataFrame
                        try:
                            current_df = self.df_manager.get_dataframe(session_id)
                        except KeyError:
                            # No DataFrame loaded yet
                            raise DataframeNotFoundError(session_id)
                    
                    # Log the tool execution
                    log_info(f"Executing tool '{tool_name}'", {
                        "tool_args": tool_args,
                        "session_id": session_id,
                        "tool_name": tool_name
                    })
                    
                    # Call the tool with appropriate arguments
                    if tool_name == 'load_data':
                        # For load_data, pass args directly
                        result = self.tools[tool_name](**tool_args)
                        
                        # If load was successful, update the DataFrame manager
                        if 'result_df' in result:
                            self.df_manager.update_dataframe(
                                session_id,
                                result['result_df'],
                                'load_data',
                                {
                                    'file_path': tool_args.get('file_path'),
                                    'sheet_name': tool_args.get('sheet_name')
                                }
                            )
                    elif tool_name == 'compare_files':
                        # For compare_files, pass args directly as it doesn't require the current DataFrame
                        result = self.tools[tool_name](**tool_args)
                    else:
                        # For other tools, inject the DataFrame
                        result = self.tools[tool_name](df=current_df, **tool_args)
                    
                    # If the tool returns a new DataFrame (other than load_data), update it
                    if tool_name != 'load_data' and 'result_df' in result:
                        self.df_manager.update_dataframe(
                            session_id,
                            result['result_df'],
                            tool_name,
                            tool_args
                        )
                    
                    # Apply formatting to result DataFrame if present
                    if 'result_df' in result and result['result_df'] is not None and 'data_table' not in result:
                        # Format the DataFrame as a markdown table if not already formatted
                        result['data_table'] = format_data_table(result['result_df'], 'markdown')
                    
                    # Log the tool result
                    log_info(f"Tool '{tool_name}' execution completed", {
                        "result_keys": list(result.keys()),
                        "has_data_table": "data_table" in result and result["data_table"] is not None,
                        "has_result_df": "result_df" in result and result["result_df"] is not None,
                        "has_plot_url": "plot_url" in result and result["plot_url"] is not None,
                    })
                    
                    # Send the tool result back to the LLM for final response
                    final_response = self.llm.get_final_response(
                        session_id=session_id,
                        tool_name=tool_name,
                        tool_result=result,
                        tools=self.tool_schemas
                    )
                    
                    # Check if response is a dictionary (from OpenAI connector) or string (from Gemini)
                    final_response_text = ""
                    data_table = result.get('data_table')
                    plot_url = result.get('plot_url')
                    
                    if isinstance(final_response, dict):
                        # Extract text and data components from dictionary response
                        final_response_text = final_response.get('text', '')
                        # Use response data_table if provided, otherwise use the one from result
                        if 'data_table' in final_response:
                            data_table = final_response.get('data_table')
                        if 'plot_url' in final_response:
                            plot_url = final_response.get('plot_url')
                    else:
                        # If it's just a string, use that as the response text
                        final_response_text = final_response
                    
                    # Add the assistant response to conversation history
                    self.state_manager.add_message(session_id, 'assistant', final_response_text)
                    
                    # Mark operation as completed
                    self.state_manager.end_operation(
                        session_id,
                        'completed',
                        {
                            'tool_name': tool_name,
                            'response_length': len(final_response_text)
                        }
                    )
                    
                    # Return the final response
                    return {
                        'response': final_response_text,
                        'data_table': data_table,
                        'plot_url': plot_url
                    }
                    
                except Exception as e:
                    # Handle tool execution error
                    error_message = str(e)
                    
                    # Report error back to LLM
                    error_response = self.llm.get_final_response(
                        session_id=session_id,
                        tool_name=tool_name,
                        tool_result={
                            'success': False,
                            'message': f"Error executing tool: {error_message}"
                        },
                        tools=self.tool_schemas
                    )
                    
                    # Extract response text if it's a dictionary
                    if isinstance(error_response, dict):
                        error_response_text = error_response.get('text', '')
                    else:
                        error_response_text = error_response
                    
                    # Add the error response to conversation history
                    self.state_manager.add_message(session_id, 'assistant', error_response_text)
                    
                    # Mark operation as failed
                    self.state_manager.end_operation(
                        session_id,
                        'failed',
                        {
                            'tool_name': tool_name,
                            'error': error_message
                        }
                    )
                    
                    # Return the error response
                    return {
                        'response': error_response_text,
                        'error': error_message
                    }
            else:
                # LLM responded directly without a tool call
                direct_response = llm_response.get('text', '')
                
                # Add the direct response to conversation history
                self.state_manager.add_message(session_id, 'assistant', direct_response)
                
                # Mark operation as completed
                self.state_manager.end_operation(
                    session_id,
                    'completed',
                    {
                        'response_type': 'direct',
                        'response_length': len(direct_response)
                    }
                )
                
                # Return the direct response
                return {
                    'response': direct_response
                }
        
        except Exception as e:
            # Handle any other errors
            error_message = f"Error processing query: {str(e)}"
            
            # Mark operation as failed
            self.state_manager.end_operation(
                session_id,
                'failed',
                {
                    'error': error_message
                }
            )
            
            # Return the error
            return {
                'response': f"I'm sorry, I encountered an error: {error_message}",
                'error': error_message
            }
    
    def _session_exists(self, session_id: str) -> bool:
        """
        Check if a session exists.
        
        Args:
            session_id: Session ID to check
            
        Returns:
            True if the session exists, False otherwise
        """
        return session_id in self.df_manager.dataframes 