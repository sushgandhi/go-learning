from google import genai
from typing import List
from google.genai import types


def get_filter_data_schema():
    """Get the schema for the filter_data tool."""
    return {
        "name": "filter_data",
        "description": "Filters a pandas DataFrame based on multiple criteria.",
        "parameters": {
            "type": "object",
            "properties": {
                "filter_criteria": {
                    "type": "array",
                    "description": "A list of filter criteria dictionaries.",
                    "items": {
                        "type": "object",
                        "description": "A single filter criterion.",
                        "properties": {
                            "column": {
                                "type": "string",
                                "description": "The name of the column to filter."
                            },
                            "operator": {
                                "type": "string",
                                "description": "The comparison operator (==, >, <, >=, <=, !=)."
                            },
                            "value": {
                                "type": "string",
                                "description": "The value to compare against. Can be a string, number, or boolean."
                            }
                        },
                        "required": ["column", "operator", "value"]
                    }
                }
            },
            "required": ["filter_criteria"]
        }
    }


def get_load_data_schema():
    """Get the schema for the load_data tool."""
    return {
        "name": "load_data",
        "description": "Loads data from a CSV or Excel file into a pandas DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to load."
                },
                "sheet_name": {
                    "type": "string",
                    "description": "For Excel files, name of the sheet to load (default: first sheet)."
                }
            },
            "required": ["file_path"]
        }
    }


def get_summarize_column_schema():
    """Get the schema for the summarize_column tool."""
    return {
        "name": "summarize_column",
        "description": "Provides descriptive statistics and information about a single column in a DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {
                "column": {
                    "type": "string",
                    "description": "Name of the column to summarize."
                }
            },
            "required": ["column"]
        }
    }


def get_summarize_row_schema():
    """Get the schema for the summarize_row tool."""
    return {
        "name": "summarize_row",
        "description": "Provides information about a single row in a DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {
                "row_index": {
                    "type": "integer",
                    "description": "Index of the row to summarize (0-based)."
                }
            },
            "required": ["row_index"]
        }
    }


def get_summarize_sheet_schema():
    """Get the schema for the summarize_sheet tool."""
    return {
        "name": "summarize_sheet",
        "description": "Provides overall statistics and information about a DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {}  # No parameters needed, operates on the current DataFrame
        }
    }


def get_summarize_workbook_schema():
    """Get the schema for the summarize_workbook tool."""
    return {
        "name": "summarize_workbook",
        "description": "Provides summary information about all sheets in an Excel workbook.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the Excel file."
                }
            },
            "required": ["file_path"]
        }
    }


def get_group_and_aggregate_schema():
    """Get the schema for the group_and_aggregate tool."""
    return {
        "name": "group_and_aggregate",
        "description": "Groups a DataFrame by specified columns and performs aggregation operations. For global aggregations (like sum of all values), use an empty list for group_by_cols.",
        "parameters": {
            "type": "object",
            "properties": {
                "group_by_cols": {
                    "type": "array",
                    "description": "List of column names to group by. Use empty list [] for global aggregations across all rows.",
                    "items": {
                        "type": "string"
                    }
                },
                "agg_definitions": {
                    "type": "array",
                    "description": "List of aggregation definitions.",
                    "items": {
                        "type": "object",
                        "description": "A single aggregation definition.",
                        "properties": {
                            "column": {
                                "type": "string",
                                "description": "The name of the column to aggregate."
                            },
                            "function": {
                                "type": "string",
                                "description": "The aggregation function to apply (sum, mean, count, min, max, etc.)."
                            },
                            "new_column_name": {
                                "type": "string",
                                "description": "Optional name for the aggregated column."
                            }
                        },
                        "required": ["column", "function"]
                    }
                }
            },
            "required": ["group_by_cols", "agg_definitions"]
        }
    }


def get_create_pivot_table_schema():
    """Get the schema for the create_pivot_table tool."""
    return {
        "name": "create_pivot_table",
        "description": "Creates a pivot table from a DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {
                "index": {
                    "type": "array",
                    "description": "Column names to use as index (rows).",
                    "items": {
                        "type": "string"
                    }
                },
                "columns": {
                    "type": "array",
                    "description": "Column names to use for the table columns.",
                    "items": {
                        "type": "string"
                    }
                },
                "values": {
                    "type": "array",
                    "description": "Column names to use for the values shown in the table.",
                    "items": {
                        "type": "string"
                    }
                },
                "agg_func": {
                    "type": "string",
                    "description": "Aggregation function to apply (sum, mean, count, etc.)."
                }
            },
            "required": ["index", "values", "agg_func"]
        }
    }


def get_visualize_data_schema():
    """Get the schema for the visualize_data tool."""
    return {
        "name": "visualize_data",
        "description": "Generates a visualization of the data.",
        "parameters": {
            "type": "object",
            "properties": {
                "plot_type": {
                    "type": "string",
                    "description": "Type of plot to generate (bar, line, scatter, histogram, boxplot, pie, etc.)."
                },
                "x": {
                    "type": "string",
                    "description": "Column to use for the x-axis."
                },
                "y": {
                    "type": "string",
                    "description": "Column to use for the y-axis (not required for histogram, pie)."
                },
                "color": {
                    "type": "string",
                    "description": "Column to use for color differentiation (optional)."
                },
                "title": {
                    "type": "string",
                    "description": "Title for the plot (optional)."
                },
                "figsize": {
                    "type": "array",
                    "description": "Figure size as [width, height] in inches (optional).",
                    "items": {
                        "type": "number"
                    }
                },
                "bins": {
                    "type": "integer",
                    "description": "Number of bins for histogram (optional)."
                },
                "orientation": {
                    "type": "string",
                    "description": "Orientation of the plot (horizontal, vertical) (optional)."
                }
            },
            "required": ["plot_type", "x"]
        }
    }


def get_compare_columns_schema():
    """Get the schema for the compare_columns tool."""
    return {
        "name": "compare_columns",
        "description": "Compares two columns in a DataFrame.",
        "parameters": {
            "type": "object",
            "properties": {
                "col1": {
                    "type": "string",
                    "description": "Name of the first column to compare."
                },
                "col2": {
                    "type": "string",
                    "description": "Name of the second column to compare."
                },
                "comparison_type": {
                    "type": "string",
                    "description": "Type of comparison to perform (correlation, difference, distribution, value_comparison)."
                }
            },
            "required": ["col1", "col2", "comparison_type"]
        }
    }


def get_compare_files_schema():
    """Get the schema for the compare_files tool."""
    return {
        "name": "compare_files",
        "description": "Compares two DataFrames.",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path1": {
                    "type": "string",
                    "description": "Path to the first file."
                },
                "file_path2": {
                    "type": "string",
                    "description": "Path to the second file."
                },
                "comparison_type": {
                    "type": "string",
                    "description": "Type of comparison to perform (structure, common_rows, differences, summary_comparison)."
                }
            },
            "required": ["file_path1", "file_path2", "comparison_type"]
        }
    }


def get_tool_schemas() -> List:
    """
    Get all tool schemas for the LLM.
    
    Returns:
        List of tool function declarations using the Gemini SDK format
    """
    # Initialize tool declarations list
    function_declarations = []
    
    # Add all tool schemas
    function_declarations.append({
        "name": "filter_data",
        "description": get_filter_data_schema()['description'],
        "parameters": get_filter_data_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "load_data",
        "description": get_load_data_schema()['description'],
        "parameters": get_load_data_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "summarize_column",
        "description": get_summarize_column_schema()['description'],
        "parameters": get_summarize_column_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "summarize_row",
        "description": get_summarize_row_schema()['description'],
        "parameters": get_summarize_row_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "summarize_sheet",
        "description": get_summarize_sheet_schema()['description'],
        "parameters": get_summarize_sheet_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "summarize_workbook",
        "description": get_summarize_workbook_schema()['description'],
        "parameters": get_summarize_workbook_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "group_and_aggregate",
        "description": get_group_and_aggregate_schema()['description'],
        "parameters": get_group_and_aggregate_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "create_pivot_table",
        "description": get_create_pivot_table_schema()['description'],
        "parameters": get_create_pivot_table_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "visualize_data",
        "description": get_visualize_data_schema()['description'],
        "parameters": get_visualize_data_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "compare_columns",
        "description": get_compare_columns_schema()['description'],
        "parameters": get_compare_columns_schema()['parameters']
    })
    
    function_declarations.append({
        "name": "compare_files",
        "description": get_compare_files_schema()['description'],
        "parameters": get_compare_files_schema()['parameters']
    })
    
    # Create a Tool object with the function declarations
    tool = types.Tool(function_declarations=function_declarations)
    
    # Return as a list as required by Gemini API
    return [tool] 