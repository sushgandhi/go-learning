from typing import List

# Import the original schema functions
from app.agent.tool_schemas import (
    get_filter_data_schema,
    get_load_data_schema,
    get_summarize_column_schema,
    get_summarize_row_schema,
    get_summarize_sheet_schema,
    get_summarize_workbook_schema,
    get_group_and_aggregate_schema,
    get_create_pivot_table_schema,
    get_visualize_data_schema,
    get_compare_columns_schema,
    get_compare_files_schema
)

def get_tool_schemas_openai() -> List:
    """
    Get all tool schemas for OpenAI function calling.
    
    Returns:
        List of tool function declarations in OpenAI format
    """
    # Initialize tool list with implemented tools
    tools = []
    
    # Convert each schema to OpenAI format
    tools.append({
        "type": "function",
        "function": {
            "name": "filter_data",
            "description": get_filter_data_schema()['description'],
            "parameters": get_filter_data_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "load_data",
            "description": get_load_data_schema()['description'],
            "parameters": get_load_data_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "summarize_column",
            "description": get_summarize_column_schema()['description'],
            "parameters": get_summarize_column_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "summarize_row",
            "description": get_summarize_row_schema()['description'],
            "parameters": get_summarize_row_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "summarize_sheet",
            "description": get_summarize_sheet_schema()['description'],
            "parameters": get_summarize_sheet_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "summarize_workbook",
            "description": get_summarize_workbook_schema()['description'],
            "parameters": get_summarize_workbook_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "group_and_aggregate",
            "description": get_group_and_aggregate_schema()['description'],
            "parameters": get_group_and_aggregate_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "create_pivot_table",
            "description": get_create_pivot_table_schema()['description'],
            "parameters": get_create_pivot_table_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "visualize_data",
            "description": get_visualize_data_schema()['description'],
            "parameters": get_visualize_data_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "compare_columns",
            "description": get_compare_columns_schema()['description'],
            "parameters": get_compare_columns_schema()['parameters']
        }
    })
    
    tools.append({
        "type": "function",
        "function": {
            "name": "compare_files",
            "description": get_compare_files_schema()['description'],
            "parameters": get_compare_files_schema()['parameters']
        }
    })
    
    return tools 