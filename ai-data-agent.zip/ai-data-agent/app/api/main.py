import os
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from typing import Dict, Any
from functools import lru_cache

from app.data.dataframe_manager import DataFrameManager
from app.data.state_manager import StateManager
from app.agent.llm_connector import LLMConnector
from app.agent.openai_connector import OpenAIConnector
from app.agent.orchestrator import Orchestrator
from app.utils.exceptions import DataAgentError
from app.utils.logging import log_info, log_error


# Determine which LLM provider to use
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai").lower()  # Default to OpenAI

# Create global instances of managers
df_manager = DataFrameManager()
state_manager = StateManager()

# Create the appropriate LLM connector based on the provider
if LLM_PROVIDER == "gemini":
    llm_connector = LLMConnector(api_key=os.getenv("GEMINI_API_KEY"))
    log_info(f"Using Gemini as the LLM provider")
else:
    llm_connector = OpenAIConnector(api_key=os.getenv("OPENAI_API_KEY"))
    log_info(f"Using OpenAI as the LLM provider")

orchestrator = Orchestrator(df_manager, state_manager, llm_connector)


# Dependency to get the orchestrator
@lru_cache()
def get_orchestrator():
    return orchestrator


# Create FastAPI app
app = FastAPI(
    title="AI Data Agent API",
    description="API for interacting with CSV and Excel files using natural language",
    version="0.1.0"
)


# Configure CORS
allowed_origins = os.getenv("ALLOW_ORIGINS", "http://localhost:3000,http://localhost:8000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Mount static files directories
os.makedirs("storage/plots", exist_ok=True)
app.mount("/plot", StaticFiles(directory="storage/plots"), name="plots")


# Import routers (imported here to avoid circular imports)
def setup_routes():
    from app.api.routes.files import router as files_router
    from app.api.routes.chat import router as chat_router
    from app.api.routes.status import router as status_router
    
    # Include routers
    app.include_router(files_router, prefix="/files", tags=["files"])
    app.include_router(chat_router, prefix="/chat", tags=["chat"])
    app.include_router(status_router, prefix="/status", tags=["status"])


# Set up routes
setup_routes()


# Root endpoint
@app.get("/", tags=["root"])
def read_root() -> Dict[str, Any]:
    """
    Root endpoint that returns basic API information.
    """
    return {
        "name": "AI Data Agent API",
        "version": "0.1.0",
        "docs_url": "/docs",
        "endpoints": {
            "file_upload": "/files/upload",
            "chat": "/chat",
            "status": "/status/{session_id}"
        }
    }


# Exception handler for custom exceptions
@app.exception_handler(DataAgentError)
async def data_agent_exception_handler(request, exc):
    """
    Handler for DataAgentError exceptions.
    """
    return HTTPException(
        status_code=400,
        detail={
            "error": exc.message,
            "code": exc.code,
            "details": exc.details
        }
    )


# Run the app with uvicorn
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.api.main:app", host="0.0.0.0", port=8000, reload=True) 