from pydantic import BaseModel, Field, validator
from typing import Optional, Dict, Any, List


class ChatRequest(BaseModel):
    """
    Model for chat requests.
    """
    session_id: str = Field(..., description="Session identifier")
    message: str = Field(..., description="User message")


class FileUploadRequest(BaseModel):
    """
    Model for file upload requests.
    """
    session_id: Optional[str] = Field(None, description="Session identifier (optional, will create if not provided)")
    sheet_name: Optional[str] = Field(None, description="For Excel files, name of the sheet to load (optional)")


class StatusRequest(BaseModel):
    """
    Model for status check requests.
    """
    session_id: str = Field(..., description="Session identifier")


class DataRetrievalRequest(BaseModel):
    """
    Model for data retrieval requests.
    """
    session_id: str = Field(..., description="Session identifier")
    format: str = Field("json", description="Format to return the data in (json, csv, html)")
    version: Optional[str] = Field("current", description="Version of the data to retrieve (current, original, or specific version number)")
    
    @validator('format')
    def validate_format(cls, v):
        allowed_formats = ["json", "csv", "html", "markdown"]
        if v not in allowed_formats:
            raise ValueError(f"Format must be one of {', '.join(allowed_formats)}")
        return v 