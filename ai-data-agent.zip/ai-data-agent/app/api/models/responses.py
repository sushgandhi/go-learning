from pydantic import BaseModel, Field
from typing import Optional, Dict, Any, List


class ChatResponse(BaseModel):
    """
    Model for chat responses.
    """
    response: str = Field(..., description="Text response")
    data_table: Optional[str] = Field(None, description="Formatted data table (if applicable)")
    plot_url: Optional[str] = Field(None, description="URL to visualization (if applicable)")
    error: Optional[str] = Field(None, description="Error message (if applicable)")


class FileUploadResponse(BaseModel):
    """
    Model for file upload responses.
    """
    session_id: str = Field(..., description="Session identifier")
    file_name: str = Field(..., description="Name of the uploaded file")
    file_type: str = Field(..., description="Type of the uploaded file (csv, excel)")
    sheet_name: Optional[str] = Field(None, description="For Excel files, name of the loaded sheet")
    rows: int = Field(..., description="Number of rows in the loaded data")
    columns: int = Field(..., description="Number of columns in the loaded data")
    column_names: List[str] = Field(..., description="Names of the columns in the loaded data")
    message: str = Field(..., description="Message describing the upload result")
    error: Optional[str] = Field(None, description="Error message (if applicable)")


class StatusResponse(BaseModel):
    """
    Model for status check responses.
    """
    session_id: str = Field(..., description="Session identifier")
    active: bool = Field(..., description="Whether the session is active")
    dataframe_loaded: bool = Field(..., description="Whether a DataFrame is loaded for the session")
    current_operation: Optional[Dict[str, Any]] = Field(None, description="Current operation information (if any)")
    history_length: int = Field(..., description="Length of the conversation history")
    last_message: Optional[Dict[str, Any]] = Field(None, description="Last message in the conversation history")
    dataframe_info: Optional[Dict[str, Any]] = Field(None, description="Information about the loaded DataFrame (if any)")


class DataRetrievalResponse(BaseModel):
    """
    Model for data retrieval responses.
    """
    session_id: str = Field(..., description="Session identifier")
    format: str = Field(..., description="Format of the returned data")
    version: str = Field(..., description="Version of the returned data")
    data: str = Field(..., description="The retrieved data in the requested format")
    rows: int = Field(..., description="Number of rows in the data")
    columns: int = Field(..., description="Number of columns in the data")
    error: Optional[str] = Field(None, description="Error message (if applicable)")
    
    
class ErrorResponse(BaseModel):
    """
    Model for error responses.
    """
    error: str = Field(..., description="Error message")
    detail: Optional[Dict[str, Any]] = Field(None, description="Detailed error information")
    code: Optional[str] = Field(None, description="Error code") 