from fastapi import APIRouter, Depends, HTTPException, Response, status
from typing import Dict, Any
import sys

from app.api.models.requests import ChatRequest
from app.api.models.responses import ChatResponse
from app.agent.orchestrator import Orchestrator
from app.utils.exceptions import DataAgentError, DataframeNotFoundError, SessionNotFoundError
from app.utils.logging import log_error, log_info


# Create router
router = APIRouter()


# Get the orchestrator function
def get_orchestrator():
    # Import here to prevent circular import
    from app.api.main import get_orchestrator as main_get_orchestrator
    return main_get_orchestrator()


@router.post("", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    response: Response,
    orchestrator: Orchestrator = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Process a natural language query for data analysis.
    
    - **session_id**: Session identifier
    - **message**: User message/query
    
    Returns a response with:
    - **response**: Text response
    - **data_table**: Formatted data table (if applicable)
    - **plot_url**: URL to visualization (if applicable)
    - **error**: Error message (if applicable)
    """
    try:
        log_info(f"Processing chat request", {
            "session_id": request.session_id,
            "message": request.message
        })
        
        # Process the query through the orchestrator
        result = orchestrator.process_query(
            request.session_id,
            request.message
        )
        
        # Log the result structure
        log_info(f"Chat result structure", {
            "result_keys": list(result.keys()),
            "has_data_table": "data_table" in result and result["data_table"] is not None,
            "has_plot_url": "plot_url" in result and result["plot_url"] is not None,
        })
        
        # Return the result, ensuring we include all available data
        return ChatResponse(
            response=result.get('response', ''),
            data_table=result.get('data_table'),
            plot_url=result.get('plot_url'),
            error=result.get('error')
        )
    except DataframeNotFoundError as e:
        # Special case for when no DataFrame is loaded yet
        log_error(f"No DataFrame found", e, {"session_id": request.session_id})
        response.status_code = status.HTTP_400_BAD_REQUEST
        return ChatResponse(
            response=f"No data loaded yet. Please upload a CSV or Excel file first.",
            error=str(e)
        )
    except SessionNotFoundError as e:
        # Special case for when session doesn't exist
        log_error(f"Session not found", e, {"session_id": request.session_id})
        response.status_code = status.HTTP_404_NOT_FOUND
        return ChatResponse(
            response=f"Session not found. Please create a new session.",
            error=str(e)
        )
    except DataAgentError as e:
        # Handle other custom exceptions
        log_error(f"Data agent error", e, {"session_id": request.session_id})
        response.status_code = status.HTTP_400_BAD_REQUEST
        return ChatResponse(
            response=f"Error: {e.message}",
            error=e.message
        )
    except Exception as e:
        # Handle unexpected errors
        log_error(f"Unexpected error in chat endpoint", e, {
            "session_id": request.session_id,
            "message": request.message
        })
        response.status_code = status.HTTP_500_INTERNAL_SERVER_ERROR
        return ChatResponse(
            response=f"An unexpected error occurred: {str(e)}",
            error=str(e)
        ) 