import os
import uuid
import shutil
from fastapi import APIRouter, File, UploadFile, Form, Depends, HTTPException, Query
from typing import Dict, Any, Optional

from app.api.models.responses import FileUploadResponse
from app.agent.orchestrator import Orchestrator
from app.utils.exceptions import DataAgentError, FileProcessingError
from app.tools.data_loading import load_data


# Create router
router = APIRouter()


# Define upload directory
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "storage/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


# Get the orchestrator function
def get_orchestrator():
    # Import here to prevent circular import
    from app.api.main import get_orchestrator as main_get_orchestrator
    return main_get_orchestrator()


@router.post("/upload", response_model=FileUploadResponse)
async def upload_file(
    file: UploadFile = File(...),
    session_id: Optional[str] = Query(None),
    sheet_name: Optional[str] = Query(None),
    orchestrator: Orchestrator = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Upload a CSV or Excel file for analysis.
    
    - **file**: CSV or Excel file to upload
    - **session_id**: Session identifier (optional, will create if not provided)
    - **sheet_name**: For Excel files, name of the sheet to load (optional)
    
    Returns a response with file metadata and session information.
    """
    try:
        # Create session ID if not provided
        if not session_id:
            session_id = orchestrator.df_manager.create_session()
        
        # Save the uploaded file
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in ['.csv', '.xlsx', '.xls']:
            raise FileProcessingError(
                file.filename,
                f"Unsupported file type: {file_extension}. Supported formats: .csv, .xlsx, .xls"
            )
        
        # Create a unique filename to avoid conflicts
        unique_filename = f"{uuid.uuid4().hex}{file_extension}"
        file_path = os.path.join(UPLOAD_DIR, unique_filename)
        
        # Save the file
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Load the file using the data_loading tool
        try:
            result = load_data(file_path, sheet_name)
            
            # Update the DataFrame in the orchestrator
            orchestrator.df_manager.update_dataframe(
                session_id,
                result['result_df'],
                'load_data',
                {
                    'file_path': file_path,
                    'sheet_name': sheet_name
                }
            )
            
            # Store file metadata
            metadata = result['metadata']
            
            # Add file information to conversation history
            file_info_message = f"File '{file.filename}' loaded with {metadata['rows']} rows and {metadata['columns']} columns."
            orchestrator.state_manager.add_message(session_id, 'system', file_info_message)
            
            # Set as active file
            orchestrator.state_manager.set_active_file(session_id, file_path)
            
            # Create a more descriptive message
            message = (
                f"Successfully loaded file '{file.filename}' with {metadata['rows']} rows and {metadata['columns']} columns. "
                f"The file contains these columns: {', '.join(metadata['column_names'][:10])}"
            )
            if len(metadata['column_names']) > 10:
                message += f", and {len(metadata['column_names']) - 10} more."
            message += f"\nSession ID: {session_id}"
            
            # Return the response
            return FileUploadResponse(
                session_id=session_id,
                file_name=file.filename,
                file_type=metadata['file_type'],
                sheet_name=metadata['sheet_name'],
                rows=metadata['rows'],
                columns=metadata['columns'],
                column_names=metadata['column_names'],
                message=message
            )
        
        except Exception as e:
            # Clean up the file if loading failed
            if os.path.exists(file_path):
                os.remove(file_path)
            raise e
    
    except FileProcessingError as e:
        # Handle file processing errors
        return FileUploadResponse(
            session_id=session_id,
            file_name=file.filename,
            file_type="unknown",
            rows=0,
            columns=0,
            column_names=[],
            message=f"Error processing file: {e.message}",
            error=e.message
        )
    except DataAgentError as e:
        # Handle other custom exceptions
        return FileUploadResponse(
            session_id=session_id,
            file_name=file.filename,
            file_type="unknown",
            rows=0,
            columns=0,
            column_names=[],
            message=f"Error: {e.message}",
            error=e.message
        )
    except Exception as e:
        # Handle unexpected errors
        return FileUploadResponse(
            session_id=session_id,
            file_name=file.filename,
            file_type="unknown",
            rows=0,
            columns=0,
            column_names=[],
            message=f"An unexpected error occurred: {str(e)}",
            error=str(e)
        ) 