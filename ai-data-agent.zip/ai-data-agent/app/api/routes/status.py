from fastapi import APIRouter, Depends, HTTPException
from typing import Dict, Any

from app.api.models.requests import StatusRequest
from app.api.models.responses import StatusResponse
from app.agent.orchestrator import Orchestrator
from app.utils.exceptions import DataAgentError, SessionNotFoundError


# Create router
router = APIRouter()


# Get the orchestrator function
def get_orchestrator():
    # Import here to prevent circular import
    from app.api.main import get_orchestrator as main_get_orchestrator
    return main_get_orchestrator()


@router.get("/{session_id}", response_model=StatusResponse)
async def get_status(
    session_id: str,
    orchestrator: Orchestrator = Depends(get_orchestrator)
) -> Dict[str, Any]:
    """
    Get the status of a session.
    
    - **session_id**: Session identifier
    
    Returns a response with session status information.
    """
    try:
        # Check if session exists
        if not orchestrator._session_exists(session_id):
            raise SessionNotFoundError(session_id)
        
        # Get conversation history
        conversation = orchestrator.state_manager.get_conversation(session_id)
        history_length = len(conversation)
        
        # Get last message if available
        last_message = conversation[-1] if history_length > 0 else None
        
        # Get current operation status
        operation_status = orchestrator.state_manager.get_operation_status(session_id)
        
        # Check if a DataFrame is loaded
        dataframe_loaded = orchestrator.df_manager.dataframes.get(session_id) is not None
        
        # Get DataFrame info if available
        dataframe_info = None
        if dataframe_loaded:
            try:
                # Get basic DataFrame info (shape, columns)
                df = orchestrator.df_manager.get_dataframe(session_id)
                dataframe_info = {
                    'rows': len(df),
                    'columns': len(df.columns),
                    'column_names': df.columns.tolist()
                }
            except Exception:
                # If there's any error getting DataFrame info, just set it to None
                dataframe_info = None
        
        # Return the status
        return StatusResponse(
            session_id=session_id,
            active=True,
            dataframe_loaded=dataframe_loaded,
            current_operation=operation_status,
            history_length=history_length,
            last_message=last_message,
            dataframe_info=dataframe_info
        )
    
    except SessionNotFoundError as e:
        # Return a structured response for session not found
        return StatusResponse(
            session_id=session_id,
            active=False,
            dataframe_loaded=False,
            history_length=0,
            error=str(e)
        )
    except DataAgentError as e:
        # Handle other custom exceptions
        raise HTTPException(status_code=400, detail={"error": e.message, "code": e.code})
    except Exception as e:
        # Handle unexpected errors
        raise HTTPException(status_code=500, detail={"error": str(e)}) 