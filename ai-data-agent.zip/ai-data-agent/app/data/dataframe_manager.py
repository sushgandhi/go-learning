import pandas as pd
import os
import uuid
from typing import Dict, List, Optional, Any, Tuple
from datetime import datetime


class DataFrameManager:
    """
    Manages DataFrames and their metadata.
    Handles loading, storage, and versioning of DataFrames for multiple sessions.
    """
    def __init__(self):
        """Initialize the DataFrameManager"""
        # Store active DataFrames by session ID
        self.dataframes: Dict[str, pd.DataFrame] = {}
        # Store original DataFrames by session ID
        self.original_dataframes: Dict[str, pd.DataFrame] = {}
        # Store DataFrame histories (versions) by session ID
        self.history: Dict[str, List[Dict[str, Any]]] = {}
        # Store metadata about loaded files by session ID
        self.file_metadata: Dict[str, Dict[str, Any]] = {}
        
    def load_file(self, file_path: str, session_id: str, sheet_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Load a CSV or Excel file into a DataFrame.
        
        Args:
            file_path: Path to the file to load
            session_id: Session ID to associate with the DataFrame
            sheet_name: For Excel files, the name of the sheet to load (default: first sheet)
            
        Returns:
            Dictionary with metadata about the loaded file and DataFrame
        """
        # Check if file exists
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")
        
        # Determine file type based on extension
        file_extension = os.path.splitext(file_path)[1].lower()
        
        try:
            # Load based on file type
            if file_extension == '.csv':
                df = pd.read_csv(file_path)
                file_type = 'csv'
                sheets = None
            elif file_extension in ['.xlsx', '.xls']:
                # If sheet_name is None, read the first sheet
                if sheet_name is None:
                    # Get list of sheet names
                    all_sheets = pd.ExcelFile(file_path).sheet_names
                    sheet_name = all_sheets[0]  # Default to first sheet
                    sheets = all_sheets
                else:
                    # Verify the sheet exists
                    all_sheets = pd.ExcelFile(file_path).sheet_names
                    if sheet_name not in all_sheets:
                        raise ValueError(f"Sheet '{sheet_name}' not found in Excel file")
                    sheets = all_sheets
                
                # Read the specified sheet
                df = pd.read_excel(file_path, sheet_name=sheet_name)
                file_type = 'excel'
            else:
                raise ValueError(f"Unsupported file type: {file_extension}")
            
            # Store the DataFrame
            self.dataframes[session_id] = df
            # Store a copy as the original
            self.original_dataframes[session_id] = df.copy()
            
            # Initialize history for this session
            self.history[session_id] = [{
                'version': 0,  # Initial version
                'operation': 'load_file',
                'timestamp': datetime.now().isoformat(),
                'rows': len(df),
                'columns': len(df.columns)
            }]
            
            # Store file metadata
            self.file_metadata[session_id] = {
                'file_path': file_path,
                'file_name': os.path.basename(file_path),
                'file_type': file_type,
                'sheet_name': sheet_name if file_type == 'excel' else None,
                'sheets': sheets,
                'loaded_at': datetime.now().isoformat(),
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': df.columns.tolist(),
                'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                'sample_data': df.head(3).to_dict(orient='records') if len(df) > 0 else []
            }
            
            # Return metadata about the loaded file
            return {
                'success': True,
                'file_path': file_path,
                'file_name': os.path.basename(file_path),
                'file_type': file_type,
                'sheet_name': sheet_name if file_type == 'excel' else None,
                'sheets': sheets,
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': df.columns.tolist(),
                'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()}
            }
            
        except Exception as e:
            # Re-raise with more context
            raise RuntimeError(f"Error loading file '{file_path}': {str(e)}") from e
    
    def get_dataframe(self, session_id: str, version: str = 'current') -> pd.DataFrame:
        """
        Get a DataFrame for a session, optionally at a specific version.
        
        Args:
            session_id: Session ID associated with the DataFrame
            version: 'current', 'original', or a specific version number
            
        Returns:
            The requested DataFrame
        """
        # Check if session exists
        if session_id not in self.dataframes:
            raise KeyError(f"No DataFrame found for session_id: {session_id}")
        
        # Check if dataframe is None
        if self.dataframes[session_id] is None:
            raise KeyError(f"No DataFrame loaded yet for session_id: {session_id}")
        
        # Return based on version requested
        if version == 'current':
            return self.dataframes[session_id]
        elif version == 'original':
            return self.original_dataframes[session_id]
        else:
            # Convert version to int if it's a string number
            try:
                version_num = int(version)
            except ValueError:
                raise ValueError(f"Invalid version: {version}")
            
            # Check if version exists in history
            history = self.history[session_id]
            versions = [entry['version'] for entry in history]
            if version_num not in versions:
                raise ValueError(f"Version {version_num} not found for session_id: {session_id}")
            
            # For a real implementation, we would store actual DataFrames for each version
            # This is a simplified version that only works for 'current' and 'original'
            raise NotImplementedError("Version retrieval not implemented yet")
    
    def update_dataframe(self, session_id: str, new_df: pd.DataFrame, operation_name: str, 
                        operation_details: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Save a new version of a DataFrame after an operation.
        
        Args:
            session_id: Session ID associated with the DataFrame
            new_df: The new DataFrame to store
            operation_name: Name of the operation that produced this DataFrame
            operation_details: Optional details about the operation
            
        Returns:
            Dictionary with metadata about the update
        """
        # If session doesn't exist, create it
        if session_id not in self.dataframes:
            self.create_session()
            self.dataframes[session_id] = None
            self.original_dataframes[session_id] = None
            self.history[session_id] = []
        
        # Calculate new version number
        new_version = len(self.history[session_id])
        
        # Update the current DataFrame
        self.dataframes[session_id] = new_df
        
        # If this is the first update, also set as original
        if self.original_dataframes[session_id] is None:
            self.original_dataframes[session_id] = new_df.copy()
        
        # Add entry to history
        history_entry = {
            'version': new_version,
            'operation': operation_name,
            'timestamp': datetime.now().isoformat(),
            'rows': len(new_df),
            'columns': len(new_df.columns)
        }
        
        # Add operation details if provided
        if operation_details:
            history_entry['details'] = operation_details
            
        self.history[session_id].append(history_entry)
        
        # Return metadata about the update
        return {
            'success': True,
            'session_id': session_id,
            'version': new_version,
            'operation': operation_name,
            'rows': len(new_df),
            'columns': len(new_df.columns)
        }
    
    def get_file_metadata(self, session_id: str) -> Dict[str, Any]:
        """
        Get metadata about the file loaded for a session.
        
        Args:
            session_id: Session ID to get metadata for
            
        Returns:
            Dictionary with file metadata
        """
        if session_id not in self.file_metadata:
            raise KeyError(f"No file metadata found for session_id: {session_id}")
        
        return self.file_metadata[session_id]
    
    def get_dataframe_info(self, session_id: str, version: str = 'current') -> Dict[str, Any]:
        """
        Get information about a DataFrame.
        
        Args:
            session_id: Session ID associated with the DataFrame
            version: 'current', 'original', or a specific version number
            
        Returns:
            Dictionary with DataFrame information
        """
        try:
            # Get the requested DataFrame
            df = self.get_dataframe(session_id, version)
            
            # Get basic information
            info = {
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': df.columns.tolist(),
                'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                'memory_usage': df.memory_usage(deep=True).sum(),
                'null_counts': df.isnull().sum().to_dict()
            }
            
            # Get numeric column statistics if any exist
            numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
            if numeric_cols:
                info['numeric_columns'] = numeric_cols
                info['numeric_stats'] = df[numeric_cols].describe().to_dict()
            
            # Get categorical column information if any exist
            categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
            if categorical_cols:
                info['categorical_columns'] = categorical_cols
                # Get value counts for categorical columns (limit to top 10)
                cat_value_counts = {}
                for col in categorical_cols:
                    cat_value_counts[col] = df[col].value_counts().head(10).to_dict()
                info['categorical_value_counts'] = cat_value_counts
            
            return info
        except (KeyError, ValueError) as e:
            # If DataFrame doesn't exist or is None, return minimal info
            return {
                'error': str(e),
                'rows': 0,
                'columns': 0,
                'column_names': []
            }
    
    def create_session(self) -> str:
        """
        Create a new empty session.
        
        Returns:
            New session ID
        """
        session_id = str(uuid.uuid4())
        self.dataframes[session_id] = None
        self.original_dataframes[session_id] = None
        self.history[session_id] = []
        self.file_metadata[session_id] = {}
        
        return session_id 