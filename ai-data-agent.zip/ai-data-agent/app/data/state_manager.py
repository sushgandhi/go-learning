from typing import Dict, List, Optional, Any
from datetime import datetime


class StateManager:
    """
    Manages conversation context and operational state.
    Tracks conversation history, active files, and user-defined aliases.
    """
    def __init__(self):
        """Initialize the StateManager"""
        # Track conversation history by session ID
        self.conversations: Dict[str, List[Dict[str, Any]]] = {}
        # Track current file/DataFrame reference by session ID
        self.active_files: Dict[str, str] = {}
        # Track user-defined aliases by session ID
        self.aliases: Dict[str, Dict[str, str]] = {}
        # Track active operations by session ID (for long-running operations)
        self.active_operations: Dict[str, Dict[str, Any]] = {}
        
    def add_message(self, session_id: str, role: str, content: Any) -> None:
        """
        Add a message to the conversation history.
        
        Args:
            session_id: Session ID to add the message to
            role: Role of the message sender (e.g., 'user', 'assistant', 'system')
            content: Content of the message (text or structured data)
        """
        # Initialize conversation for session if not exists
        if session_id not in self.conversations:
            self.conversations[session_id] = []
            
        # Add the message with timestamp
        self.conversations[session_id].append({
            'role': role,
            'content': content,
            'timestamp': datetime.now().isoformat()
        })
    
    def add_system_message(self, session_id: str, content: Any) -> None:
        """
        Add a system message to the conversation history.
        
        Args:
            session_id: Session ID to add the message to
            content: Content of the system message
        """
        self.add_message(session_id, 'system', content)
    
    def get_conversation(self, session_id: str, last_n: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get conversation history for a session.
        
        Args:
            session_id: Session ID to get conversation for
            last_n: Optionally, limit to last n messages
            
        Returns:
            List of conversation messages
        """
        # Check if session exists
        if session_id not in self.conversations:
            return []
            
        # Get full conversation
        conversation = self.conversations[session_id]
        
        # Limit to last n messages if specified
        if last_n is not None and last_n > 0:
            return conversation[-last_n:]
        
        return conversation
    
    def set_active_file(self, session_id: str, file_id: str) -> None:
        """
        Set the active file for a session.
        
        Args:
            session_id: Session ID to set active file for
            file_id: ID of the file to set as active
        """
        self.active_files[session_id] = file_id
    
    def get_active_file(self, session_id: str) -> Optional[str]:
        """
        Get the active file for a session.
        
        Args:
            session_id: Session ID to get active file for
            
        Returns:
            Active file ID or None if not set
        """
        return self.active_files.get(session_id)
    
    def add_alias(self, session_id: str, original: str, alias: str) -> None:
        """
        Add a user-defined alias for a column or value.
        
        Args:
            session_id: Session ID to add alias for
            original: Original column or value name
            alias: Alias to use instead
        """
        # Initialize aliases for session if not exists
        if session_id not in self.aliases:
            self.aliases[session_id] = {}
            
        # Add the alias
        self.aliases[session_id][alias] = original
    
    def get_original_name(self, session_id: str, name: str) -> str:
        """
        Get the original name for a possible alias.
        
        Args:
            session_id: Session ID to check aliases for
            name: Name or alias to look up
            
        Returns:
            Original name if name is an alias, otherwise the name itself
        """
        # If session doesn't have aliases or name is not an alias, return as is
        if session_id not in self.aliases or name not in self.aliases[session_id]:
            return name
            
        # Return the original name
        return self.aliases[session_id][name]
    
    def start_operation(self, session_id: str, operation_name: str, details: Dict[str, Any] = None) -> None:
        """
        Mark an operation as active for a session.
        
        Args:
            session_id: Session ID to mark operation for
            operation_name: Name of the operation
            details: Optional details about the operation
        """
        # Initialize active operations for session if not exists
        if session_id not in self.active_operations:
            self.active_operations[session_id] = {}
            
        # Set the operation as active
        self.active_operations[session_id] = {
            'name': operation_name,
            'start_time': datetime.now().isoformat(),
            'status': 'in_progress',
            'details': details or {}
        }
    
    def end_operation(self, session_id: str, status: str = 'completed', result: Dict[str, Any] = None) -> None:
        """
        Mark an operation as completed for a session.
        
        Args:
            session_id: Session ID to update operation for
            status: Status of the operation ('completed', 'failed', etc.)
            result: Optional result of the operation
        """
        # Check if session and operation exist
        if session_id not in self.active_operations:
            return
            
        # Update the operation status
        self.active_operations[session_id].update({
            'status': status,
            'end_time': datetime.now().isoformat(),
            'result': result or {}
        })
    
    def get_operation_status(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get the status of the active operation for a session.
        
        Args:
            session_id: Session ID to get operation status for
            
        Returns:
            Dictionary with operation status or None if no active operation
        """
        return self.active_operations.get(session_id)
    
    def clear_conversation(self, session_id: str) -> None:
        """
        Clear the conversation history for a session.
        
        Args:
            session_id: Session ID to clear conversation for
        """
        if session_id in self.conversations:
            self.conversations[session_id] = [] 