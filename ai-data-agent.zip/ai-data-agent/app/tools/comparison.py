import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import Dict, Any, List, Optional, Union
from app.utils.exceptions import ToolExecutionError
from app.utils.helpers import save_plot
from app.tools.data_loading import load_data


def compare_columns(df: pd.DataFrame, col1: str, col2: str, comparison_type: str) -> Dict[str, Any]:
    """
    Compares two columns in a DataFrame.
    
    Args:
        df: The DataFrame containing the columns to compare
        col1: Name of the first column to compare
        col2: Name of the second column to compare
        comparison_type: Type of comparison to perform:
            - 'correlation': Calculate correlation coefficient
            - 'difference': Calculate differences between values
            - 'distribution': Compare distributions visually
            - 'value_comparison': Compare values side by side
        
    Returns:
        Dictionary containing comparison results and optional visualization
    """
    # Input validation
    if df is None:
        raise ToolExecutionError("compare_columns", "DataFrame is None")
    
    # Validate columns exist
    if col1 not in df.columns:
        raise ToolExecutionError(
            "compare_columns",
            f"Column '{col1}' not found in DataFrame. Available columns: {', '.join(df.columns)}"
        )
    
    if col2 not in df.columns:
        raise ToolExecutionError(
            "compare_columns",
            f"Column '{col2}' not found in DataFrame. Available columns: {', '.join(df.columns)}"
        )
    
    # Validate comparison type
    supported_comparison_types = ["correlation", "difference", "distribution", "value_comparison"]
    if comparison_type.lower() not in supported_comparison_types:
        raise ToolExecutionError(
            "compare_columns",
            f"Unsupported comparison type: '{comparison_type}'. Supported types: {', '.join(supported_comparison_types)}"
        )
    
    try:
        result = {
            'message': f"Comparison of columns '{col1}' and '{col2}' using {comparison_type}.",
            'metadata': {
                'col1': col1,
                'col2': col2,
                'comparison_type': comparison_type,
                'dtype_col1': str(df[col1].dtype),
                'dtype_col2': str(df[col2].dtype)
            }
        }
        
        # Different comparison methods
        if comparison_type.lower() == "correlation":
            # Check if both columns are numeric
            if not pd.api.types.is_numeric_dtype(df[col1]) or not pd.api.types.is_numeric_dtype(df[col2]):
                raise ToolExecutionError(
                    "compare_columns",
                    f"Correlation requires numeric columns. '{col1}' is {df[col1].dtype} and '{col2}' is {df[col2].dtype}."
                )
            
            # Calculate correlation
            pearson_corr = df[col1].corr(df[col2], method='pearson')
            spearman_corr = df[col1].corr(df[col2], method='spearman')
            
            # Create scatter plot with regression line
            fig, ax = plt.subplots(figsize=(10, 6))
            sns.regplot(x=col1, y=col2, data=df, scatter_kws={'alpha':0.5}, ax=ax)
            ax.set_title(f"Correlation between {col1} and {col2}")
            plt.tight_layout()
            
            # Save plot
            plot_url = save_plot(fig)
            
            # Prepare result
            result['plot_url'] = plot_url
            result['metadata'].update({
                'pearson_correlation': round(pearson_corr, 4),
                'spearman_correlation': round(spearman_corr, 4),
                'interpretation': interpret_correlation(pearson_corr)
            })
            
            # Create result DataFrame
            result_df = pd.DataFrame({
                'Measure': ['Pearson Correlation', 'Spearman Correlation', 'Interpretation'],
                'Value': [round(pearson_corr, 4), round(spearman_corr, 4), interpret_correlation(pearson_corr)]
            })
            result['result_df'] = result_df
            
        elif comparison_type.lower() == "difference":
            # Ensure comparable dtypes
            if df[col1].dtype != df[col2].dtype and not (
                pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2])
            ):
                raise ToolExecutionError(
                    "compare_columns",
                    f"Difference comparison requires compatible datatypes. '{col1}' is {df[col1].dtype} and '{col2}' is {df[col2].dtype}."
                )
            
            # Calculate differences for numeric columns
            if pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2]):
                difference = df[col1] - df[col2]
                
                # Calculate statistics
                mean_diff = difference.mean()
                median_diff = difference.median()
                std_diff = difference.std()
                min_diff = difference.min()
                max_diff = difference.max()
                
                # Create histogram of differences
                fig, ax = plt.subplots(figsize=(10, 6))
                sns.histplot(difference, kde=True, ax=ax)
                ax.set_title(f"Histogram of differences ({col1} - {col2})")
                ax.axvline(x=0, color='red', linestyle='--')
                plt.tight_layout()
                
                # Save plot
                plot_url = save_plot(fig)
                
                # Prepare result
                result['plot_url'] = plot_url
                result['metadata'].update({
                    'mean_difference': round(mean_diff, 4),
                    'median_difference': round(median_diff, 4),
                    'std_difference': round(std_diff, 4),
                    'min_difference': round(min_diff, 4),
                    'max_difference': round(max_diff, 4)
                })
                
                # Create result DataFrame with differences
                diff_df = pd.DataFrame({
                    col1: df[col1],
                    col2: df[col2],
                    'Difference': difference
                })
                result['result_df'] = diff_df
                
            else:
                # For non-numeric columns, show where they differ
                same_values = (df[col1] == df[col2])
                different_count = (~same_values).sum()
                same_count = same_values.sum()
                
                result['metadata'].update({
                    'total_rows': len(df),
                    'same_values_count': int(same_count),
                    'different_values_count': int(different_count),
                    'percent_same': round((same_count / len(df) * 100), 2),
                    'percent_different': round((different_count / len(df) * 100), 2)
                })
                
                # Create result DataFrame showing differences
                result_df = pd.DataFrame({
                    col1: df[col1],
                    col2: df[col2],
                    'Is_Same': same_values
                })
                
                # Create a simple pie chart showing proportion of same/different
                fig, ax = plt.subplots(figsize=(8, 8))
                ax.pie([same_count, different_count], 
                       labels=['Same', 'Different'],
                       autopct='%1.1f%%',
                       colors=['#4CAF50', '#F44336'])
                ax.set_title(f"Comparison of values: {col1} vs {col2}")
                plt.tight_layout()
                
                # Save plot
                plot_url = save_plot(fig)
                result['plot_url'] = plot_url
                result['result_df'] = result_df
            
        elif comparison_type.lower() == "distribution":
            # Create distribution comparison plots
            fig, ax = plt.subplots(figsize=(12, 6))
            
            # Approach depends on data type
            if pd.api.types.is_numeric_dtype(df[col1]) and pd.api.types.is_numeric_dtype(df[col2]):
                # For numeric columns, use KDE plots
                sns.kdeplot(df[col1], label=col1, ax=ax)
                sns.kdeplot(df[col2], label=col2, ax=ax)
                ax.set_title(f"Distribution comparison: {col1} vs {col2}")
                ax.legend()
                
                # Calculate distribution statistics
                stats_df = pd.DataFrame({
                    'Statistic': ['mean', 'median', 'std_dev', 'min', '25%', '50%', '75%', 'max'],
                    col1: [df[col1].mean(), df[col1].median(), df[col1].std(), df[col1].min(),
                           df[col1].quantile(0.25), df[col1].quantile(0.5), df[col1].quantile(0.75), df[col1].max()],
                    col2: [df[col2].mean(), df[col2].median(), df[col2].std(), df[col2].min(),
                           df[col2].quantile(0.25), df[col2].quantile(0.5), df[col2].quantile(0.75), df[col2].max()]
                })
                
                # Update metadata
                result['metadata'].update({
                    f'{col1}_mean': round(df[col1].mean(), 4),
                    f'{col1}_median': round(df[col1].median(), 4),
                    f'{col1}_std': round(df[col1].std(), 4),
                    f'{col2}_mean': round(df[col2].mean(), 4),
                    f'{col2}_median': round(df[col2].median(), 4),
                    f'{col2}_std': round(df[col2].std(), 4)
                })
                
            else:
                # For categorical columns, use count plots
                plt.subplot(1, 2, 1)
                sns.countplot(y=df[col1], order=df[col1].value_counts().index[:10])
                plt.title(f"Top values in {col1}")
                plt.tight_layout()
                
                plt.subplot(1, 2, 2)
                sns.countplot(y=df[col2], order=df[col2].value_counts().index[:10])
                plt.title(f"Top values in {col2}")
                plt.tight_layout()
                
                # Calculate value counts
                val_counts1 = df[col1].value_counts().head(10)
                val_counts2 = df[col2].value_counts().head(10)
                
                # Create a DataFrame for display
                stats_df = pd.DataFrame({
                    'Statistic': ['unique_values', 'most_common', 'most_common_count'],
                    col1: [df[col1].nunique(), val_counts1.index[0] if not val_counts1.empty else None, 
                           val_counts1.iloc[0] if not val_counts1.empty else 0],
                    col2: [df[col2].nunique(), val_counts2.index[0] if not val_counts2.empty else None, 
                           val_counts2.iloc[0] if not val_counts2.empty else 0]
                })
                
                # Update metadata
                result['metadata'].update({
                    f'{col1}_unique_values': df[col1].nunique(),
                    f'{col1}_top_value': val_counts1.index[0] if not val_counts1.empty else None,
                    f'{col1}_top_count': int(val_counts1.iloc[0]) if not val_counts1.empty else 0,
                    f'{col2}_unique_values': df[col2].nunique(),
                    f'{col2}_top_value': val_counts2.index[0] if not val_counts2.empty else None,
                    f'{col2}_top_count': int(val_counts2.iloc[0]) if not val_counts2.empty else 0
                })
            
            # Save the plot
            plot_url = save_plot(fig)
            result['plot_url'] = plot_url
            result['result_df'] = stats_df
            
        elif comparison_type.lower() == "value_comparison":
            # Create a side-by-side comparison DataFrame
            comparison_df = pd.DataFrame({
                col1: df[col1],
                col2: df[col2]
            })
            
            # Add a column showing if values are the same
            comparison_df['is_same'] = df[col1] == df[col2]
            
            # Calculate basic statistics
            same_count = comparison_df['is_same'].sum()
            diff_count = len(comparison_df) - same_count
            
            # Update metadata
            result['metadata'].update({
                'total_rows': len(df),
                'identical_values': int(same_count),
                'different_values': int(diff_count),
                'percent_identical': round((same_count / len(df) * 100), 2)
            })
            
            # Set result DataFrame
            result['result_df'] = comparison_df
            
        return result
        
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
        
        # Otherwise wrap it
        raise ToolExecutionError("compare_columns", str(e))


def compare_files(file_path1: str, file_path2: str, comparison_type: str) -> Dict[str, Any]:
    """
    Compares two data files.
    
    Args:
        file_path1: Path to the first file
        file_path2: Path to the second file
        comparison_type: Type of comparison to perform:
            - 'structure': Compare column names, data types
            - 'common_rows': Find common rows
            - 'differences': Find rows that differ
            - 'summary_comparison': Compare summary statistics
        
    Returns:
        Dictionary containing comparison results
    """
    try:
        # Load both files
        try:
            result1 = load_data(file_path1)
            df1 = result1['result_df']
            file1_info = result1['metadata']
        except Exception as e:
            raise ToolExecutionError("compare_files", f"Error loading first file: {str(e)}")
        
        try:
            result2 = load_data(file_path2)
            df2 = result2['result_df']
            file2_info = result2['metadata']
        except Exception as e:
            raise ToolExecutionError("compare_files", f"Error loading second file: {str(e)}")
        
        # Validate comparison type
        supported_comparison_types = ["structure", "common_rows", "differences", "summary_comparison"]
        if comparison_type.lower() not in supported_comparison_types:
            raise ToolExecutionError(
                "compare_files",
                f"Unsupported comparison type: '{comparison_type}'. Supported types: {', '.join(supported_comparison_types)}"
            )
        
        # Basic file information
        file1_name = file1_info['file_name']
        file2_name = file2_info['file_name']
        
        result = {
            'message': f"Comparison of files '{file1_name}' and '{file2_name}' using {comparison_type}.",
            'metadata': {
                'file1': file1_info,
                'file2': file2_info,
                'comparison_type': comparison_type
            }
        }
        
        # Different comparison methods
        if comparison_type.lower() == "structure":
            # Compare column names
            cols1 = set(df1.columns)
            cols2 = set(df2.columns)
            common_cols = cols1.intersection(cols2)
            only_in_file1 = cols1 - cols2
            only_in_file2 = cols2 - cols1
            
            # Compare data types for common columns
            dtypes_comparison = {}
            for col in common_cols:
                dtypes_comparison[col] = {
                    'file1_dtype': str(df1[col].dtype),
                    'file2_dtype': str(df2[col].dtype),
                    'is_same': df1[col].dtype == df2[col].dtype
                }
            
            # Update metadata
            result['metadata'].update({
                'common_columns_count': len(common_cols),
                'only_in_file1_count': len(only_in_file1),
                'only_in_file2_count': len(only_in_file2),
                'common_columns': list(common_cols),
                'only_in_file1': list(only_in_file1),
                'only_in_file2': list(only_in_file2),
                'dtypes_comparison': dtypes_comparison
            })
            
            # Create a comparison DataFrame
            structure_df = pd.DataFrame({
                'Column': list(cols1.union(cols2)),
                'In_File1': [col in cols1 for col in cols1.union(cols2)],
                'In_File2': [col in cols2 for col in cols1.union(cols2)],
                'File1_Dtype': [str(df1[col].dtype) if col in cols1 else None for col in cols1.union(cols2)],
                'File2_Dtype': [str(df2[col].dtype) if col in cols2 else None for col in cols1.union(cols2)]
            })
            
            # Add "Same Dtype" column for common columns
            structure_df['Same_Dtype'] = structure_df.apply(
                lambda row: row['File1_Dtype'] == row['File2_Dtype'] if row['In_File1'] and row['In_File2'] else None, 
                axis=1
            )
            
            # Set result DataFrame
            result['result_df'] = structure_df
            
        elif comparison_type.lower() == "common_rows":
            # Ensure both DataFrames have the same columns for comparison
            common_cols = set(df1.columns).intersection(set(df2.columns))
            
            if not common_cols:
                raise ToolExecutionError(
                    "compare_files",
                    "The files have no common columns to compare rows"
                )
            
            # Use only common columns for comparison
            df1_common = df1[list(common_cols)]
            df2_common = df2[list(common_cols)]
            
            # Find duplicate rows in each DataFrame (if any)
            df1_duplicates = df1_common[df1_common.duplicated()]
            df2_duplicates = df2_common[df2_common.duplicated()]
            
            # Method 1: Direct merge (works well for small to medium datasets)
            try:
                # Use a merge indicator to identify common rows
                merged = pd.merge(df1_common, df2_common, how='inner', indicator=False)
                common_rows = merged.drop_duplicates()
            except Exception:
                # If merge fails (e.g., memory issues), fall back to a simpler approach
                common_rows = pd.DataFrame(columns=list(common_cols))
                
                # This is a simple but inefficient way to find common rows for large datasets
                # In a production system, consider batch processing or more efficient algorithms
                for _, row1 in df1_common.iterrows():
                    if any((df2_common == row1).all(axis=1)):
                        common_rows = pd.concat([common_rows, pd.DataFrame([row1])], ignore_index=True)
            
            # Update metadata
            result['metadata'].update({
                'file1_rows': len(df1),
                'file2_rows': len(df2),
                'common_rows_count': len(common_rows),
                'common_columns_used': list(common_cols),
                'file1_duplicates': len(df1_duplicates),
                'file2_duplicates': len(df2_duplicates)
            })
            
            # Set result DataFrame
            result['result_df'] = common_rows
            
        elif comparison_type.lower() == "differences":
            # Ensure both DataFrames have the same columns for comparison
            common_cols = set(df1.columns).intersection(set(df2.columns))
            
            if not common_cols:
                raise ToolExecutionError(
                    "compare_files",
                    "The files have no common columns to compare differences"
                )
            
            # Use only common columns for comparison
            df1_common = df1[list(common_cols)]
            df2_common = df2[list(common_cols)]
            
            # Mark rows with file source
            df1_marked = df1_common.copy()
            df1_marked['source'] = file1_name
            
            df2_marked = df2_common.copy()
            df2_marked['source'] = file2_name
            
            # Combine and find duplicates (rows that exist in both files)
            combined = pd.concat([df1_marked, df2_marked], ignore_index=True)
            duplicate_mask = combined.duplicated(subset=list(common_cols), keep=False)
            
            # Extract rows that are unique to each file
            unique_rows = combined[~duplicate_mask]
            
            # Update metadata
            result['metadata'].update({
                'file1_total_rows': len(df1),
                'file2_total_rows': len(df2),
                'unique_to_file1': len(unique_rows[unique_rows['source'] == file1_name]),
                'unique_to_file2': len(unique_rows[unique_rows['source'] == file2_name]),
                'common_columns_used': list(common_cols)
            })
            
            # Set result DataFrame
            result['result_df'] = unique_rows
            
        elif comparison_type.lower() == "summary_comparison":
            # Collect summary statistics for both files
            numeric_cols1 = df1.select_dtypes(include=[np.number]).columns
            numeric_cols2 = df2.select_dtypes(include=[np.number]).columns
            
            # Find common numeric columns for statistical comparison
            common_numeric_cols = set(numeric_cols1).intersection(set(numeric_cols2))
            
            # Create summary comparison for common numeric columns
            if common_numeric_cols:
                summary_comparison = []
                
                for col in common_numeric_cols:
                    summary1 = df1[col].describe()
                    summary2 = df2[col].describe()
                    
                    # Calculate differences
                    diff_mean = summary1['mean'] - summary2['mean']
                    diff_std = summary1['std'] - summary2['std']
                    diff_min = summary1['min'] - summary2['min']
                    diff_max = summary1['max'] - summary2['max']
                    
                    summary_comparison.append({
                        'column': col,
                        'file1_mean': summary1['mean'],
                        'file2_mean': summary2['mean'],
                        'mean_diff': diff_mean,
                        'mean_diff_percent': round((diff_mean / summary2['mean'] * 100), 2) if summary2['mean'] != 0 else None,
                        'file1_std': summary1['std'],
                        'file2_std': summary2['std'],
                        'std_diff': diff_std,
                        'file1_min': summary1['min'],
                        'file2_min': summary2['min'],
                        'min_diff': diff_min,
                        'file1_max': summary1['max'],
                        'file2_max': summary2['max'],
                        'max_diff': diff_max
                    })
                
                # Create a DataFrame for the summary comparison
                summary_df = pd.DataFrame(summary_comparison)
                
                # Update metadata
                result['metadata'].update({
                    'common_numeric_columns': list(common_numeric_cols),
                    'file1_only_numeric_columns': list(set(numeric_cols1) - set(numeric_cols2)),
                    'file2_only_numeric_columns': list(set(numeric_cols2) - set(numeric_cols1)),
                    'summary_statistics': summary_comparison
                })
                
                # Set result DataFrame
                result['result_df'] = summary_df
                
            else:
                # If no common numeric columns, create a general structure comparison
                categorical_cols1 = df1.select_dtypes(include=['object', 'category']).columns
                categorical_cols2 = df2.select_dtypes(include=['object', 'category']).columns
                
                # Find common categorical columns
                common_categorical_cols = set(categorical_cols1).intersection(set(categorical_cols2))
                
                # Create basic structure comparison
                structure_comparison = {
                    'file1_rows': len(df1),
                    'file2_rows': len(df2),
                    'file1_columns': len(df1.columns),
                    'file2_columns': len(df2.columns),
                    'common_columns': len(set(df1.columns).intersection(set(df2.columns))),
                    'file1_numeric_columns': len(numeric_cols1),
                    'file2_numeric_columns': len(numeric_cols2),
                    'file1_categorical_columns': len(categorical_cols1),
                    'file2_categorical_columns': len(categorical_cols2),
                    'common_categorical_columns': len(common_categorical_cols)
                }
                
                # Convert to DataFrame for display
                structure_df = pd.DataFrame({
                    'Metric': list(structure_comparison.keys()),
                    'Value': list(structure_comparison.values())
                })
                
                # Update metadata
                result['metadata'].update(structure_comparison)
                
                # Set result DataFrame
                result['result_df'] = structure_df
        
        return result
        
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
        
        # Otherwise wrap it
        raise ToolExecutionError("compare_files", str(e))


def interpret_correlation(corr_value: float) -> str:
    """
    Provides a human-readable interpretation of a correlation coefficient.
    
    Args:
        corr_value: Correlation coefficient (-1 to 1)
        
    Returns:
        String interpretation of the correlation strength and direction
    """
    abs_corr = abs(corr_value)
    
    if abs_corr < 0.1:
        strength = "No or negligible"
    elif abs_corr < 0.3:
        strength = "Weak"
    elif abs_corr < 0.5:
        strength = "Moderate"
    elif abs_corr < 0.7:
        strength = "Moderately strong"
    elif abs_corr < 0.9:
        strength = "Strong"
    else:
        strength = "Very strong"
    
    direction = "positive" if corr_value > 0 else "negative"
    
    if abs_corr < 0.1:
        return f"{strength} correlation"
    else:
        return f"{strength} {direction} correlation" 