import pandas as pd
from typing import List, Dict, Any, Union
from app.utils.exceptions import ToolExecutionError


def filter_data(df: pd.DataFrame, filter_criteria: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Filters a pandas DataFrame based on multiple criteria.

    Args:
        df: The input pandas DataFrame.
        filter_criteria: A list of dictionaries, where each dictionary
                         specifies a column, operator (==, >, <, >=, <=, !=),
                         and value for filtering.
                         Example: [{'column': 'Sales', 'operator': '>', 'value': 1000}]

    Returns:
        Dictionary containing the filtered DataFrame and metadata about the operation.
    """
    # Input validation
    if df is None:
        raise ToolExecutionError("filter_data", "DataFrame is None")

    if not isinstance(filter_criteria, list):
        raise ToolExecutionError(
            "filter_data", 
            f"filter_criteria must be a list, got {type(filter_criteria).__name__}"
        )

    # Copy DataFrame to avoid modifying the original
    filtered_df = df.copy()
    original_row_count = len(filtered_df)
    
    # Keep track of how many rows were filtered at each step
    filter_steps = []
    
    try:
        for i, criterion in enumerate(filter_criteria):
            # Validate criterion structure
            if not isinstance(criterion, dict):
                raise ToolExecutionError(
                    "filter_data", 
                    f"Each filter criterion must be a dictionary, got {type(criterion).__name__}"
                )
            
            required_keys = ['column', 'operator', 'value']
            for key in required_keys:
                if key not in criterion:
                    raise ToolExecutionError(
                        "filter_data", 
                        f"Filter criterion missing required key: '{key}'"
                    )
            
            col = criterion['column']
            op = criterion['operator']
            val = criterion['value']
            
            # Validate column exists
            if col not in filtered_df.columns:
                raise ToolExecutionError(
                    "filter_data", 
                    f"Column '{col}' not found in DataFrame. Available columns: {', '.join(filtered_df.columns)}"
                )
            
            # Apply filter based on operator
            pre_filter_count = len(filtered_df)
            
            if op == '==':
                filtered_df = filtered_df[filtered_df[col] == val]
            elif op == '>':
                filtered_df = filtered_df[filtered_df[col] > val]
            elif op == '<':
                filtered_df = filtered_df[filtered_df[col] < val]
            elif op == '>=':
                filtered_df = filtered_df[filtered_df[col] >= val]
            elif op == '<=':
                filtered_df = filtered_df[filtered_df[col] <= val]
            elif op == '!=':
                filtered_df = filtered_df[filtered_df[col] != val]
            else:
                raise ToolExecutionError(
                    "filter_data", 
                    f"Unsupported operator: '{op}'. Supported operators: ==, >, <, >=, <=, !="
                )
            
            # Track how many rows were filtered in this step
            post_filter_count = len(filtered_df)
            rows_filtered = pre_filter_count - post_filter_count
            
            filter_steps.append({
                'step': i + 1,
                'column': col,
                'operator': op,
                'value': val,
                'rows_before': pre_filter_count,
                'rows_after': post_filter_count,
                'rows_filtered': rows_filtered,
                'percentage_filtered': round((rows_filtered / pre_filter_count * 100), 2) if pre_filter_count > 0 else 0
            })
        
        # Prepare result with metadata
        result = {
            'result_df': filtered_df,
            'message': f"Data filtered successfully. {original_row_count - len(filtered_df)} rows were filtered out.",
            'metadata': {
                'original_rows': original_row_count,
                'filtered_rows': len(filtered_df),
                'rows_removed': original_row_count - len(filtered_df),
                'percentage_removed': round(((original_row_count - len(filtered_df)) / original_row_count * 100), 2) if original_row_count > 0 else 0,
                'filter_criteria': filter_criteria,
                'filter_steps': filter_steps
            }
        }
        
        return result
        
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
            
        # Otherwise wrap it
        raise ToolExecutionError("filter_data", str(e)) 