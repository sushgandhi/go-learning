import uvicorn
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Run the app with uvicorn
if __name__ == "__main__":
    # Get port from environment or use default
    port = int(os.getenv("PORT", "8000"))
    
    # Get host from environment or use default
    host = os.getenv("HOST", "0.0.0.0")
    
    # Run the server
    print(f"Starting AI Data Agent API on {host}:{port}")
    uvicorn.run("app.api.main:app", host=host, port=port, reload=True) 