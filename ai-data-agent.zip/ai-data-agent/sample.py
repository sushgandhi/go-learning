import google.generativeai as genai
import pandas as pd
import os
from typing import List, Dict, Any

''''
This example shows the fundamental loop: User -> LLM (plans/calls tool) -> Orchestrator (executes tool) -> Tool (runs code) -> Orchestrator (gets result) -> LLM (gets result/interprets/responds) -> User. This pattern is scalable as you add more tools to the Tooling Layer and their corresponding definitions to the Gemini Tool Definition.
'''
# --- 1. Mock Data Management Layer ---
# In a real app, this would load/store data
current_dataframe = pd.DataFrame({
    'OrderID': [1, 2, 3, 4, 5, 6, 7, 8],
    'Category': ['Electronics', 'Clothing', 'Electronics', 'Footwear', 'Electronics', 'Clothing', 'Electronics', 'Footwear'],
    'Sales': [1200, 300, 800, 150, 2500, 450, 1500, 200],
    'Region': ['North', 'South', 'East', 'West', 'North', 'East', 'South', 'West']
})

# --- 2. Tooling Layer (filter_data function) ---
def filter_data(df: pd.DataFrame, filter_criteria: List[Dict[str, Any]]) -> pd.DataFrame:
    """
    Filters a pandas DataFrame based on multiple criteria.

    Args:
        df: The input pandas DataFrame.
        filter_criteria: A list of dictionaries, where each dictionary
                         specifies a column, operator (==, >, <, >=, <=, !=),
                         and value for filtering.
                         Example: [{'column': 'Sales', 'operator': '>', 'value': 1000}]

    Returns:
        A new DataFrame containing only the rows that match all criteria.
    """
    print(f"\n--- Tool Call: filter_data ---")
    print(f"Input DataFrame shape: {df.shape}")
    print(f"Filter Criteria: {filter_criteria}")

    filtered_df = df.copy()
    try:
        for criterion in filter_criteria:
            col = criterion['column']
            op = criterion['operator']
            val = criterion['value']

            if col not in filtered_df.columns:
                raise ValueError(f"Column '{col}' not found in DataFrame.")

            # Simple operator mapping - expand for more robust handling
            if op == '==':
                filtered_df = filtered_df[filtered_df[col] == val]
            elif op == '>':
                filtered_df = filtered_df[filtered_df[col] > val]
            elif op == '<':
                filtered_df = filtered_df[filtered_df[col] < val]
            elif op == '>=':
                filtered_df = filtered_df[filtered_df[col] >= val]
            elif op == '<=':
                filtered_df = filtered_df[filtered_df[col] <= val]
            elif op == '!=':
                filtered_df = filtered_df[filtered_df[col] != val]
            else:
                raise ValueError(f"Unsupported operator: {op}")

        print(f"Output DataFrame shape: {filtered_df.shape}")
        print("--- Tool Call End ---")
        return filtered_df

    except Exception as e:
        print(f"Error during tool execution: {e}")
        print("--- Tool Call End (Error) ---")
        # In a real system, you'd structure the error response for the LLM
        raise # Re-raise the exception for the orchestrator to catch and report back

# --- 3. Gemini Tool Definition ---
# This tells Gemini about the filter_data function
filter_data_tool = genai.protos.Tool(
    function_declarations=[
        genai.protos.FunctionDeclaration(
            name='filter_data',
            description='Filters a pandas DataFrame based on multiple criteria.',
            parameters=genai.protos.Schema(
                type=genai.protos.Schema.Type.OBJECT,
                properties={
                    'filter_criteria': genai.protos.Schema(
                        type=genai.protos.Schema.Type.ARRAY,
                        description='A list of filter criteria dictionaries.',
                        items=genai.protos.Schema(
                            type=genai.protos.Schema.Type.OBJECT,
                            description='A single filter criterion.',
                            properties={
                                'column': genai.protos.Schema(
                                    type=genai.protos.Schema.Type.STRING,
                                    description='The name of the column to filter.'
                                ),
                                'operator': genai.protos.Schema(
                                    type=genai.protos.Schema.Type.STRING,
                                    description='The comparison operator (e.g., ==, >, <, >=, <=, !=).'
                                ),
                                'value': genai.protos.Schema(
                                    # Using Any allows for different data types (string, number)
                                    type=genai.protos.Schema.Type.STRING, # LLMs often return values as strings
                                    description='The value to compare against.'
                                )
                            },
                            required=['column', 'operator', 'value']
                        )
                    )
                },
                required=['filter_criteria']
            )
        )
    ]
)

# --- 4. Agent Core (Gemini Interaction) & Execution Orchestrator ---

# Configure Gemini API key
API_KEY = os.getenv("GEMINI_API_KEY")
if not API_KEY:
    raise ValueError("Please set the GEMINI_API_KEY environment variable.")
genai.configure(api_key=API_KEY)

# Initialize the model with tool calling enabled
model = genai.GenerativeModel('gemini-1.5-flash-latest', tools=[filter_data_tool]) # Or 'gemini-1.5-pro-latest'
chat = model.start_chat()

# Simulate the user interaction
user_query = "Filter the data to only include rows where the 'Category' is 'Electronics' and 'Sales' are greater than 500."

print(f"User: {user_query}")

# Send the user message to Gemini
response = chat.send_message(user_query)

# Check if Gemini wants to call a tool
if response.tool_calls:
    print("\nGemini wants to call a tool:")
    tool_call = response.tool_calls[0] # Assuming one tool call for this example
    print(tool_call)

    # --- Execution Orchestrator Part ---
    # Extract tool details
    tool_name = tool_call.function.name
    tool_args = tool_call.function.args # These are passed as a dictionary

    # Check if the requested tool exists (simple lookup here)
    if tool_name == 'filter_data':
        try:
            # Call the actual Python function
            # In a real system, we'd manage which DataFrame 'df' refers to
            # Here, we pass the global dummy DataFrame for demonstration
            filtered_result_df = filter_data(df=current_dataframe, **tool_args)

            # Prepare the tool response to send back to Gemini
            # We return information about the result, not the whole DataFrame
            tool_response_content = {
                "success": True,
                "resulting_rows": filtered_result_df.shape[0],
                "message": "Data filtered successfully."
            }

            print("\nSending tool response back to Gemini:")
            print(tool_response_content)

            # Send the tool response back to the model
            final_response = chat.send_message(
                genai.protos.ToolFunctionResponse(
                    name=tool_name,
                    response=tool_response_content
                )
            )

            # Now Gemini should generate the final natural language response
            print("\nGemini's final response:")
            print(final_response.text)

        except Exception as e:
             # Handle errors during tool execution and report back to Gemini
             error_response_content = {
                "success": False,
                "error": str(e),
                "message": "An error occurred during filtering."
             }
             print("\nSending tool error response back to Gemini:")
             print(error_response_content)
             error_response = chat.send_message(
                 genai.protos.ToolFunctionResponse(
                    name=tool_name,
                    response=error_response_content
                 )
             )
             print("\nGemini's response to error:")
             print(error_response.text)


    else:
        # Handle case where Gemini requested a tool that doesn't exist in the orchestrator
        print(f"Error: Gemini requested unknown tool '{tool_name}'")
        # Send an error response back to Gemini

else:
    # Gemini did not request a tool call, it might have misunderstood or responded directly
    print("\nGemini did not request a tool call.")
    print("Gemini's direct response:")
    print(response.text)