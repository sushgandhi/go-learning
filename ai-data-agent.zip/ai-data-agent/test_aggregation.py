import pandas as pd
from app.tools.aggregation import group_and_aggregate

# Create a sample dataframe
data = {
    'Product': ['A', 'B', 'A', 'C', 'B', 'A'],
    'Region': ['North', 'South', 'North', 'East', 'South', 'West'],
    'Sales': [100, 200, 150, 300, 250, 175],
    'Quantity': [10, 20, 15, 30, 25, 17]
}

df = pd.DataFrame(data)
print("Original DataFrame:")
print(df)
print("\n")

# Test global aggregation (empty group_by_cols)
print("Testing global aggregation (empty group_by_cols):")
try:
    result = group_and_aggregate(
        df=df,
        group_by_cols=[],
        agg_definitions=[
            {"column": "Sales", "function": "sum", "new_column_name": "Total Sales"},
            {"column": "Quantity", "function": "sum", "new_column_name": "Total Quantity"}
        ]
    )
    
    print("Success! Result:")
    print(result['result_df'])
    print("\nMessage:", result['message'])
    print("\nMetadata:", result['metadata'])
except Exception as e:
    print("Error:", str(e))

# Test grouped aggregation (with group_by_cols)
print("\nTesting grouped aggregation (with group_by_cols):")
try:
    result = group_and_aggregate(
        df=df,
        group_by_cols=["Region"],
        agg_definitions=[
            {"column": "Sales", "function": "sum", "new_column_name": "Total Sales"},
            {"column": "Quantity", "function": "mean", "new_column_name": "Avg Quantity"}
        ]
    )
    
    print("Success! Result:")
    print(result['result_df'])
    print("\nMessage:", result['message'])
    print("\nMetadata:", result['metadata'])
except Exception as e:
    print("Error:", str(e))

# Test with case-insensitive column matching
print("\nTesting case-insensitive column matching:")
try:
    result = group_and_aggregate(
        df=df,
        group_by_cols=[],
        agg_definitions=[
            {"column": "sales", "function": "sum", "new_column_name": "Total Sales"},  # lowercase
            {"column": "quantity", "function": "sum", "new_column_name": "Total Quantity"}  # lowercase
        ]
    )
    
    print("Success! Result:")
    print(result['result_df'])
    print("\nMessage:", result['message'])
except Exception as e:
    print("Error:", str(e)) 