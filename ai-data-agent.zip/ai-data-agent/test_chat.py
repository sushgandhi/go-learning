import requests
import json
import os
import argparse

def main():
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Test AI Data Agent Chat API')
    parser.add_argument('--session_id', required=True, help='Session ID to use')
    parser.add_argument('--message', required=True, help='Message to send')
    parser.add_argument('--url', default='http://localhost:8000', help='Base URL for the API')
    args = parser.parse_args()
    
    # Set up the request
    url = f"{args.url}/chat"
    headers = {
        'Content-Type': 'application/json'
    }
    data = {
        'session_id': args.session_id,
        'message': args.message
    }
    
    try:
        # Send the request
        print(f"Sending request to {url}...")
        response = requests.post(url, headers=headers, data=json.dumps(data))
        
        # Check if there was an error
        if response.status_code != 200:
            print(f"Error: {response.status_code}")
            print(response.text)
            return
        
        # Parse the response
        result = response.json()
        
        # Print the response
        print("\n" + "-" * 80)
        print("RESPONSE:")
        print("-" * 80)
        print(result.get('response', 'No response'))
        
        # Check if there's a data table
        if result.get('data_table'):
            print("\n" + "-" * 80)
            print("DATA TABLE:")
            print("-" * 80)
            print(json.dumps(result['data_table'], indent=2))
        
        # Check if there's a plot
        if result.get('plot_url'):
            print("\n" + "-" * 80)
            print("PLOT URL:")
            print("-" * 80)
            print(result['plot_url'])
        
        # Check if there's an error
        if result.get('error'):
            print("\n" + "-" * 80)
            print("ERROR:")
            print("-" * 80)
            print(result['error'])
            
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    main() 