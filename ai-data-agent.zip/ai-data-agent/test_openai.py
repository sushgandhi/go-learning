import os
import sys
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Add the current directory to the path so we can import from app
sys.path.append(os.getcwd())

from app.data.dataframe_manager import DataFrameManager
from app.data.state_manager import StateManager
from app.agent.openai_connector import OpenAIConnector
from app.agent.tool_schemas_openai import get_tool_schemas_openai
from app.utils.logging import log_info, log_error

def test_openai_connector():
    """
    Test the OpenAI connector with the correct tool schemas
    """
    print("Testing OpenAI connector...")
    
    # Create a DataFrameManager and StateManager
    df_manager = DataFrameManager()
    state_manager = StateManager()
    
    # Create an OpenAI connector
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("Error: OPENAI_API_KEY environment variable not found")
        return
    
    openai_connector = OpenAIConnector(api_key=api_key)
    
    # Get tool schemas
    tools = get_tool_schemas_openai()
    
    # Print the first tool schema to verify structure
    print(f"Tool schema structure (first tool):")
    print(tools[0])
    
    # Create a session
    session_id = df_manager.create_session()
    
    # Add some context to the conversation
    state_manager.add_message(session_id, 'system', "You are a helpful data analysis assistant.")
    
    # Test the get_tool_response method
    try:
        user_message = "Summarize the data in my dataset."
        print(f"Sending message: {user_message}")
        
        response = openai_connector.get_tool_response(
            session_id=session_id,
            user_message=user_message,
            conversation_history=state_manager.get_conversation(session_id),
            tools=tools
        )
        
        print("Response from OpenAI:")
        print(response)
        
        if response.get('has_tool_call', False):
            print(f"Tool call detected: {response['tool_name']}")
            print(f"Tool args: {response['tool_args']}")
        else:
            print(f"Regular response: {response['text']}")
            
        print("Test completed successfully!")
        
    except Exception as e:
        print(f"Error: {str(e)}")

if __name__ == "__main__":
    test_openai_connector() 