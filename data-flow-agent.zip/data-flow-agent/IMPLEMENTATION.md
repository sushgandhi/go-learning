# Implementation Details

## System Architecture

### Core Components

#### 1. `DataContext`
Manages the current state of data being analyzed.
- Loads and stores DataFrames from CSV/Excel files
- Tracks changes to data through analysis operations
- Maintains data metadata (column types, statistics, etc.)

#### 2. `AgentManager`
Coordinates the AI agent interactions with the LLM.
- Initializes the LLM client
- Manages the system prompt and tool definitions
- Processes user queries and routes them to the LLM
- Parses LLM responses and function calls

#### 3. `ToolExecutor`
Executes tools based on LLM function calls.
- Validates tool inputs
- Executes the requested tool
- Formats tool responses
- Handles tool errors

#### 4. `ConversationManager`
Manages the conversation history.
- Stores user queries and system responses
- Provides context for the LLM
- Enables multi-turn conversations

#### 5. `ApplicationManager`
Top-level component that orchestrates the system.
- Initializes all components
- Handles CLI arguments
- Manages the application lifecycle
- Implements the main interaction loop

### Modules and Functions

#### Core Modules

1. **main.py**
   - Entry point for the application
   - CLI argument parsing
   - Application initialization

2. **data_flow_agent/__init__.py**
   - Package initialization
   - Version information
   - Public API exports

3. **data_flow_agent/agent.py**
   - `AgentManager` class
   - LLM initialization
   - Function calling logic

4. **data_flow_agent/data.py**
   - `DataContext` class
   - Data loading and manipulation
   - DataFrame management

5. **data_flow_agent/tools.py**
   - `ToolExecutor` class
   - Tool registration
   - Tool execution logic

6. **data_flow_agent/conversation.py**
   - `ConversationManager` class
   - History tracking
   - Context management

7. **data_flow_agent/application.py**
   - `ApplicationManager` class
   - Configuration
   - Application lifecycle

#### Tool Implementations

1. **tools/filtering.py**
   - Filter data based on conditions
   - Column-based filtering
   - Complex filtering with multiple criteria

2. **tools/aggregation.py**
   - Group data by columns
   - Perform aggregations (sum, avg, etc.)
   - Create pivot tables

3. **tools/visualization.py**
   - Generate various chart types
   - Customize visualization properties
   - Save visualization outputs

4. **tools/comparison.py**
   - Compare columns within a dataset
   - Compare data across files
   - Statistical comparison utilities

5. **tools/summarization.py**
   - Column summarization
   - Row summarization
   - Sheet and workbook summarization

6. **tools/data_loading.py**
   - File loading utilities
   - Data type detection
   - Initial data cleaning

#### Utility Modules

1. **utils/exceptions.py**
   - Custom exception classes
   - Error handling utilities

2. **utils/logging.py**
   - Logging configuration
   - Log formatting

3. **utils/helpers.py**
   - Shared utility functions
   - Type conversions
   - Output formatting

## Class Structures

### `DataContext` Class
```python
class DataContext:
    def __init__(self):
        self.current_df = None
        self.dataframes = {}
        self.current_file_path = None
        self.metadata = {}
        
    def load_file(self, file_path, sheet_name=None):
        # Load file and store DataFrame
        
    def get_current_df(self):
        # Return current DataFrame
        
    def update_df(self, df, operation=None):
        # Update current DataFrame and track operation
        
    def get_metadata(self):
        # Return metadata about current data
```

### `AgentManager` Class
```python
class AgentManager:
    def __init__(self, config=None):
        self.client = None
        self.model_name = None
        self.system_instruction = None
        self.tools = []
        
    def initialize_client(self):
        # Initialize LLM client
        
    def register_tools(self, tools):
        # Register tools with the agent
        
    def process_query(self, query, context=None):
        # Process user query with LLM
        
    def execute_function_call(self, function_call, data_context):
        # Execute function call from LLM
```

### `ToolExecutor` Class
```python
class ToolExecutor:
    def __init__(self, data_context):
        self.data_context = data_context
        self.registered_tools = {}
        
    def register_tool(self, tool_func):
        # Register a tool
        
    def execute_tool(self, tool_name, tool_args):
        # Execute a tool with given arguments
        
    def format_response(self, tool_result):
        # Format tool execution result
```

### `ConversationManager` Class
```python
class ConversationManager:
    def __init__(self, max_history=10):
        self.history = []
        self.max_history = max_history
        
    def add_interaction(self, user_query, system_response):
        # Add interaction to history
        
    def get_recent_history(self, n=None):
        # Get recent conversation history
        
    def clear_history(self):
        # Clear conversation history
```

### `ApplicationManager` Class
```python
class ApplicationManager:
    def __init__(self, config=None):
        self.agent_manager = None
        self.data_context = None
        self.tool_executor = None
        self.conversation_manager = None
        self.config = config or {}
        
    def initialize(self):
        # Initialize application components
        
    def run_interactive(self):
        # Run in interactive mode
        
    def process_single_query(self, query, file_path=None):
        # Process a single query
        
    def shutdown(self):
        # Clean up resources
``` 