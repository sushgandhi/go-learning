# Data Flow Agent

Data Flow Agent is an AI-powered data analysis system that allows non-technical users to analyze CSV and Excel data using natural language queries.

## Features

- Natural language interface for data analysis
- Support for CSV and Excel files
- Various data analysis capabilities:
  - Filtering and grouping data
  - Creating visualizations
  - Generating pivot tables
  - Comparing columns
  - Summarizing data
- Interactive command-line interface
- RESTful API interface
- ChatGPT-like web interface
- Modular and extensible architecture

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/data-flow-agent.git
cd data-flow-agent

# Install dependencies for the backend
pip install -r requirements.txt

# Install dependencies for the frontend
cd frontend
npm install
cd ..
```

## Usage

### Running the Backend API

```bash
# From the root directory
uvicorn api:app --reload
```

The API will be available at http://localhost:8000, and the API documentation at http://localhost:8000/docs.

### Running the Frontend

```bash
# From the frontend directory
cd frontend
npm start
```

The frontend will be available at http://localhost:3000.

### Command Line Interface

The Data Flow Agent can also be used via the command line in both interactive and non-interactive modes.

#### Interactive Mode

```bash
python main.py -i
```

In interactive mode, you can:
- Load a file: `load path/to/your/file.csv`
- Ask questions about your data: `What's the total sales by region?`
- Exit the application: `exit` or `quit`

#### Single Query Mode

```bash
python main.py -f path/to/your/file.csv -q "What's the total sales by region?"
```

#### Command Line Options

```
usage: main.py [-h] [-f FILE] [-s SHEET] [-q QUERY] [-c CONFIG] [-i]
               [-o {text,json}] [--debug]

Data Flow Agent - AI-powered data analysis system

options:
  -h, --help            show this help message and exit
  -f FILE, --file FILE  Path to the data file (CSV or Excel)
  -s SHEET, --sheet SHEET
                        Sheet name for Excel files
  -q QUERY, --query QUERY
                        Natural language query to execute. If provided, runs in
                        non-interactive mode.
  -c CONFIG, --config CONFIG
                        Path to configuration file
  -i, --interactive     Run in interactive mode (default if no query is
                        provided)
  -o {text,json}, --output {text,json}
                        Output format (text, json)
  --debug               Enable debug mode
```

### API Interface

The Data Flow Agent's RESTful API provides endpoints for:

- **POST /query**: Process a natural language query on a data file
  ```json
  {
    "query": "What is the total sales by region?",
    "file_path": "/path/to/your/data.csv",
    "sheet_name": null
  }
  ```

- **GET /metadata**: Get metadata about the currently loaded data

- **GET /health**: Health check endpoint

### Web Interface

The web interface provides a ChatGPT-like experience for interacting with your data:

1. Upload a CSV or Excel file using the sidebar
2. Ask questions about your data in natural language
3. View the results in the chat interface, including tables and visualizations

### Examples

#### Load a CSV file and analyze it

```bash
python main.py -f sample.csv -i
```

#### Ask a specific question about your data

```bash
python main.py -f sample.csv -q "Show me a bar chart of sales by region"
```

#### Use the API directly

```bash
curl -X POST "http://localhost:8000/query" \
     -H "Content-Type: application/json" \
     -d '{"query":"Show total sales by region", "file_path":"/path/to/your/data.csv"}'
```

## Configuration

The Data Flow Agent can be configured using environment variables:

- `MODEL_NAME`: Name of the LLM model to use (default: "gemini-2.5-pro")
- `BASE_URL`: Base URL for the LLM API
- `VERTEX_PROJECT_ID`: Project ID for Google Vertex AI
- `VERTEX_PROJECT_LOCATION`: Location for Google Vertex AI

## Project Structure

```
data-flow-agent/
├── data_flow_agent/      # Core package
│   ├── __init__.py
│   ├── agent.py          # LLM integration
│   ├── application.py    # Main application orchestration
│   ├── conversation.py   # Conversation management
│   ├── data.py           # Data context handling
│   └── tools.py          # Tool execution
├── tools/                # Analysis tools
│   ├── aggregation.py
│   ├── comparison.py
│   ├── data_loading.py
│   ├── filtering.py
│   ├── summarization.py
│   └── visualization.py
├── utils/                # Utility functions
│   ├── exceptions.py
│   ├── helpers.py
│   └── logging.py
├── frontend/             # Web interface
│   ├── index.html        # Main page
│   ├── styles.css        # Styling
│   ├── app.js            # Frontend logic
│   └── server.js         # Static file server
├── api.py                # FastAPI application
├── main.py               # CLI entry point
└── sample.csv            # Sample data file
```

## Extending the System

The Data Flow Agent is designed to be modular and extensible. You can add new tools by:

1. Creating a new function in the `tools/` directory
2. Registering the tool in `data_flow_agent/application.py`

## License

[MIT License](LICENSE)

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request. 