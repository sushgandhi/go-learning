# Understanding the Problem

## Overview
We are building a Data-AI Agent system that allows non-technical users to analyze data from Excel/CSV files using natural language queries. The system will act as an "AI data analyst" that can understand user requests in natural language and execute appropriate data analysis tools to fulfill those requests.

## Key Components
1. **Command Line Interface**: The initial interface for the system, with potential to expose it as an API later.
2. **AI Agent**: The core component that interprets user queries and selects appropriate tools to analyze data.
3. **Tools**: A collection of data analysis tools that perform specific operations like filtering, visualization, and summarization.
4. **LLM Integration**: The system uses Google's Gemini 2.5 Pro model for understanding user queries and function calling.

## Data Flow
1. User provides a natural language query about their data
2. AI agent interprets the query and selects appropriate tools to analyze the data
3. Selected tools are executed on the data
4. Results are returned to the user

## External Dependencies
- **Google Gemini API**: For natural language understanding and function calling
- **Pandas**: For data manipulation
- **Matplotlib/Seaborn**: For data visualization

## Tool Capabilities
The system should provide the following data analysis capabilities:
1. Filtering and grouping data
2. Creating various types of visualizations
3. Pivoting data tables
4. Comparing columns and files
5. Summarizing columns, rows, sheets, and entire workbooks

## Architecture Goals
- Modular and extensible code structure
- Ability to function as both a standalone application and a library
- Potential to expose functionality as an API 