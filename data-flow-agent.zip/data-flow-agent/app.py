import os
from getpass import getpass
import requests
import json
import pandas as pd
import subprocess
import datemath
from typing import Dict, List, Any

from google import genai
from google.oauth2.credentials import Credentials
from google.genai.types import HttpOptions
from google.genai.types import Tool, GoogleSearch
from google.genai.types import GenerateContentConfig
from google.genai import types
from pydantic import BaseModel


from tools.aggregation import group_and_aggregate, create_pivot_table
from tools.visualization import visualize_data  
from tools.filtering import filter_data

os.environ["SSL_CERT_FILE"] = ""
os.environ["REQUESTS_ CA_ BUNDLE"] = ""
os.environ["client id"] = ""
os.environ["client_secret"] = ""
os.environ["M2M GRANT TYPE"] = ""
os.environ["M2M SCOPE"] = ""
os.environ["RUN MODE"] = "local"


BASE_URL_VERTEX = ""
VERTEX_PROJECT_ID = ""
VERTEX_PROJECT_LOCATION = ""
model_name = "gemini-2.5-pro"

tool_selection_guide = """You are a data analysis assistant that helps users analyze their data. 
Your job is to select the most appropriate tool based on the user's request.

IMPORTANT TOOL SELECTION GUIDELINES:
1. For calculating sums, totals, averages, or any aggregation of data, ALWAYS use 'group_and_aggregate', not 'summarize_column' or 'summarize_sheet'.
   - For global aggregations (e.g., "total sales"), use 'group_and_aggregate' with empty group_by_cols: []
   - For grouped aggregations (e.g., "sales by region"), use 'group_and_aggregate' with group_by_cols: ["region"]
2. For understanding data structure and general statistics, use 'summarize_sheet'.
3. For detailed analysis of a specific column, use 'summarize_column'.
4. For filtering data, use 'filter_data'.
5. For creating charts, use 'visualize_data'.
6. For comparing two columns, use 'compare_columns'.
7. For looking at pivot views of data, use 'create_pivot_table'.

EXAMPLES:
- "What is the sum of sales?" → Use 'group_and_aggregate' with empty group_by_cols: [] and agg_definitions: [{"column": "sales", "function": "sum", "new_column_name": "Total Sales"}]
- "Show me total revenue by region" → Use 'group_and_aggregate' with group_by_cols: ["region"], agg_definitions: [{"column": "revenue", "function": "sum", "new_column_name": "Total Revenue"}]
- "Average price by category" → Use 'group_and_aggregate' with group_by_cols: ["category"], agg_definitions: [{"column": "price", "function": "mean", "new_column_name": "Average Price"}]
- "Tell me about the sales column" → Use 'summarize_column' with column: "sales"
- "What does my data look like?" → Use 'summarize_sheet'
- "Show me a histogram of ages" → Use 'visualize_data' with plot_type: "histogram", x: "age"
- "Compare price and rating" → Use 'compare_columns' with col1: "price", col2: "rating"

MOST IMPORTANT: Pay close attention to whether the user wants to calculate a value (sum, average, etc.) or just understand column statistics. For calculations, use group_and_aggregate."""


def get_m2m_token():
    return "token"

def get_h2m_token():
    return "token"

def _refresh_token():
    if os.getenv("RUN MODE") == "local":
        return get_h2m_token()
    else:
        return get_m2m_token()
    
def _initialize_client():
    credentials = None
    try:
        credentials = Credentials(_refresh_token())
        client  = genai.Client(
            http_options = HttpOptions(
                base_url = BASE_URL_VERTEX,
                api_key = credentials,
                project_id = VERTEX_PROJECT_ID,
                vertexai = True,
                location = VERTEX_PROJECT_LOCATION,
            )
        )
        return credentials, client
    except Exception as e:
        print(f"Error initializing client: {e}")
        return None, None
    
config = GenerateContentConfig(
    system_instruction = tool_selection_guide,
    tools = [filter_data, group_and_aggregate, create_pivot_table, visualize_data],
    automatic_function_calling = {"disable": True}
)


def call_function(function_name, functions):
    function_name = function_name.name
    function_args = function_call.args
    for func in functions:
        if func.__name__ == function_name:
            return func(**function_args)

user_content = '''
Query :
------------

Can you please share a plot of sales per region?

Instructions :
--------------

Please use best match of user query to columns in the data.

Context:
the data definition is as follows:

{'OrderID': dtype('int64'), 
'Category': dtype('O'), 
'Sales': dtype('int64'), 
'Region': dtype('O'),
 'Date': dtype('O')}

 -----------

 The data_path is as follows:
 /Users/sushant/Sushant/Projects/data-flow-agent/sample.csv

'''
credentials, client = _initialize_client()

r = client.generate_content(
    model = model_name,
    config = config,
    content= user_content,

)

for part in r.candidates[0].content.parts:
    print(part.function_call)

part = r.candidates[0].content.parts[0]

if part.function_call:
    result = call_function(part.function_call, [filter_data, group_and_aggregate, create_pivot_table, visualize_data])
    print(result)





