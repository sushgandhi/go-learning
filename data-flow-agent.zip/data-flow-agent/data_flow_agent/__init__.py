"""
Data Flow Agent - An AI-powered data analysis system.

This package provides tools and utilities for building AI-powered data analysis
applications that can understand natural language queries and execute appropriate
data operations.
"""

__version__ = "0.1.0"

# Public API exports
from data_flow_agent.application import ApplicationManager
from data_flow_agent.agent import AgentManager
from data_flow_agent.data import DataContext
from data_flow_agent.tools import ToolExecutor
from data_flow_agent.conversation import ConversationManager 