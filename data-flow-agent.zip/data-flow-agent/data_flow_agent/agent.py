"""
AgentManager module for handling LLM interactions in the Data Flow Agent.

This module provides the AgentManager class which is responsible for initializing
the LLM client, managing prompts, and handling function calling.
"""

import os
import json
from typing import Dict, List, Any, Optional, Callable, Union

from google import genai
from google.oauth2.credentials import Credentials
from google.genai.types import HttpOptions
from google.genai.types import GenerateContentConfig
from pydantic import BaseModel

from utils.exceptions import LLMError, ToolExecutionError

class AgentManager:
    """
    Coordinates the AI agent interactions with the LLM.
    
    The AgentManager is responsible for:
    - Initializing the LLM client
    - Managing the system prompt and tool definitions
    - Processing user queries and routing them to the LLM
    - Parsing LLM responses and function calls
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the AgentManager.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.client = None
        self.model_name = self.config.get('model_name', 'gemini-2.5-pro')
        self.system_instruction = None
        self.tools = []
        self.tools_dict = {}
        
    def initialize_client(self):
        """
        Initialize the LLM client.
        
        This method sets up the connection to the LLM service.
        
        Returns:
            True if initialization was successful, False otherwise
            
        Raises:
            LLMError: If client initialization fails
        """
        try:
            # Get token using the existing mechanism from app.py
            def get_token():
                if os.getenv("RUN_MODE") == "local":
                    return self._get_h2m_token()
                else:
                    return self._get_m2m_token()
            
            credentials = Credentials(get_token())
            
            # Set up client with the configuration from the original implementation
            self.client = genai.Client(
                http_options=HttpOptions(
                    base_url=self.config.get('base_url', ''),
                    api_key=credentials,
                    project_id=self.config.get('project_id', ''),
                    vertexai=True,
                    location=self.config.get('location', ''),
                )
            )
            
            return True
            
        except Exception as e:
            raise LLMError(f"Error initializing client: {str(e)}")
            
    def _get_m2m_token(self):
        """Get machine-to-machine token."""
        # This implementation would depend on your authentication mechanism
        return self.config.get('m2m_token', 'token')
        
    def _get_h2m_token(self):
        """Get human-to-machine token."""
        # This implementation would depend on your authentication mechanism
        return self.config.get('h2m_token', 'token')
        
    def set_system_instruction(self, instruction: str):
        """
        Set the system instruction for the LLM.
        
        Args:
            instruction: The system instruction to use
        """
        self.system_instruction = instruction
        
    def register_tools(self, tools: List[Callable]):
        """
        Register tools with the agent.
        
        Args:
            tools: List of tool functions to register
        """
        self.tools = tools
        
        # Create a dictionary of tools for easy lookup
        self.tools_dict = {tool.__name__: tool for tool in tools}
        
    def process_query(self, 
                      query: str, 
                      data_context: Optional[Dict[str, Any]] = None, 
                      conversation_history: Optional[List[Dict[str, Any]]] = None) -> Dict[str, Any]:
        """
        Process a user query with the LLM.
        
        Args:
            query: The user's natural language query
            data_context: Optional context about the current data
            conversation_history: Optional conversation history
            
        Returns:
            Dictionary containing the LLM response and any function calls
            
        Raises:
            LLMError: If the LLM request fails
        """
        if not self.client:
            raise LLMError("LLM client not initialized")
            
        try:
            # Format the query with data context if provided
            formatted_query = self._format_query(query, data_context)
            
            # Create the generate content config
            config = GenerateContentConfig(
                system_instruction=self.system_instruction,
                tools=self.tools,
                automatic_function_calling={"disable": True}
            )
            
            # Call the LLM
            response = self.client.generate_content(
                model=self.model_name,
                config=config,
                content=formatted_query,
            )
            
            # Process the response
            return self._process_response(response)
            
        except Exception as e:
            raise LLMError(f"Error processing query: {str(e)}")
            
    def _format_query(self, query: str, data_context: Optional[Dict[str, Any]] = None) -> str:
        """
        Format the query with data context.
        
        Args:
            query: The user's natural language query
            data_context: Optional context about the current data
            
        Returns:
            Formatted query string
        """
        # Basic format from the original implementation
        formatted_query = f"Query :\n------------\n\n{query}\n\n"
        
        # Add instructions
        formatted_query += "Instructions :\n--------------\n\n"
        formatted_query += "Please use best match of user query to columns in the data.\n\n"
        
        # Add data context if provided
        if data_context:
            formatted_query += "Context:\n"
            
            # Add data definition if available
            if 'column_dtypes' in data_context:
                formatted_query += "the data definition is as follows:\n\n"
                formatted_query += str(data_context['column_dtypes'])
                formatted_query += "\n\n"
            
            # Add file path if available
            if 'file_path' in data_context:
                formatted_query += " -----------\n\n"
                formatted_query += f" The data_path is as follows:\n {data_context['file_path']}\n\n"
                
        return formatted_query
        
    def _process_response(self, response: Any) -> Dict[str, Any]:
        """
        Process the LLM response.
        
        Args:
            response: The raw LLM response
            
        Returns:
            Dictionary containing the processed response
        """
        try:
            # Extract function call from the response
            part = response.candidates[0].content.parts[0]
            
            if part.function_call:
                function_call = {
                    'name': part.function_call.name,
                    'args': part.function_call.args,
                }
                
                return {
                    'type': 'function_call',
                    'function_call': function_call
                }
            else:
                # Text response
                return {
                    'type': 'text',
                    'content': response.candidates[0].content.text
                }
                
        except Exception as e:
            raise LLMError(f"Error processing LLM response: {str(e)}")
            
    def execute_function_call(self, function_call: Dict[str, Any], data_context: Any) -> Dict[str, Any]:
        """
        Execute a function call returned by the LLM.
        
        Args:
            function_call: The function call information
            data_context: DataContext instance
            
        Returns:
            Result of the function execution
            
        Raises:
            ToolExecutionError: If function execution fails
        """
        function_name = function_call['name']
        function_args = function_call['args']
        
        # Ensure the function exists
        if function_name not in self.tools_dict:
            raise ToolExecutionError(
                "execute_function_call", 
                f"Function '{function_name}' not found in registered tools"
            )
            
        try:
            # Get the function
            func = self.tools_dict[function_name]
            
            # If the function requires a data_location and it's not provided,
            # add the current file path from data_context
            if 'data_location' in func.__annotations__ and 'data_location' not in function_args:
                function_args['data_location'] = data_context.current_file_path
                
            # Execute the function
            result = func(**function_args)
            
            # Update the data context if the function returns a DataFrame
            if 'result_df' in result:
                data_context.update_df(
                    result['result_df'],
                    operation=function_name,
                    details={'args': function_args}
                )
                
            return {
                'success': True,
                'function_name': function_name,
                'result': result
            }
            
        except Exception as e:
            raise ToolExecutionError(
                "execute_function_call", 
                f"Error executing function '{function_name}': {str(e)}"
            ) 