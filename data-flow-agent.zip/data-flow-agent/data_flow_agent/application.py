"""
Application module for orchestrating components in the Data Flow Agent.

This module provides the ApplicationManager class which is responsible for initializing
and coordinating all components of the system.
"""

import os
import sys
from typing import Dict, List, Any, Optional, Tuple

from data_flow_agent.agent import AgentManager
from data_flow_agent.data import DataContext
from data_flow_agent.tools import ToolExecutor
from data_flow_agent.conversation import ConversationManager

# Import tools
from tools.filtering import filter_data
from tools.aggregation import group_and_aggregate, create_pivot_table
from tools.visualization import visualize_data
from tools.comparison import compare_columns
from tools.summarization import summarize_column, summarize_row, summarize_sheet

from utils.exceptions import DataAgentError, LLMError, ToolExecutionError
from utils.helpers import to_serializable_dict

class ApplicationManager:
    """
    Top-level component that orchestrates the system.
    
    The ApplicationManager is responsible for:
    - Initializing all components
    - Handling CLI arguments
    - Managing the application lifecycle
    - Implementing the main interaction loop
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the ApplicationManager.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.agent_manager = None
        self.data_context = None
        self.tool_executor = None
        self.conversation_manager = None
        
        # Tool selection guide from original implementation
        self.tool_selection_guide = """You are a data analysis assistant that helps users analyze their data. 
Your job is to select the most appropriate tool based on the user's request.

IMPORTANT TOOL SELECTION GUIDELINES:
1. For calculating sums, totals, averages, or any aggregation of data, ALWAYS use 'group_and_aggregate', not 'summarize_column' or 'summarize_sheet'.
   - For global aggregations (e.g., "total sales"), use 'group_and_aggregate' with empty group_by_cols: []
   - For grouped aggregations (e.g., "sales by region"), use 'group_and_aggregate' with group_by_cols: ["region"]
2. For understanding data structure and general statistics, use 'summarize_sheet'.
3. For detailed analysis of a specific column, use 'summarize_column'.
4. For filtering data, use 'filter_data'.
5. For creating charts, use 'visualize_data'.
6. For comparing two columns, use 'compare_columns'.
7. For looking at pivot views of data, use 'create_pivot_table'.

EXAMPLES:
- "What is the sum of sales?" → Use 'group_and_aggregate' with empty group_by_cols: [] and agg_definitions: [{"column": "sales", "function": "sum", "new_column_name": "Total Sales"}]
- "Show me total revenue by region" → Use 'group_and_aggregate' with group_by_cols: ["region"], agg_definitions: [{"column": "revenue", "function": "sum", "new_column_name": "Total Revenue"}]
- "Average price by category" → Use 'group_and_aggregate' with group_by_cols: ["category"], agg_definitions: [{"column": "price", "function": "mean", "new_column_name": "Average Price"}]
- "Tell me about the sales column" → Use 'summarize_column' with column: "sales"
- "What does my data look like?" → Use 'summarize_sheet'
- "Show me a histogram of ages" → Use 'visualize_data' with plot_type: "histogram", x: "age"
- "Compare price and rating" → Use 'compare_columns' with col1: "price", col2: "rating"

MOST IMPORTANT: Pay close attention to whether the user wants to calculate a value (sum, average, etc.) or just understand column statistics. For calculations, use group_and_aggregate."""
        
    def initialize(self):
        """
        Initialize application components.
        
        Returns:
            True if initialization was successful, False otherwise
        """
        try:
            # Initialize DataContext
            self.data_context = DataContext()
            
            # Initialize AgentManager
            agent_config = {
                'model_name': self.config.get('model_name', 'gemini-2.5-pro'),
                'base_url': self.config.get('base_url', ''),
                'project_id': self.config.get('project_id', ''),
                'location': self.config.get('location', ''),
                'm2m_token': self.config.get('m2m_token', ''),
                'h2m_token': self.config.get('h2m_token', '')
            }
            self.agent_manager = AgentManager(agent_config)
            self.agent_manager.initialize_client()
            self.agent_manager.set_system_instruction(self.tool_selection_guide)
            
            # Initialize ToolExecutor
            self.tool_executor = ToolExecutor(self.data_context)
            
            # Register tools
            tools = [
                filter_data,
                group_and_aggregate,
                create_pivot_table,
                visualize_data,
                compare_columns,
                summarize_column,
                summarize_row,
                summarize_sheet
            ]
            self.tool_executor.register_tools(tools)
            self.agent_manager.register_tools(tools)
            
            # Initialize ConversationManager
            self.conversation_manager = ConversationManager()
            
            return True
            
        except Exception as e:
            print(f"Error initializing application: {str(e)}")
            return False
            
    def load_data(self, file_path: str, sheet_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Load data from a file.
        
        Args:
            file_path: Path to the file to load
            sheet_name: For Excel files, name of the sheet to load
            
        Returns:
            Dictionary containing metadata about the loaded file
        """
        if not self.data_context:
            raise DataAgentError("Application not initialized")
            
        result = self.data_context.load_file(file_path, sheet_name)
        
        # Make the result serializable
        serializable_result = to_serializable_dict(result)
        
        return serializable_result
        
    def process_query(self, query: str) -> Dict[str, Any]:
        """
        Process a user query.
        
        Args:
            query: The user's natural language query
            
        Returns:
            Dictionary containing the result of processing the query
        """
        if not self.agent_manager or not self.data_context or not self.tool_executor:
            raise DataAgentError("Application not initialized")
            
        try:
            # Get data context for the query
            data_context_dict = self.data_context.get_metadata()
            
            # Process query with LLM
            llm_response = self.agent_manager.process_query(query, data_context_dict)
            
            # Handle function call response
            if llm_response.get('type') == 'function_call':
                function_call = llm_response.get('function_call', {})
                
                # Execute the function
                result = self.agent_manager.execute_function_call(function_call, self.data_context)
                
                # Add result to the response
                llm_response['result'] = result
                
            # Add interaction to conversation history
            self.conversation_manager.add_interaction(query, llm_response)
            
            # Make the response serializable
            serializable_response = to_serializable_dict(llm_response)
            
            return serializable_response
            
        except Exception as e:
            error_type = type(e).__name__
            error_message = str(e)
            
            error_response = {
                'type': 'error',
                'error_type': error_type,
                'error_message': error_message
            }
            
            # Add error to conversation history
            self.conversation_manager.add_user_message(query)
            self.conversation_manager.add_system_message(
                f"Error: {error_message}",
                {'error_type': error_type}
            )
            
            return error_response
            
    def run_interactive(self):
        """Run the application in interactive mode."""
        print("Data Flow Agent - Interactive Mode")
        print("Type 'exit' or 'quit' to exit, 'load <file_path>' to load a file.")
        
        while True:
            try:
                # Get user input
                user_input = input("\nQuery: ").strip()
                
                # Check for exit command
                if user_input.lower() in ['exit', 'quit']:
                    print("Exiting...")
                    break
                    
                # Check for load command
                if user_input.lower().startswith('load '):
                    file_path = user_input[5:].strip()
                    print(f"Loading file: {file_path}")
                    result = self.load_data(file_path)
                    print(f"File loaded: {result['message']}")
                    continue
                    
                # Process user query
                result = self.process_query(user_input)
                
                # Display result
                if result.get('type') == 'error':
                    print(f"Error: {result['error_message']}")
                elif result.get('type') == 'function_call':
                    function_result = result.get('result', {})
                    
                    if 'message' in function_result:
                        print(f"Result: {function_result['message']}")
                        
                    if 'plot_url' in function_result:
                        print(f"Plot generated: {function_result['plot_url']}")
                else:
                    print(f"Response: {result.get('content', '')}")
                    
            except KeyboardInterrupt:
                print("\nExiting...")
                break
            except Exception as e:
                print(f"Error: {str(e)}")
                
    def process_single_query(self, file_path: str, query: str) -> Dict[str, Any]:
        """
        Process a single query in non-interactive mode.
        
        Args:
            file_path: Path to the data file
            query: The user's natural language query
            
        Returns:
            Result of processing the query
        """
        try:
            # Load the file
            self.load_data(file_path)
            
            # Process the query
            return self.process_query(query)
            
        except Exception as e:
            return {
                'type': 'error',
                'error_type': type(e).__name__,
                'error_message': str(e)
            }
            
    def shutdown(self):
        """Clean up resources and shutdown."""
        # No cleanup needed for now
        pass 