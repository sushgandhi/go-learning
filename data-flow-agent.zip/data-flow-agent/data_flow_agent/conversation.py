"""
Conversation module for managing conversation history in the Data Flow Agent.

This module provides the ConversationManager class which is responsible for storing
and managing the conversation history between the user and the agent.
"""

from typing import Dict, List, Any, Optional, Tuple
import time
import json

class ConversationManager:
    """
    Manages the conversation history.
    
    The ConversationManager is responsible for:
    - Storing user queries and system responses
    - Providing context for the LLM
    - Enabling multi-turn conversations
    """
    
    def __init__(self, max_history: int = 10):
        """
        Initialize the ConversationManager.
        
        Args:
            max_history: Maximum number of interactions to keep in history
        """
        self.history = []
        self.max_history = max_history
        
    def add_user_message(self, message: str) -> None:
        """
        Add a user message to the conversation history.
        
        Args:
            message: The user's message
        """
        self.history.append({
            'role': 'user',
            'content': message,
            'timestamp': time.time()
        })
        
        # Trim history if it exceeds max length
        self._trim_history()
        
    def add_system_message(self, message: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """
        Add a system message to the conversation history.
        
        Args:
            message: The system's message
            metadata: Optional metadata about the message
        """
        entry = {
            'role': 'system',
            'content': message,
            'timestamp': time.time()
        }
        
        if metadata:
            entry['metadata'] = metadata
            
        self.history.append(entry)
        
        # Trim history if it exceeds max length
        self._trim_history()
        
    def add_tool_execution(self, tool_name: str, arguments: Dict[str, Any], result: Dict[str, Any]) -> None:
        """
        Add a tool execution to the conversation history.
        
        Args:
            tool_name: Name of the executed tool
            arguments: Arguments passed to the tool
            result: Result returned by the tool
        """
        self.history.append({
            'role': 'tool',
            'tool_name': tool_name,
            'arguments': arguments,
            'result': result,
            'timestamp': time.time()
        })
        
        # Trim history if it exceeds max length
        self._trim_history()
        
    def add_interaction(self, user_query: str, system_response: Dict[str, Any]) -> None:
        """
        Add a complete interaction to the conversation history.
        
        Args:
            user_query: The user's query
            system_response: The system's response
        """
        # Add user message
        self.add_user_message(user_query)
        
        # Add system response based on type
        if system_response.get('type') == 'function_call':
            # Add function call as tool execution
            function_call = system_response.get('function_call', {})
            self.add_tool_execution(
                function_call.get('name', 'unknown'),
                function_call.get('args', {}),
                system_response.get('result', {})
            )
        else:
            # Add text response as system message
            self.add_system_message(
                system_response.get('content', ''),
                system_response.get('metadata', {})
            )
            
    def get_recent_history(self, n: Optional[int] = None) -> List[Dict[str, Any]]:
        """
        Get the most recent conversation history.
        
        Args:
            n: Number of most recent interactions to retrieve (default: all)
            
        Returns:
            List of recent conversation history items
        """
        if n is None:
            return self.history
        return self.history[-n:]
    
    def get_formatted_history(self, n: Optional[int] = None) -> str:
        """
        Get a formatted string of the conversation history for display.
        
        Args:
            n: Number of most recent interactions to include (default: all)
            
        Returns:
            Formatted conversation history string
        """
        history = self.get_recent_history(n)
        formatted = []
        
        for item in history:
            if item['role'] == 'user':
                formatted.append(f"User: {item['content']}")
            elif item['role'] == 'system':
                formatted.append(f"System: {item['content']}")
            elif item['role'] == 'tool':
                formatted.append(f"Tool: {item['tool_name']}")
                formatted.append(f"  Arguments: {json.dumps(item['arguments'], indent=2)}")
                if 'message' in item['result']:
                    formatted.append(f"  Result: {item['result']['message']}")
                    
        return "\n".join(formatted)
    
    def get_llm_context(self) -> List[Dict[str, Any]]:
        """
        Get the conversation history formatted for the LLM.
        
        Returns:
            List of conversation turns formatted for the LLM
        """
        context = []
        
        for item in self.history:
            if item['role'] == 'user':
                context.append({'role': 'user', 'content': item['content']})
            elif item['role'] == 'system':
                context.append({'role': 'assistant', 'content': item['content']})
            elif item['role'] == 'tool':
                # Format tool executions as assistant messages
                if 'message' in item['result']:
                    tool_message = f"I used the {item['tool_name']} tool. {item['result']['message']}"
                    context.append({'role': 'assistant', 'content': tool_message})
                    
        return context
    
    def clear_history(self) -> None:
        """Clear the conversation history."""
        self.history = []
        
    def _trim_history(self) -> None:
        """Trim history to max_history items."""
        if len(self.history) > self.max_history:
            self.history = self.history[-self.max_history:] 