"""
DataContext module for managing data state in the Data Flow Agent.

This module provides the DataContext class which is responsible for loading,
managing, and tracking changes to data throughout an analysis session.
"""

import os
import pandas as pd
from typing import Dict, Any, Optional, List, Tuple

# Import tools for data loading
from tools.data_loading import load_data
from utils.exceptions import DataAgentError, DataframeNotFoundError, FileProcessingError

class DataContext:
    """
    Manages the current state of data being analyzed.
    
    The DataContext is responsible for:
    - Loading and storing DataFrames from CSV/Excel files
    - Tracking changes to data through analysis operations
    - Maintaining data metadata (column types, statistics, etc.)
    """
    
    def __init__(self):
        """Initialize an empty DataContext."""
        self.current_df = None
        self.dataframes = {}
        self.current_file_path = None
        self.metadata = {}
        self.operation_history = []
        
    def load_file(self, file_path: str, sheet_name: Optional[str] = None) -> Dict[str, Any]:
        """
        Load a data file (CSV or Excel) into the DataContext.
        
        Args:
            file_path: Path to the file to load
            sheet_name: For Excel files, name of the sheet to load (default: first sheet)
            
        Returns:
            Dictionary containing metadata about the loaded file
            
        Raises:
            FileProcessingError: If file loading fails
        """
        try:
            # Use the existing load_data tool
            loaded_data = load_data(file_path, sheet_name)
            
            # Store the DataFrame
            df = loaded_data['result_df']
            file_info = loaded_data['metadata']
            
            # Update context state
            self.current_df = df
            self.current_file_path = file_path
            self.metadata = file_info
            
            # Store in dataframes dictionary
            file_key = f"{os.path.basename(file_path)}"
            if sheet_name:
                file_key += f":{sheet_name}"
            self.dataframes[file_key] = df
            
            # Add to operation history
            self.operation_history.append({
                'operation': 'load_file',
                'file_path': file_path,
                'sheet_name': sheet_name,
                'rows': len(df),
                'columns': len(df.columns)
            })
            
            return {
                'success': True,
                'message': loaded_data['message'],
                'metadata': file_info
            }
            
        except Exception as e:
            raise FileProcessingError(
                os.path.basename(file_path) if file_path else "unknown",
                f"Error loading file: {str(e)}"
            )
            
    def get_current_df(self) -> pd.DataFrame:
        """
        Get the current DataFrame being analyzed.
        
        Returns:
            The current pandas DataFrame
            
        Raises:
            DataframeNotFoundError: If no DataFrame is currently loaded
        """
        if self.current_df is None:
            raise DataframeNotFoundError("No data has been loaded yet")
        return self.current_df
    
    def update_df(self, df: pd.DataFrame, operation: str = None, details: Dict[str, Any] = None) -> None:
        """
        Update the current DataFrame with a new version.
        
        Args:
            df: The new DataFrame
            operation: Name of the operation that produced this DataFrame
            details: Additional details about the operation
        """
        self.current_df = df
        
        # Add to operation history
        if operation:
            history_entry = {
                'operation': operation,
                'rows': len(df),
                'columns': len(df.columns)
            }
            if details:
                history_entry.update(details)
            self.operation_history.append(history_entry)
    
    def get_metadata(self) -> Dict[str, Any]:
        """
        Get metadata about the current DataFrame.
        
        Returns:
            Dictionary containing metadata about the current data
        """
        if self.current_df is None:
            raise DataframeNotFoundError("No data has been loaded yet")
        
        # Update some metadata fields that might have changed
        self.metadata.update({
            'rows': len(self.current_df),
            'columns': len(self.current_df.columns),
            'column_names': self.current_df.columns.tolist(),
            'column_dtypes': {col: str(dtype) for col, dtype in self.current_df.dtypes.items()},
            'has_missing_values': self.current_df.isna().any().any(),
            'missing_value_counts': self.current_df.isna().sum().to_dict()
        })
        
        return self.metadata
    
    def get_available_dataframes(self) -> List[str]:
        """
        Get list of available dataframes in the context.
        
        Returns:
            List of dataframe identifiers
        """
        return list(self.dataframes.keys())
    
    def get_dataframe(self, identifier: str) -> pd.DataFrame:
        """
        Get a specific dataframe by identifier.
        
        Args:
            identifier: The dataframe identifier
            
        Returns:
            The requested DataFrame
            
        Raises:
            DataframeNotFoundError: If the requested DataFrame doesn't exist
        """
        if identifier not in self.dataframes:
            raise DataframeNotFoundError(f"DataFrame '{identifier}' not found")
        return self.dataframes[identifier]
    
    def set_current_dataframe(self, identifier: str) -> None:
        """
        Set the current dataframe by identifier.
        
        Args:
            identifier: The dataframe identifier
            
        Raises:
            DataframeNotFoundError: If the requested DataFrame doesn't exist
        """
        if identifier not in self.dataframes:
            raise DataframeNotFoundError(f"DataFrame '{identifier}' not found")
        self.current_df = self.dataframes[identifier]
        
        # Update operation history
        self.operation_history.append({
            'operation': 'set_current_dataframe',
            'identifier': identifier
        })
    
    def get_operation_history(self) -> List[Dict[str, Any]]:
        """
        Get the operation history for the current session.
        
        Returns:
            List of operations performed
        """
        return self.operation_history
    
    def get_column_info(self, column_name: str) -> Dict[str, Any]:
        """
        Get detailed information about a specific column.
        
        Args:
            column_name: Name of the column
            
        Returns:
            Dictionary with column information
            
        Raises:
            DataAgentError: If column doesn't exist
        """
        if self.current_df is None:
            raise DataframeNotFoundError("No data has been loaded yet")
            
        if column_name not in self.current_df.columns:
            raise DataAgentError(
                f"Column '{column_name}' not found in current DataFrame",
                code="column_not_found"
            )
            
        column_data = self.current_df[column_name]
        column_type = column_data.dtype
        
        # Gather basic statistics
        info = {
            'name': column_name,
            'type': str(column_type),
            'count': len(column_data),
            'missing': column_data.isna().sum(),
            'missing_percentage': round(column_data.isna().sum() / len(column_data) * 100, 2) if len(column_data) > 0 else 0
        }
        
        # Add numeric-specific statistics
        if pd.api.types.is_numeric_dtype(column_type):
            info.update({
                'min': column_data.min() if not column_data.empty else None,
                'max': column_data.max() if not column_data.empty else None,
                'mean': column_data.mean() if not column_data.empty else None,
                'median': column_data.median() if not column_data.empty else None,
                'std': column_data.std() if not column_data.empty else None
            })
        
        # Add categorical/string-specific statistics
        if pd.api.types.is_object_dtype(column_type) or pd.api.types.is_categorical_dtype(column_type):
            value_counts = column_data.value_counts().head(10).to_dict()
            unique_count = column_data.nunique()
            info.update({
                'unique_values': unique_count,
                'unique_percentage': round(unique_count / len(column_data) * 100, 2) if len(column_data) > 0 else 0,
                'top_values': value_counts
            })
            
        return info 