"""
Tools module for managing tool execution in the Data Flow Agent.

This module provides the ToolExecutor class which is responsible for registering,
validating, and executing tools.
"""

import inspect
from typing import Dict, List, Any, Optional, Callable, Union, Type

from utils.exceptions import ToolExecutionError, ToolNotFoundError

class ToolExecutor:
    """
    Executes tools based on LLM function calls.
    
    The ToolExecutor is responsible for:
    - Validating tool inputs
    - Executing the requested tool
    - Formatting tool responses
    - Handling tool errors
    """
    
    def __init__(self, data_context):
        """
        Initialize the ToolExecutor.
        
        Args:
            data_context: The DataContext instance to use for tool execution
        """
        self.data_context = data_context
        self.registered_tools = {}
        self.tool_descriptions = {}
        
    def register_tool(self, tool_func: Callable) -> None:
        """
        Register a tool function.
        
        Args:
            tool_func: The tool function to register
        """
        tool_name = tool_func.__name__
        self.registered_tools[tool_name] = tool_func
        
        # Extract tool description from docstring
        if tool_func.__doc__:
            self.tool_descriptions[tool_name] = tool_func.__doc__.strip()
        else:
            self.tool_descriptions[tool_name] = f"Tool: {tool_name}"
        
    def register_tools(self, tools: List[Callable]) -> None:
        """
        Register multiple tool functions.
        
        Args:
            tools: List of tool functions to register
        """
        for tool in tools:
            self.register_tool(tool)
            
    def get_registered_tools(self) -> List[str]:
        """
        Get list of registered tool names.
        
        Returns:
            List of registered tool names
        """
        return list(self.registered_tools.keys())
    
    def get_tool_description(self, tool_name: str) -> str:
        """
        Get the description of a registered tool.
        
        Args:
            tool_name: Name of the tool
            
        Returns:
            Tool description
            
        Raises:
            ToolNotFoundError: If the tool is not registered
        """
        if tool_name not in self.tool_descriptions:
            raise ToolNotFoundError(tool_name)
        return self.tool_descriptions[tool_name]
    
    def get_tool_schema(self, tool_name: str) -> Dict[str, Any]:
        """
        Get the JSON schema for a tool's parameters.
        
        Args:
            tool_name: Name of the tool
            
        Returns:
            JSON schema for the tool
            
        Raises:
            ToolNotFoundError: If the tool is not registered
        """
        if tool_name not in self.registered_tools:
            raise ToolNotFoundError(tool_name)
            
        tool = self.registered_tools[tool_name]
        signature = inspect.signature(tool)
        
        # Build parameter schema
        parameters = {}
        for name, param in signature.parameters.items():
            param_type = "string"  # Default type
            
            # Try to extract type from annotation
            if param.annotation != inspect.Parameter.empty:
                if param.annotation == str:
                    param_type = "string"
                elif param.annotation == int:
                    param_type = "integer"
                elif param.annotation == float:
                    param_type = "number"
                elif param.annotation == bool:
                    param_type = "boolean"
                elif param.annotation == List[str]:
                    param_type = "array"
                elif param.annotation == Dict[str, Any]:
                    param_type = "object"
                    
            # Check if parameter has a default value
            required = param.default == inspect.Parameter.empty
            
            parameters[name] = {
                "type": param_type,
                "required": required
            }
            
        return {
            "name": tool_name,
            "description": self.get_tool_description(tool_name),
            "parameters": parameters
        }
    
    def get_all_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        Get JSON schemas for all registered tools.
        
        Returns:
            List of tool schemas
        """
        return [self.get_tool_schema(tool) for tool in self.registered_tools]
            
    def validate_arguments(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate arguments for a tool.
        
        Args:
            tool_name: Name of the tool
            arguments: Dictionary of tool arguments
            
        Returns:
            Validated arguments dictionary
            
        Raises:
            ToolExecutionError: If arguments are invalid
        """
        if tool_name not in self.registered_tools:
            raise ToolNotFoundError(tool_name)
            
        tool = self.registered_tools[tool_name]
        signature = inspect.signature(tool)
        
        validated_args = {}
        missing_args = []
        
        # Check for required parameters
        for name, param in signature.parameters.items():
            # Skip 'self' parameter if tool is a method
            if name == 'self':
                continue
                
            # Check if parameter is required and missing
            if param.default == inspect.Parameter.empty and name not in arguments:
                missing_args.append(name)
                
            # Add parameter to validated arguments if provided
            if name in arguments:
                validated_args[name] = arguments[name]
            # Add default value if not provided but has default
            elif param.default != inspect.Parameter.empty:
                validated_args[name] = param.default
                
        # If data_location is required but missing, use current file path from data context
        if 'data_location' in missing_args and self.data_context.current_file_path:
            validated_args['data_location'] = self.data_context.current_file_path
            missing_args.remove('data_location')
                
        # Raise error if any required parameters are still missing
        if missing_args:
            raise ToolExecutionError(
                tool_name,
                f"Missing required arguments: {', '.join(missing_args)}"
            )
            
        return validated_args
    
    def execute_tool(self, tool_name: str, arguments: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a tool with given arguments.
        
        Args:
            tool_name: Name of the tool to execute
            arguments: Dictionary of tool arguments
            
        Returns:
            Result of tool execution
            
        Raises:
            ToolNotFoundError: If the tool is not registered
            ToolExecutionError: If tool execution fails
        """
        if tool_name not in self.registered_tools:
            raise ToolNotFoundError(tool_name)
            
        try:
            # Get the tool function
            tool = self.registered_tools[tool_name]
            
            # Validate arguments
            validated_args = self.validate_arguments(tool_name, arguments)
            
            # Execute tool
            result = tool(**validated_args)
            
            # Update data context if result includes a DataFrame
            if isinstance(result, dict) and 'result_df' in result:
                self.data_context.update_df(
                    result['result_df'],
                    operation=tool_name,
                    details={'args': arguments}
                )
            
            return {
                'success': True,
                'tool': tool_name,
                'result': result
            }
            
        except ToolNotFoundError:
            # Re-raise tool not found errors
            raise
        except Exception as e:
            # Wrap other exceptions
            raise ToolExecutionError(tool_name, str(e))
    
    def format_result(self, tool_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Format the result of a tool execution for user presentation.
        
        Args:
            tool_result: The raw tool execution result
            
        Returns:
            Formatted result for user presentation
        """
        # Extract base information
        formatted = {
            'success': tool_result.get('success', False),
            'tool': tool_result.get('tool', 'unknown'),
        }
        
        # Extract result data
        result = tool_result.get('result', {})
        
        # Add message if available
        if isinstance(result, dict) and 'message' in result:
            formatted['message'] = result['message']
            
        # Add plot URL if available
        if isinstance(result, dict) and 'plot_url' in result:
            formatted['plot_url'] = result['plot_url']
            
        # Add metadata if available
        if isinstance(result, dict) and 'metadata' in result:
            formatted['metadata'] = result['metadata']
            
        return formatted 