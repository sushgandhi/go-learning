# Data Flow Agent Frontend

This is a simple ChatGPT-like frontend for the Data Flow Agent API.

## Features

- File upload interface
- Chat-based interaction with the API
- Support for displaying tables and visualizations
- Chat history management
- Responsive design

## Installation

```bash
# Install dependencies
npm install
```

## Usage

First, make sure the backend API is running:

```bash
# From the root directory
uvicorn api:app --reload
```

Then, start the frontend server:

```bash
# From the frontend directory
npm start
```

The frontend will be available at http://localhost:3000.

## How to Use

1. Upload a CSV or Excel file using the sidebar
2. Ask questions about your data in natural language
3. View the results in the chat interface

## Technologies Used

- HTML5/CSS3
- JavaScript (ES6+)
- Express.js (for serving static files)
- LocalStorage (for persisting state)

## Notes

- This is a simple frontend for demonstration purposes
- In a real application, you would implement file uploads to the server
- The actual path to your data file needs to be adjusted in app.js 