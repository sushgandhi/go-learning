Here's the problem statement.

Building a Data - AI Agent system that takes Exxel/Csv as inputs and can be fully agentic to combination of tool calling. the goals is to build a system that can be used by non-tech users to analyse their data. The agent is a data analyst agent.

I want an ai system can a combination of tool calling.

Tools are defined in tools/ folder
Let's restrict to 1 file as of now. We can expand to more files later.

For now i just want to build a system that can be triggered via command line. but has to be modular and extensible, so it can be exposed as an API later.

Also code strucutre should be modular and extensible, so it can also be used as a library.

It should have following features.


All interaction will be based with user in natural language form.

Based on user query, the agent should be able to use the tools to analyse the data.

There's a working implementation sample in app.py

and tools already exist

please use blueprint of app.py as baseline to build this.
sample.csv is a csv file to test this


Tool calling features are as follows:

1. Ability to filter and group data.

2. Ability to visualise any data with any grain. Visualisation can be pretty much of any kind. System should be smart enough to know what's possible and what is not.

3. Ability to pivot data, table.

4. Compare 2 columns

5. Compare 2 files

6. Summarise a column

7. Summarise a row

8. Summarise the sheet

9. Summarise the entire workbook across all sheets.
------

As you develop the solution

please keep on updating the following files - 

- UNDEFRSTANDING.md : Reflects what you understood about the problem statement and write in its own words. you may also list down external API endpoints etc of any service that this code is supposed to consume

- REQUIREMENTS.md: Reflects proper requirements step by step

- PLAN.md: Phase wise plan to implement things so it starts with boilerplate, then core structures, then adds necessary functionality, then good to have ones, etc. 

- IMPLEMENTATION.md: Low level design and description of classes, functions and other details. 

- CHANGELOG.md: Keep a versioned changelog in the format of keep a changelog so it always knows what has been done between sessions and what's next, by correlating against PLAN.


