#!/usr/bin/env python3
"""
Data Flow Agent - Main Entry Point

This module provides the main entry point for the Data Flow Agent application.
It handles command-line arguments and initializes the application.
"""

import os
import sys
import argparse
from typing import Dict, Any, Optional

from data_flow_agent.application import ApplicationManager

def parse_arguments():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Data Flow Agent - AI-powered data analysis system"
    )
    
    # File input
    parser.add_argument(
        "-f", "--file",
        help="Path to the data file (CSV or Excel)",
        type=str
    )
    
    # Sheet name for Excel files
    parser.add_argument(
        "-s", "--sheet",
        help="Sheet name for Excel files",
        type=str
    )
    
    # Query
    parser.add_argument(
        "-q", "--query",
        help="Natural language query to execute. If provided, runs in non-interactive mode.",
        type=str
    )
    
    # Configuration file
    parser.add_argument(
        "-c", "--config",
        help="Path to configuration file",
        type=str
    )
    
    # Interactive mode
    parser.add_argument(
        "-i", "--interactive",
        help="Run in interactive mode (default if no query is provided)",
        action="store_true"
    )
    
    # Output format
    parser.add_argument(
        "-o", "--output",
        help="Output format (text, json)",
        type=str,
        choices=["text", "json"],
        default="text"
    )
    
    # Debug mode
    parser.add_argument(
        "--debug",
        help="Enable debug mode",
        action="store_true"
    )
    
    return parser.parse_args()

def load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """
    Load configuration from file.
    
    Args:
        config_path: Path to configuration file
        
    Returns:
        Configuration dictionary
    """
    config = {
        'model_name': os.environ.get('MODEL_NAME', 'gemini-2.5-pro'),
        'base_url': os.environ.get('BASE_URL', ''),
        'project_id': os.environ.get('VERTEX_PROJECT_ID', ''),
        'location': os.environ.get('VERTEX_PROJECT_LOCATION', ''),
    }
    
    # TODO: Add configuration file loading if path provided
    
    return config

def main():
    """Main entry point for the application."""
    # Parse arguments
    args = parse_arguments()
    
    # Load configuration
    config = load_config(args.config)
    
    # Update config with debug flag
    if args.debug:
        config['debug'] = True
    
    # Initialize application
    app = ApplicationManager(config)
    if not app.initialize():
        print("Failed to initialize application. Exiting.")
        sys.exit(1)
    
    try:
        # If file is provided, load it
        if args.file:
            file_path = os.path.abspath(args.file)
            if not os.path.exists(file_path):
                print(f"Error: File not found: {file_path}")
                sys.exit(1)
                
            print(f"Loading file: {file_path}")
            result = app.load_data(file_path, args.sheet)
            print(f"File loaded: {result['message']}")
        
        # Determine mode based on arguments
        if args.query:
            # Non-interactive mode with query
            if not args.file:
                print("Error: File is required when providing a query.")
                sys.exit(1)
                
            result = app.process_query(args.query)
            
            # Print result based on output format
            if args.output == "json":
                import json
                print(json.dumps(result, indent=2))
            else:
                if result.get('type') == 'error':
                    print(f"Error: {result['error_message']}")
                elif result.get('type') == 'function_call':
                    function_result = result.get('result', {})
                    
                    if 'message' in function_result:
                        print(f"Result: {function_result['message']}")
                        
                    if 'plot_url' in function_result:
                        print(f"Plot generated: {function_result['plot_url']}")
                else:
                    print(f"Response: {result.get('content', '')}")
        
        elif args.interactive or not args.file:
            # Interactive mode
            app.run_interactive()
            
    except KeyboardInterrupt:
        print("\nOperation interrupted by user. Exiting.")
        
    except Exception as e:
        print(f"Error: {str(e)}")
        if args.debug:
            import traceback
            traceback.print_exc()
            
    finally:
        app.shutdown()

if __name__ == "__main__":
    main() 