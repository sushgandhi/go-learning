import os
from typing import Dict, Any, Optional
import pandas as pd
from utils.exceptions import ToolExecutionError, FileProcessingError


def load_data(file_path: str, sheet_name: Optional[str] = None) -> Dict[str, Any]:
    """
    Loads data from a CSV or Excel file into a pandas DataFrame.
    
    Args:
        file_path: Path to the file to load
        sheet_name: For Excel files, name of the sheet to load (default: first sheet)
        
    Returns:
        Dictionary containing the loaded DataFrame and metadata about the file
    """
    try:
        # Check if file exists
        if not os.path.exists(file_path):
            raise FileProcessingError(
                os.path.basename(file_path),
                f"File not found: {file_path}"
            )
        
        # Determine file type based on extension
        file_extension = os.path.splitext(file_path)[1].lower()
        
        # Load based on file type
        if file_extension == '.csv':
            # Load CSV file
            df = pd.read_csv(file_path)
            file_type = 'csv'
            sheets = None
            sheet_loaded = None
        elif file_extension in ['.xlsx', '.xls']:
            # For Excel files
            excel_file = pd.ExcelFile(file_path)
            all_sheets = excel_file.sheet_names
            
            # If sheet_name is None, read the first sheet
            if sheet_name is None:
                sheet_name = all_sheets[0]
            elif sheet_name not in all_sheets:
                raise FileProcessingError(
                    os.path.basename(file_path),
                    f"Sheet '{sheet_name}' not found in Excel file. Available sheets: {', '.join(all_sheets)}"
                )
            
            # Load the specified sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            file_type = 'excel'
            sheets = all_sheets
            sheet_loaded = sheet_name
        else:
            raise FileProcessingError(
                os.path.basename(file_path),
                f"Unsupported file type: {file_extension}. Supported formats: .csv, .xlsx, .xls"
            )
        
        # Basic data cleaning and preparation
        # 1. Remove leading/trailing spaces from column names
        df.columns = df.columns.str.strip()
        
        # 2. Attempt to convert numeric columns stored as strings
        for col in df.select_dtypes(include=['object']).columns:
            try:
                # Try to convert to numeric, but only if it doesn't introduce NaNs
                numeric_series = pd.to_numeric(df[col], errors='coerce')
                # If no NaNs were introduced, or the NaNs were already there, convert
                if numeric_series.isna().sum() == df[col].isna().sum():
                    df[col] = numeric_series
            except:
                # If any error occurs, keep the column as is
                pass
        
        # Prepare result with metadata
        result = {
            'result_df': df,
            'message': f"File '{os.path.basename(file_path)}' loaded successfully with {len(df)} rows and {len(df.columns)} columns.",
            'metadata': {
                'file_path': file_path,
                'file_name': os.path.basename(file_path),
                'file_type': file_type,
                'file_size_bytes': os.path.getsize(file_path),
                'sheet_name': sheet_loaded,
                'available_sheets': sheets,
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': df.columns.tolist(),
                'column_dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
                'has_missing_values': df.isna().any().any(),
                'missing_value_counts': df.isna().sum().to_dict()
            }
        }
        
        return result
    
    except FileProcessingError as e:
        # Re-raise the FileProcessingError
        raise ToolExecutionError("load_data", e.message, e.details)
    except Exception as e:
        # Wrap other exceptions
        file_name = os.path.basename(file_path) if file_path else "unknown"
        raise ToolExecutionError(
            "load_data", 
            f"Error loading file '{file_name}': {str(e)}"
        ) 