import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, Union, List
from utils.exceptions import ToolExecutionError
from utils.logging import log_info
from tools.data_loading import load_data
import os
import json


def summarize_column(data_location: str, column: str) -> Dict[str, Any]:
    """
    Provides descriptive statistics and information about a single column in a DataFrame.
    
    Args:
        df: The DataFrame to analyze
        column: Name of the column to summarize
        
    Returns:
        Dictionary containing summary information about the column
    """
    try:
        try:
            loaded_data = load_data(data_location)
            df = loaded_data['result_df']
            file_info = loaded_data['metadata']
        except Exception as e:
            raise ToolExecutionError("summarize_column", f"Error loading first file: {str(e)}")
        
        # Case-insensitive column name matching
        actual_column = None
        if column in df.columns:
            actual_column = column
        else:
            # Try case-insensitive matching
            column_lower = column.lower()
            log_info(f"Trying case-insensitive match for column '{column}'", {
                "available_columns": list(df.columns),
                "lowercase_column": column_lower
            })
            for col in df.columns:
                if col.lower() == column_lower:
                    log_info(f"Found matching column: '{col}' for requested column: '{column}'")
                    actual_column = col
                    break
            
            if actual_column is None:
                log_info(f"No matching column found for '{column}'")
        
        if actual_column is None:
            raise ToolExecutionError(
                "summarize_column",
                f"Column '{column}' not found in DataFrame. Available columns: {', '.join(df.columns)}"
            )
        
        # Use the matched column name for all operations
        column = actual_column
        
        # Extract the column
        series = df[column]
        
        # Basic information
        summary = {
            'column_name': column,
            'data_type': str(series.dtype),
            'count': len(series),
            'non_null_count': series.count(),
            'null_count': series.isna().sum(),
            'null_percent': round((series.isna().sum() / len(series) * 100), 2),
            'unique_values': series.nunique(),
            'memory_usage': series.memory_usage(deep=True)
        }
        
        # Different stats based on dtype
        if pd.api.types.is_numeric_dtype(series):
            # For numeric columns
            summary['numeric_stats'] = {
                'mean': series.mean() if not all(series.isna()) else None,
                'median': series.median() if not all(series.isna()) else None,
                'std_dev': series.std() if not all(series.isna()) else None,
                'min': series.min() if not all(series.isna()) else None,
                'max': series.max() if not all(series.isna()) else None,
                'quantiles': {
                    '25%': series.quantile(0.25) if not all(series.isna()) else None,
                    '50%': series.quantile(0.50) if not all(series.isna()) else None,
                    '75%': series.quantile(0.75) if not all(series.isna()) else None,
                },
                'skew': series.skew() if not all(series.isna()) else None,
                'kurtosis': series.kurtosis() if not all(series.isna()) else None
            }
            
            # Check if column appears to be a boolean encoded as numeric
            if series.dropna().isin([0, 1]).all():
                summary['appears_boolean'] = True
                value_counts = series.value_counts().to_dict()
                summary['value_distribution'] = {
                    'count_0': value_counts.get(0, 0),
                    'count_1': value_counts.get(1, 0),
                    'percentage_0': round((value_counts.get(0, 0) / series.count() * 100), 2),
                    'percentage_1': round((value_counts.get(1, 0) / series.count() * 100), 2)
                }
            
        elif pd.api.types.is_datetime64_dtype(series):
            # For datetime columns
            summary['datetime_stats'] = {
                'min_date': series.min().strftime('%Y-%m-%d %H:%M:%S') if not all(series.isna()) else None,
                'max_date': series.max().strftime('%Y-%m-%d %H:%M:%S') if not all(series.isna()) else None,
                'range_days': (series.max() - series.min()).days if not all(series.isna()) else None
            }
            
        else:
            # For categorical/object columns
            value_counts = series.value_counts().head(10).to_dict()
            top_values_percent = sum(value_counts.values()) / series.count() * 100 if series.count() > 0 else 0
            
            summary['categorical_stats'] = {
                'top_values': value_counts,
                'top_values_percent': round(top_values_percent, 2),
                'average_string_length': round(series.astype(str).str.len().mean(), 2) if not all(series.isna()) else None
            }
            
            # Check if column appears to be a boolean
            if series.dropna().isin(['True', 'False']) or series.dropna().isin([True, False]):
                summary['appears_boolean'] = True
                bool_counts = series.value_counts().to_dict()
                summary['value_distribution'] = {
                    'count_True': bool_counts.get(True, 0) + bool_counts.get('True', 0),
                    'count_False': bool_counts.get(False, 0) + bool_counts.get('False', 0),
                    'percentage_True': round(((bool_counts.get(True, 0) + bool_counts.get('True', 0)) / series.count() * 100), 2),
                    'percentage_False': round(((bool_counts.get(False, 0) + bool_counts.get('False', 0)) / series.count() * 100), 2)
                }
                
        # Prepare result
        result = {
            'result_df': pd.DataFrame({
                'Statistic': list(summary.keys()),
                'Value': [str(v) if not isinstance(v, dict) else json.dumps(v) for v in summary.values()]
            }),
            'message': f"Column '{column}' summary statistics:",
            'metadata': summary
        }
        
        return result
        
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
            
        # Otherwise wrap it
        raise ToolExecutionError("summarize_column", str(e))


def summarize_row(data_location: str, row_index: int) -> Dict[str, Any]:
    """
    Provides information about a single row in a DataFrame.
    
    Args:
        df: The DataFrame to analyze
        row_index: Index of the row to summarize (0-based)
        
    Returns:
        Dictionary containing the row data and metadata
    """
    try:
        try:
            loaded_data = load_data(data_location)
            df = loaded_data['result_df']
            file_info = loaded_data['metadata']
        except Exception as e:
            raise ToolExecutionError("summarize_row", f"Error loading first file: {str(e)}")
        
        if not 0 <= row_index < len(df):
            raise ToolExecutionError(
                "summarize_row", 
                f"Row index {row_index} out of bounds. DataFrame has {len(df)} rows (0-{len(df)-1})."
            )
            
        # Extract the row
        row = df.iloc[row_index]
        
        # Convert row to dictionary
        row_dict = row.to_dict()
        
        # Prepare result
        result = {
            'result_df': pd.DataFrame({
                'Column': list(row_dict.keys()),
                'Value': list(row_dict.values())
            }),
            'message': f"Values for row {row_index}:",
            'metadata': {
                'row_index': row_index,
                'total_rows': len(df),
                'row_data': row_dict
            }
        }
        
        return result
    
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
            
        # Otherwise wrap it
        raise ToolExecutionError("summarize_row", str(e))


def summarize_sheet(data_location: str) -> Dict[str, Any]:
    """
    Provides overall statistics and information about a DataFrame.
    
    Args:
        df: The DataFrame to analyze
        
    Returns:
        Dictionary containing summary information about the DataFrame
    """
    try:
        try:
            loaded_data = load_data(data_location)
            df = loaded_data['result_df']
            file_info = loaded_data['metadata']
        except Exception as e:
            raise ToolExecutionError("summarize_sheet", f"Error loading first file: {str(e)}")
        
        # Basic DataFrame info
        summary = {
            'shape': {
                'rows': len(df),
                'columns': len(df.columns)
            },
            'memory_usage_bytes': df.memory_usage(deep=True).sum(),
            'columns': df.columns.tolist(),
            'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
            'null_counts': df.isna().sum().to_dict(),
            'null_percentage': {col: round((null_count / len(df) * 100), 2) 
                              for col, null_count in df.isna().sum().to_dict().items()},
            'duplicate_rows': df.duplicated().sum(),
            'duplicate_percentage': round((df.duplicated().sum() / len(df) * 100), 2) if len(df) > 0 else 0
        }
        
        # Numeric column statistics
        numeric_cols = df.select_dtypes(include=['number']).columns.tolist()
        if numeric_cols:
            numeric_stats = df[numeric_cols].describe().to_dict()
            # Round numeric values for readability
            for col, stats in numeric_stats.items():
                numeric_stats[col] = {k: round(v, 4) if isinstance(v, (float, np.float64, np.float32)) else v 
                                     for k, v in stats.items()}
            summary['numeric_columns'] = numeric_cols
            summary['numeric_stats'] = numeric_stats
        
        # Categorical column statistics
        categorical_cols = df.select_dtypes(include=['object', 'category']).columns.tolist()
        if categorical_cols:
            categorical_stats = {}
            for col in categorical_cols:
                value_counts = df[col].value_counts().head(5).to_dict()
                unique_values = df[col].nunique()
                categorical_stats[col] = {
                    'unique_values': unique_values,
                    'top_5_values': value_counts,
                    'top_5_percentage': round(sum(value_counts.values()) / df[col].count() * 100, 2) if df[col].count() > 0 else 0
                }
            summary['categorical_columns'] = categorical_cols
            summary['categorical_stats'] = categorical_stats
        
        # Datetime column statistics
        datetime_cols = df.select_dtypes(include=['datetime']).columns.tolist()
        if datetime_cols:
            datetime_stats = {}
            for col in datetime_cols:
                datetime_stats[col] = {
                    'min_date': df[col].min().strftime('%Y-%m-%d %H:%M:%S') if not all(df[col].isna()) else None,
                    'max_date': df[col].max().strftime('%Y-%m-%d %H:%M:%S') if not all(df[col].isna()) else None,
                    'range_days': (df[col].max() - df[col].min()).days if not all(df[col].isna()) else None
                }
            summary['datetime_columns'] = datetime_cols
            summary['datetime_stats'] = datetime_stats
        
        # Create a DataFrame for display
        info_df = pd.DataFrame({
            'Column': df.columns.tolist(),
            'Non-Null Count': [(len(df) - df[col].isna().sum()) for col in df.columns],
            'Dtype': [str(df[col].dtype) for col in df.columns],
            'Unique Values': [df[col].nunique() for col in df.columns],
            'Memory Usage (bytes)': [df[col].memory_usage(deep=True) for col in df.columns]
        })
        
        # Prepare result
        result = {
            'result_df': info_df,
            'message': f"DataFrame summary: {len(df)} rows × {len(df.columns)} columns",
            'metadata': summary
        }
        
        return result
    
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
            
        # Otherwise wrap it
        raise ToolExecutionError("summarize_sheet", str(e))


def summarize_workbook(file_path: str) -> Dict[str, Any]:
    """
    Provides summary information about all sheets in an Excel workbook.
    
    Args:
        file_path: Path to the Excel file
        
    Returns:
        Dictionary containing summary information about all sheets
    """
    try:
        # Validate inputs
        if not file_path:
            raise ToolExecutionError("summarize_workbook", "File path is empty")
        
        # Check if file exists
        if not os.path.exists(file_path):
            raise ToolExecutionError("summarize_workbook", f"File not found: {file_path}")
        
        # Determine file type based on extension
        file_extension = os.path.splitext(file_path)[1].lower()
        
        # Only process Excel files
        if file_extension not in ['.xlsx', '.xls']:
            raise ToolExecutionError(
                "summarize_workbook", 
                f"File is not an Excel workbook: {file_path}. Supported formats: .xlsx, .xls"
            )
        
        # Read all sheets
        excel_file = pd.ExcelFile(file_path)
        sheet_names = excel_file.sheet_names
        
        # Analyze each sheet
        sheet_summaries = {}
        sheet_info = []
        
        for sheet_name in sheet_names:
            # Read sheet
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Basic sheet info
            sheet_summary = {
                'rows': len(df),
                'columns': len(df.columns),
                'memory_usage_bytes': df.memory_usage(deep=True).sum(),
                'column_names': df.columns.tolist(),
                'null_counts': df.isna().sum().sum(),
                'duplicate_rows': df.duplicated().sum()
            }
            
            sheet_summaries[sheet_name] = sheet_summary
            
            # Add to info list for result DataFrame
            sheet_info.append({
                'Sheet Name': sheet_name,
                'Rows': len(df),
                'Columns': len(df.columns),
                'Memory Usage (MB)': round(df.memory_usage(deep=True).sum() / (1024 * 1024), 2),
                'Column Names': ', '.join(df.columns.tolist()[:5]) + ('...' if len(df.columns) > 5 else '')
            })
        
        # Calculate workbook-level statistics
        total_sheets = len(sheet_names)
        total_rows = sum(summary['rows'] for summary in sheet_summaries.values())
        total_columns = sum(summary['columns'] for summary in sheet_summaries.values())
        total_memory = sum(summary['memory_usage_bytes'] for summary in sheet_summaries.values())
        
        # Prepare result
        result = {
            'result_df': pd.DataFrame(sheet_info),
            'message': f"Workbook summary: {total_sheets} sheets, {total_rows} total rows across all sheets",
            'metadata': {
                'file_path': file_path,
                'file_name': os.path.basename(file_path),
                'file_size_bytes': os.path.getsize(file_path),
                'total_sheets': total_sheets,
                'sheet_names': sheet_names,
                'total_rows': total_rows,
                'total_columns': total_columns,
                'total_memory_bytes': total_memory,
                'sheet_summaries': sheet_summaries
            }
        }
        
        return result
    
    except Exception as e:
        # If it's already a ToolExecutionError, re-raise it
        if isinstance(e, ToolExecutionError):
            raise e
            
        # Otherwise wrap it
        raise ToolExecutionError("summarize_workbook", str(e)) 