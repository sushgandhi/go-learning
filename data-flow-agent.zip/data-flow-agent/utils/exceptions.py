class DataAgentError(Exception):
    """Base exception class for all Data Agent exceptions."""
    
    def __init__(self, message, code=None, details=None):
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(self.message)

class ToolExecutionError(DataAgentError):
    """Exception raised when a tool execution fails."""
    
    def __init__(self, tool_name, message, details=None):
        super().__init__(
            message=f"Error executing tool '{tool_name}': {message}",
            code="tool_execution_error",
            details={"tool_name": tool_name, **(details or {})}
        )

class InvalidRequestError(DataAgentError):
    """Exception raised when a request is invalid."""
    
    def __init__(self, message, details=None):
        super().__init__(
            message=f"Invalid request: {message}",
            code="invalid_request",
            details=details
        )

class SessionNotFoundError(DataAgentError):
    """Exception raised when a session is not found."""
    
    def __init__(self, session_id):
        super().__init__(
            message=f"Session not found: {session_id}",
            code="session_not_found",
            details={"session_id": session_id}
        )

class DataframeNotFoundError(DataAgentError):
    """Exception raised when a dataframe is not found for a session."""
    
    def __init__(self, session_id):
        super().__init__(
            message=f"No dataframe found for session: {session_id}",
            code="dataframe_not_found",
            details={"session_id": session_id}
        )

class FileProcessingError(DataAgentError):
    """Exception raised when processing a file fails."""
    
    def __init__(self, file_name, message, details=None):
        super().__init__(
            message=f"Error processing file '{file_name}': {message}",
            code="file_processing_error",
            details={"file_name": file_name, **(details or {})}
        )

class LLMError(DataAgentError):
    """Exception raised when there's an error with the LLM."""
    
    def __init__(self, message, details=None):
        super().__init__(
            message=f"LLM error: {message}",
            code="llm_error",
            details=details
        )

class ToolNotFoundError(DataAgentError):
    """Exception raised when a tool is not found."""
    
    def __init__(self, tool_name, details=None):
        super().__init__(
            message=f"Tool not found: {tool_name}",
            code="tool_not_found",
            details={"tool_name": tool_name, **(details or {})}
        ) 