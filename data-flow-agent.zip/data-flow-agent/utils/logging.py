import os
import logging
from datetime import datetime
import traceback
import json

# Configure logging
LOG_DIR = os.path.join(os.getcwd(), 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

# Create logger instances
error_logger = logging.getLogger('error_logger')
info_logger = logging.getLogger('info_logger')

# Set logging level
error_logger.setLevel(logging.ERROR)
info_logger.setLevel(logging.INFO)

# Create log file handlers
error_file_handler = logging.FileHandler(os.path.join(LOG_DIR, 'error.log'))
info_file_handler = logging.FileHandler(os.path.join(LOG_DIR, 'info.log'))

# Create formatters
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
error_file_handler.setFormatter(log_formatter)
info_file_handler.setFormatter(log_formatter)

# Add handlers to loggers
error_logger.addHandler(error_file_handler)
info_logger.addHandler(info_file_handler)

def log_error(error_message, error=None, additional_info=None):
    """
    Log an error with full traceback and additional info.
    
    Args:
        error_message: A descriptive error message
        error: The exception object (optional)
        additional_info: Dictionary of additional information (optional)
    """
    if error:
        error_details = {
            'message': error_message,
            'error_type': type(error).__name__,
            'error_details': str(error),
            'traceback': traceback.format_exc(),
            'timestamp': datetime.now().isoformat()
        }
    else:
        error_details = {
            'message': error_message,
            'timestamp': datetime.now().isoformat()
        }
    
    if additional_info:
        error_details.update(additional_info)
    
    try:
        error_logger.error(json.dumps(error_details, indent=2))
    except:
        # Fallback if JSON serialization fails
        error_logger.error(f"{error_message} - {str(error)}")
        if additional_info:
            error_logger.error(f"Additional info: {str(additional_info)}")

def log_info(message, additional_info=None):
    """
    Log information.
    
    Args:
        message: The info message
        additional_info: Dictionary of additional information (optional)
    """
    if additional_info:
        try:
            info_details = {
                'message': message,
                'details': additional_info,
                'timestamp': datetime.now().isoformat()
            }
            info_logger.info(json.dumps(info_details, indent=2))
        except:
            # Fallback if JSON serialization fails
            info_logger.info(message)
            info_logger.info(f"Additional info: {str(additional_info)}")
    else:
        info_logger.info(message) 