# Excel Workflow System

A comprehensive system for autonomous Excel and CSV data processing using LangGraph and LLMs.

## Features

- **Advanced Column Analysis**:
  - Smart processing for different data types (numeric, text, dates, etc.)
  - Batched processing of text columns with aggregated insights
  - Comprehensive statistical and textual analysis

- **Contextual Row Analysis**:
  - Enhanced row summaries with complete context for all columns
  - Data value comparisons against dataset statistics
  - Adjacent row context for better understanding
  - Direct output to Excel with an EXCEL_WORKFLOW_SUMMARY column
  - Flexible row range processing with single row, all rows, or custom range options

- **Data Classification**:
  - Unsupervised classification using LLM knowledge
  - Few-shot learning with example-based classification
  - Context-based classification with detailed row information
  - Parallel processing for larger datasets

- **Data Visualization**: Generate various visualizations like bar charts, histograms, line charts, etc.

- **Natural Language Filtering**: Filter and query data using natural language

- **Queue-based Task Processing**: Priority queue for handling multiple tasks

- **LLM Support**:
  - Google's Gemini Pro (primary)
  - OpenAI
  - Ollama (for local deployment)
  - Fallback simulation mode for testing

- **Rich Outputs**:
  - Automatic markdown reports
  - Excel output with added summary columns
  - Visualization export options

## Installation

```bash
# Clone the repository
git clone https://github.com/yourusername/excel_workflow.git
cd excel_workflow

# Install dependencies
pip install -r requirements.txt

# For Gemini support
pip install langchain-google-genai
```

## Requirements

- Python 3.8+
- Dependencies listed in requirements.txt:
  - langgraph
  - langchain-core
  - pandas
  - matplotlib
  - openpyxl
  - numpy
  - langchain-google-genai (for Gemini support)

## Usage

### Command Line Interface

The system provides both interactive and command-line modes:

```bash
# Interactive mode
python -m excel_workflow.main --interactive

# Process a specific file with a specific action
python -m excel_workflow.main --file data.xlsx --action summarize-column --column "Price"

# Analyze a single row
python -m excel_workflow.main --file data.xlsx --action summarize-row --row 5

# Analyze all rows in the dataset and export to Excel 
python -m excel_workflow.main --file data.xlsx --action summarize-row --all-rows

# Analyze a specific range of rows (rows 10-20) with parallel processing
python -m excel_workflow.main --file data.xlsx --action summarize-row --start-row 10 --end-row 20 --parallel

# Generate a visualization
python -m excel_workflow.main --file data.xlsx --action visualize --viz-type bar_chart --x-column "Category" --y-column "Sales" --output chart.png

# Classify data with context
python -m excel_workflow.main --file data.csv --action classify --column "Description" --mode context --output classified_data.csv
```

### Python API

You can also use the system programmatically:

```python
from excel_workflow import initialize_system, load_excel_file, generate_column_summary, generate_all_row_summaries
# For using Gemini
from langchain_google_genai import ChatGoogleGenerativeAI

# Initialize with Gemini
llm = ChatGoogleGenerativeAI(model="gemini-pro")
initialize_system(llm)

# Load a file
load_excel_file("data.xlsx")

# Generate an enhanced column summary for text data
result = generate_column_summary("data.xlsx", "Comments", batch_size=50)
print(result["result"]["summary"])

# Generate a rich row summary for a single row
row_result = generate_row_summary("data.xlsx", 5)  # Analyze row 5
print(row_result["result"]["summary"])

# Generate summaries for a range of rows and export to Excel
all_rows_result = generate_all_row_summaries(
    "data.xlsx",
    start_row=10,
    max_rows=50,  # Process 50 rows starting from row 10
    parallel_processing=True,
    max_workers=4
)
print(f"Summaries saved to: {all_rows_result['output_file']}")

# Classify data with parallel processing for large datasets
classify_result = classify_data(
    "data.xlsx",
    "Description",
    mode="context",
    class_definitions={
        "Positive": "Content expressing approval or satisfaction",
        "Negative": "Content expressing criticism or dissatisfaction",
        "Neutral": "Factual or balanced content without strong sentiment"
    },
    parallel_processing=True,
    batch_size=50,
    max_workers=4
)
print(classify_result["result"]["summary"]["classification_counts"])
```

## Examples

The repository includes example scripts to demonstrate different capabilities:

- `examples/basic_workflow.py`: Basic usage examples for all core features
- `examples/enhanced_analysis.py`: Demonstrates text processing, row context, and parallel processing

Run the examples:

```bash
python -m examples.basic_workflow
python -m examples.enhanced_analysis
```

## Architecture

The system is built on a queue-based architecture using LangGraph for workflow management:

1. **Task Queue**: Tasks are prioritized and processed sequentially or in parallel
2. **State Management**: All state is tracked in a central state object
3. **LLM Integration**: Uses LangChain to integrate with various LLM providers
4. **Data Processing**: Uses pandas for data manipulation and matplotlib for visualization
5. **Parallel Processing**: Optional parallel processing for large datasets

## Performance

For large datasets, the system supports parallel processing of classification tasks, which can significantly improve performance. The speedup depends on:

- The size of the dataset
- The complexity of the classification task
- The number of available CPU cores
- The type of LLM client used (some may have rate limiting)

## Extending the System

You can extend the system by:

1. Adding new task types in `state.py`
2. Implementing processors for new tasks in `processors.py`
3. Exposing new features through the API in `api.py`
4. Adding UI components for new features

## License

MIT License 