"""
Basic example demonstrating how to use the Excel Workflow system.

This example:
1. Initializes the system with a DummyLLM (for demonstration)
2. Loads a sample Excel file
3. Performs various operations on the data
4. Prints results
"""

import os
import sys
import pandas as pd

# Add the parent directory to the sys.path to import the excel_workflow package
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from excel_workflow.api import (
    initialize_system,
    reset_system,
    load_excel_file,
    get_loaded_files,
    generate_column_summary,
    generate_workbook_summary,
    classify_data,
    generate_visualization,
    filter_data
)

# Import the DummyLLM for demonstration
from excel_classification import DummyLLM

def create_sample_data():
    """Create a sample Excel file for demonstration."""
    df = pd.DataFrame({
        'Product': ['Laptop', 'Phone', 'Tablet', 'Monitor', 'Keyboard', 'Mouse', 'Headphones', 'Speakers', 'Webcam', 'Charger'],
        'Category': ['Electronics', 'Electronics', 'Electronics', 'Electronics', 'Accessories', 'Accessories', 'Accessories', 'Accessories', 'Accessories', 'Accessories'],
        'Price': [1200, 800, 500, 300, 80, 50, 120, 150, 70, 30],
        'Stock': [50, 100, 75, 30, 200, 250, 80, 40, 60, 300],
        'Rating': [4.5, 4.2, 3.8, 4.0, 4.1, 3.9, 4.3, 3.7, 3.5, 4.0],
        'Description': [
            'High-performance laptop with SSD',
            'Latest smartphone model with great camera',
            'Lightweight tablet with long battery life',
            '27-inch 4K monitor with HDR support',
            'Mechanical keyboard with RGB lighting',
            'Wireless mouse with ergonomic design',
            'Noise-cancelling headphones',
            'Bluetooth speakers with deep bass',
            'HD webcam with microphone',
            'Fast charging USB-C charger'
        ]
    })
    
    # Create a directory for samples if it doesn't exist
    os.makedirs('samples', exist_ok=True)
    
    # Save the DataFrame to an Excel file
    df.to_excel('samples/sample_data.xlsx', index=False)
    print("Created sample data file: samples/sample_data.xlsx")
    return 'samples/sample_data.xlsx'

def main():
    # Reset the system to ensure a clean state
    reset_system()
    
    # Initialize with DummyLLM
    print("Initializing system with DummyLLM...")
    initialize_system(DummyLLM())
    
    # Create and load sample data
    sample_file = create_sample_data()
    print("\nLoading sample data...")
    load_result = load_excel_file(sample_file)
    print(f"Load result: {load_result['status']} - {load_result['message']}")
    
    # List loaded files
    print("\nLoaded files:")
    files = get_loaded_files()
    for file in files:
        print(f"- {file['file_name']} ({file['total_rows']} rows)")
    
    # Generate a column summary
    print("\nGenerating column summary for 'Price'...")
    column_result = generate_column_summary(sample_file, 'Price')
    print("Column Summary:\n" + "-" * 50)
    if isinstance(column_result.get('result'), str):
        print(column_result['result'][:500] + "..." if len(column_result['result']) > 500 else column_result['result'])
    else:
        print("(Summary not available as text)")
    
    # Generate a workbook summary
    print("\nGenerating workbook summary...")
    workbook_result = generate_workbook_summary(sample_file)
    print("Workbook Summary:\n" + "-" * 50)
    if isinstance(workbook_result.get('result'), str):
        summary = workbook_result['result']
        print(summary[:500] + "..." if len(summary) > 500 else summary)
    else:
        print("(Summary not available as text)")
    
    # Classify data using unsupervised mode
    print("\nClassifying 'Description' column using unsupervised mode...")
    classify_result = classify_data(sample_file, 'Description', 'unsupervised')
    if classify_result.get('result', {}).get('summary', {}).get('classification_counts'):
        print("Classification Results:\n" + "-" * 50)
        for category, count in classify_result['result']['summary']['classification_counts'].items():
            print(f"- {category}: {count} items")
    else:
        print("Classification failed or returned no results")
    
    # Generate a visualization
    print("\nGenerating bar chart visualization of Price by Category...")
    viz_result = generate_visualization(sample_file, 'bar_chart', 'Category', 'Price')
    if viz_result.get('result', {}).get('image_data'):
        print("Visualization generated successfully")
        print("To view the visualization, save it using:")
        print(f"from excel_workflow.api import get_task_result")
        print(f"import base64")
        print(f"result = get_task_result('{viz_result['id']}')")
        print(f"with open('samples/visualization.png', 'wb') as f:")
        print(f"    f.write(base64.b64decode(result['result']['image_data']))")
        
        # Save the visualization
        import base64
        with open('samples/visualization.png', 'wb') as f:
            f.write(base64.b64decode(viz_result['result']['image_data']))
        print("Saved visualization to samples/visualization.png")
    else:
        print("Visualization failed or returned no results")
    
    # Filter data using natural language
    print("\nFiltering data with natural language query: 'items with price above 100'...")
    filter_result = filter_data(sample_file, 'items with price above 100')
    if filter_result.get('result', {}).get('filtered_data'):
        filtered_data = filter_result['result']['filtered_data']
        print(f"Filter Results ({len(filtered_data)} items):\n" + "-" * 50)
        for item in filtered_data[:5]:  # Show just the first 5
            print(f"- {item['Product']}: ${item['Price']}")
        if len(filtered_data) > 5:
            print(f"... and {len(filtered_data) - 5} more items")
    else:
        print("Filtering failed or returned no results")
    
    print("\nAll examples completed successfully!")

if __name__ == "__main__":
    main() 