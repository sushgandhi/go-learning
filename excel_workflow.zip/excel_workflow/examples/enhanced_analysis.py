"""
Enhanced Excel Analysis Example

This example demonstrates the improved Excel analysis capabilities:
1. Better column summaries for text data with batched processing
2. Comprehensive row analysis with complete context
3. Classification with full row context
4. Parallel processing for larger datasets
5. Integration with Google's Gemini model
"""

import os
import sys
import pandas as pd
import time

# Add the parent directory to the sys.path to import the excel_workflow package
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from excel_workflow.api import (
    initialize_system,
    reset_system,
    load_excel_file,
    generate_column_summary,
    generate_row_summary,
    classify_data,
    filter_data
)

def create_sample_text_data():
    """Create a sample Excel file with text data for demonstration."""
    # Product reviews dataset with more extensive text
    df = pd.DataFrame({
        'ProductID': ['P001', 'P002', 'P003', 'P001', 'P002', 'P004', 'P005', 'P003', 'P004', 'P005'],
        'Category': ['Electronics', 'Electronics', 'Home', 'Electronics', 'Electronics', 'Office', 'Health', 'Home', 'Office', 'Health'],
        'Rating': [4.5, 2.0, 3.8, 5.0, 1.0, 4.2, 3.5, 4.0, 3.7, 4.8],
        'Review': [
            "I absolutely love this laptop! The performance is outstanding and the battery life exceeds my expectations. The screen quality is crystal clear and the keyboard has a nice feel to it. Would definitely recommend to friends and family.",
            "Very disappointing phone. It constantly freezes and the battery drains extremely quickly. Camera quality is much worse than advertised and customer service was unhelpful when I tried to resolve the issues. Would not recommend.",
            "This coffee maker works pretty well. It brews quickly and the coffee tastes good. My only complaint is that it's a bit loud during operation. The design is sleek and it doesn't take up too much counter space.",
            "Best purchase I've made all year! This laptop is lightning fast and handles all my development work with ease. The build quality is exceptional and the cooling system keeps it running at optimal temperature even under heavy load.",
            "Terrible product! Arrived with scratches and dents. Screen has dead pixels and the charging port stopped working after just 2 days. Complete waste of money and time dealing with returns.",
            "The office chair is comfortable for short periods but starts to hurt my back after a few hours. Assembly was straightforward and the materials seem durable. Price was reasonable compared to similar chairs.",
            "This vitamin supplement has noticeably improved my energy levels within just two weeks. No aftertaste and the pills are easy to swallow. The packaging is convenient for travel too.",
            "Decent kitchen blender. It handles most ingredients well but struggles with frozen fruits. The multiple speed settings are useful and it's easy to clean. A bit louder than expected.",
            "The desk lamp provides good lighting and the adjustable brightness is a nice feature. The clip mount is secure but can leave marks on wooden surfaces. USB charging port is convenient.",
            "These resistance bands are high quality and haven't shown any signs of wear after months of regular use. The different resistance levels are accurately represented and the carrying case is a plus."
        ],
        'Sentiment': ['Positive', 'Negative', 'Neutral', 'Positive', 'Negative', 'Neutral', 'Positive', 'Neutral', 'Positive', 'Positive'],
        'PurchaseDate': ['2023-01-15', '2023-02-03', '2023-01-27', '2023-03-12', '2023-02-18', '2023-04-05', '2023-03-22', '2023-04-17', '2023-05-01', '2023-04-28'],
        'Verified': [True, True, False, True, True, True, False, True, True, False]
    })
    
    # Create a directory for samples if it doesn't exist
    os.makedirs('samples', exist_ok=True)
    
    # Save the DataFrame to an Excel file
    df.to_excel('samples/sample_text_data.xlsx', index=False)
    print("Created sample text data file: samples/sample_text_data.xlsx")
    return 'samples/sample_text_data.xlsx'

def main():
    # Reset the system to ensure a clean state
    reset_system()
    
    # Initialize the system (setup_llm will be called internally)
    print("Initializing system with LLM...")
    from excel_workflow.main import setup_llm
    initialize_system(setup_llm())
    
    # Create and load sample data
    sample_file = create_sample_text_data()
    print("\nLoading sample data...")
    load_result = load_excel_file(sample_file)
    print(f"Load result: {load_result['status']} - {load_result['message']}")
    
    # 1. Generate enhanced column summary for text data (batched processing)
    print("\n=== DEMONSTRATING ENHANCED TEXT COLUMN SUMMARY ===")
    print("Generating enhanced summary for 'Review' column (batched text processing)...")
    start_time = time.time()
    column_result = generate_column_summary(sample_file, 'Review', batch_size=3)
    end_time = time.time()
    
    print(f"Column summary generated. Time taken: {end_time - start_time:.2f} seconds")
    
    # 2. Generate comprehensive row summary with all context
    print("\n=== DEMONSTRATING COMPREHENSIVE ROW SUMMARY ===")
    row_index = 4  # The negative review with rich context
    print(f"Generating comprehensive summary for row {row_index}...")
    start_time = time.time()
    row_result = generate_row_summary(sample_file, row_index)
    end_time = time.time()
    
    print(f"Row summary generated. Time taken: {end_time - start_time:.2f} seconds")
    
    # 3. Classification with full row context
    print("\n=== DEMONSTRATING CLASSIFICATION WITH FULL ROW CONTEXT ===")
    print("Classifying 'Review' column with full row context (sentiment analysis)...")
    start_time = time.time()
    
    # Define sentiment categories
    sentiment_definitions = {
        "Positive": "Text expressing satisfaction, happiness, or approval with the product or service",
        "Negative": "Text expressing dissatisfaction, unhappiness, or criticism of the product or service",
        "Neutral": "Text that is balanced, factual, or doesn't express strong opinions either way",
        "Mixed": "Text containing both positive and negative elements"
    }
    
    # Classify using context-based approach with row context
    classify_result = classify_data(
        sample_file, 
        'Review', 
        mode='context',
        class_definitions=sentiment_definitions
    )
    end_time = time.time()
    
    print(f"Classification completed. Time taken: {end_time - start_time:.2f} seconds")
    
    # 4. Demonstrate parallel classification for larger datasets
    print("\n=== DEMONSTRATING PARALLEL CLASSIFICATION ===")
    print("Creating a larger dataset for parallel processing demo...")
    
    # Create a larger dataset by duplicating the existing one
    large_df = pd.concat([pd.read_excel(sample_file)] * 5, ignore_names=True)
    large_file = 'samples/large_sample.xlsx'
    large_df.to_excel(large_file, index=False)
    print(f"Created larger dataset with {len(large_df)} rows at {large_file}")
    
    # Load the larger file
    load_excel_file(large_file)
    
    print("\nClassifying large dataset sequentially...")
    start_time_seq = time.time()
    classify_result_seq = classify_data(
        large_file, 
        'Review', 
        mode='context',
        class_definitions=sentiment_definitions,
        parallel_processing=False  # Sequential processing
    )
    end_time_seq = time.time()
    seq_time = end_time_seq - start_time_seq
    
    print("\nClassifying large dataset in parallel...")
    start_time_par = time.time()
    classify_result_par = classify_data(
        large_file, 
        'Review', 
        mode='context',
        class_definitions=sentiment_definitions,
        parallel_processing=True,  # Parallel processing
        batch_size=10,
        max_workers=4
    )
    end_time_par = time.time()
    par_time = end_time_par - start_time_par
    
    print("\nPerformance Comparison:")
    print(f"Sequential processing time: {seq_time:.2f} seconds")
    print(f"Parallel processing time: {par_time:.2f} seconds")
    if seq_time > 0:
        print(f"Speedup factor: {seq_time/par_time:.2f}x")
    
    print("\nAll examples completed successfully!")
    print("Results have been saved to the output directory.")

if __name__ == "__main__":
    main() 