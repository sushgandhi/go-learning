#!/usr/bin/env python3
"""
Excel Workflow System - Main Entry Point

This script provides a convenient entry point to the Excel Workflow system.
Run with --help to see available options.
"""

from excel_workflow.main import main

if __name__ == "__main__":
    main() 