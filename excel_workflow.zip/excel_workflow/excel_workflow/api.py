from typing import Dict, Any, List, Optional, Union
import uuid
from .state import (
    ExcelWorkflowState, 
    ExcelTask, 
    TaskType, 
    TaskPriority, 
    TaskStatus,
    VisualizationType,
    ClassificationMode
)
from .task_queue import create_task, update_task_status
from .workflow import create_workflow_graph, initialize_workflow_state
from .data_utils import load_dataframe, get_dataframe_key, load_excel_file
import pandas as pd
import os
from datetime import datetime

# Global workflow state
workflow_state = initialize_workflow_state()
llm_client = None  # Will be set during initialization
workflow_graph = None  # Will be initialized with the LLM client

def initialize_system(llm):
    """Initialize the workflow system with the provided LLM client."""
    global llm_client, workflow_graph, workflow_state
    llm_client = llm
    workflow_graph = create_workflow_graph(llm_client)
    # Store the LLM client in the workflow state for direct access
    workflow_state["llm_client"] = llm_client
    print(f"Excel workflow system initialized with LLM client: {llm_client}")
    print(f"Workflow state llm_client: {workflow_state.get('llm_client')}")
    
    # Test the LLM to make sure it's working
    try:
        test_response = llm_client.invoke("test")
        print(f"LLM test successful, response type: {type(test_response)}")
    except Exception as e:
        print(f"Warning: LLM test failed: {str(e)}")
        import traceback
        traceback.print_exc()

def reset_system():
    """Reset the workflow state."""
    global workflow_state, llm_client
    # Store a reference to the current LLM client
    current_llm = llm_client
    # Reset the state
    workflow_state = initialize_workflow_state()
    # Restore the LLM client
    workflow_state["llm_client"] = current_llm
    print("Excel workflow system reset")

def get_state():
    """Get the current workflow state."""
    return workflow_state

def run_workflow():
    """Run the workflow to process queued tasks."""
    global workflow_state
    
    if not workflow_graph:
        return {"error": "Workflow graph not initialized. Call initialize_system() first."}
    
    if not workflow_state["task_queue"] and not workflow_state["current_task"]:
        return {"status": "idle", "message": "No tasks in queue"}
    
    try:
        # Run the workflow until it reaches an END state or times out
        final_state = workflow_graph.invoke(workflow_state)
        workflow_state = final_state
        
        # Return a summary of the completed tasks
        return {
            "status": "completed",
            "completed_tasks": [
                {
                    "id": task["id"],
                    "type": task["type"],
                    "status": task["status"],
                    "result_summary": summarize_task_result(task)
                }
                for task in workflow_state["completed_tasks"]
            ],
            "pending_tasks": len(workflow_state["task_queue"])
        }
    
    except Exception as e:
        return {"status": "error", "message": str(e)}

def summarize_task_result(task: ExcelTask) -> Dict[str, Any]:
    """Create a summary of the task result for display purposes."""
    if task["status"] == TaskStatus.FAILED:
        return {"error": task["error"]}
    
    if not task["result"]:
        return {"message": "No result data"}
    
    # Summarize based on task type
    if task["type"] == TaskType.COLUMN_SUMMARY:
        if isinstance(task["result"], str):
            # Return the first 100 characters for preview
            return {"summary": task["result"][:100] + "..." if len(task["result"]) > 100 else task["result"]}
        return {"summary": "Column summary completed"}
    
    elif task["type"] == TaskType.ROW_SUMMARY:
        if isinstance(task["result"], str):
            return {"summary": task["result"][:100] + "..." if len(task["result"]) > 100 else task["result"]}
        return {"summary": "Row summary completed"}
    
    elif task["type"] == TaskType.WORKBOOK_SUMMARY:
        if isinstance(task["result"], str):
            return {"summary": task["result"][:100] + "..." if len(task["result"]) > 100 else task["result"]}
        return {"summary": "Workbook summary completed"}
    
    elif task["type"] in [TaskType.CLASSIFICATION_CONTEXT, TaskType.CLASSIFICATION_UNSUPERVISED, TaskType.CLASSIFICATION_FEW_SHOT]:
        if isinstance(task["result"], dict) and "summary" in task["result"]:
            return {"classification_counts": task["result"]["summary"]["classification_counts"]}
        return {"summary": "Classification completed"}
    
    elif task["type"] == TaskType.DATA_VISUALIZATION:
        if isinstance(task["result"], dict) and "type" in task["result"]:
            return {
                "visualization_type": task["result"]["type"],
                "has_image": bool(task["result"].get("image_data"))
            }
        return {"summary": "Visualization completed"}
    
    elif task["type"] == TaskType.FILTER_QUERY:
        if isinstance(task["result"], dict) and "summary" in task["result"]:
            return {
                "original_rows": task["result"]["summary"]["original_rows"],
                "filtered_rows": task["result"]["summary"]["filtered_rows"],
                "reduction": f"{task['result']['summary']['reduction_percentage']}%"
            }
        return {"summary": "Filter query completed"}
    
    return {"message": "Task completed"}

def get_task_result(task_id: str) -> Dict[str, Any]:
    """Get the detailed result of a completed task."""
    for task in workflow_state["completed_tasks"]:
        if task["id"] == task_id:
            return {
                "id": task["id"],
                "type": task["type"],
                "status": task["status"],
                "created_at": task["created_at"],
                "updated_at": task["updated_at"],
                "file_path": task["file_path"],
                "sheet_name": task["sheet_name"],
                "parameters": task["parameters"],
                "result": task["result"],
                "error": task["error"]
            }
    
    return {"error": f"Task {task_id} not found"}

def load_excel_file(file_path: str, sheet_name: Optional[str] = None) -> Dict[str, Any]:
    """Load an Excel file into the system."""
    global workflow_state
    
    try:
        workflow_state = load_dataframe(workflow_state, file_path, sheet_name)
        
        if workflow_state.get("error_message"):
            return {"status": "error", "message": workflow_state["error_message"]}
        
        loaded_keys = [key for key in workflow_state["loaded_sheets"] if key.startswith(file_path)]
        return {
            "status": "success",
            "message": f"Loaded {len(loaded_keys)} sheets from {file_path}",
            "sheets": loaded_keys
        }
    
    except Exception as e:
        return {"status": "error", "message": str(e)}

def get_loaded_files() -> List[Dict[str, Any]]:
    """Get information about all loaded files."""
    file_info = {}
    
    for sheet_key in workflow_state["loaded_sheets"]:
        file_path, sheet_name = sheet_key.split(":", 1)
        
        if file_path not in file_info:
            file_info[file_path] = {
                "file_path": file_path,
                "file_name": os.path.basename(file_path),
                "sheets": [],
                "total_rows": 0
            }
        
        df = workflow_state["dataframes"].get(sheet_key)
        rows = len(df) if df is not None else 0
        
        file_info[file_path]["sheets"].append({
            "name": sheet_name,
            "rows": rows,
            "columns": len(df.columns) if df is not None else 0,
            "column_names": df.columns.tolist() if df is not None else []
        })
        
        file_info[file_path]["total_rows"] += rows
    
    return list(file_info.values())

def add_task(
    task_type: Union[TaskType, str],
    file_path: str,
    parameters: Dict[str, Any],
    priority: Union[TaskPriority, str] = TaskPriority.MEDIUM,
    sheet_name: Optional[str] = None,
    user_id: Optional[str] = None
) -> Dict[str, Any]:
    """Add a task to the workflow queue."""
    global workflow_state
    
    # Convert string types to enum if needed
    if isinstance(task_type, str):
        try:
            task_type = TaskType(task_type)
        except ValueError:
            return {"status": "error", "message": f"Invalid task type: {task_type}"}
    
    if isinstance(priority, str):
        try:
            priority = TaskPriority(priority)
        except ValueError:
            return {"status": "error", "message": f"Invalid priority: {priority}"}
    
    # Create the task
    task = create_task(task_type, file_path, parameters, priority, sheet_name, user_id)
    
    # Add to the queue
    workflow_state["task_queue"].append(task)
    
    return {
        "status": "success",
        "message": f"Task added to queue",
        "task_id": task["id"],
        "queue_position": len(workflow_state["task_queue"])
    }

def cancel_task(task_id: str) -> Dict[str, Any]:
    """Cancel a pending task in the queue."""
    global workflow_state
    
    # Find the task in the queue
    for i, task in enumerate(workflow_state["task_queue"]):
        if task["id"] == task_id:
            # Update status and move to completed
            task = update_task_status(task, TaskStatus.CANCELED)
            workflow_state["completed_tasks"].append(task)
            
            # Remove from queue
            workflow_state["task_queue"].pop(i)
            
            return {
                "status": "success",
                "message": f"Task {task_id} canceled"
            }
    
    return {"status": "error", "message": f"Task {task_id} not found in queue"}

def get_queue_status() -> Dict[str, Any]:
    """Get the current status of the task queue."""
    current = workflow_state["current_task"]
    
    return {
        "current_task": {
            "id": current["id"],
            "type": current["type"],
            "status": current["status"],
            "file_path": current["file_path"],
            "sheet_name": current["sheet_name"]
        } if current else None,
        "pending_tasks": len(workflow_state["task_queue"]),
        "completed_tasks": len(workflow_state["completed_tasks"]),
        "processing_steps": workflow_state["processing_steps"][-10:] if workflow_state["processing_steps"] else []
    }

# High-level convenience functions for common tasks

def generate_column_summary(
    file_path: str, 
    column_name: str, 
    sheet_name: Optional[str] = None,
    batch_size: int = 50
) -> Dict[str, Any]:
    """
    Convenience function to create and run a column summary task.
    
    Args:
        file_path: Path to the Excel or CSV file
        column_name: Name of the column to summarize
        sheet_name: Specific sheet to process (for Excel files)
        batch_size: Number of rows to process in each batch (for text columns)
        
    Returns:
        Dictionary with task results
    """
    result = add_task(
        TaskType.COLUMN_SUMMARY,
        file_path,
        {"column_name": column_name, "batch_size": batch_size},
        priority=TaskPriority.MEDIUM,
        sheet_name=sheet_name
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def generate_row_summary(file_path: str, row_index: int, sheet_name: Optional[str] = None) -> Dict[str, Any]:
    """Convenience function to create and run a row summary task."""
    result = add_task(
        TaskType.ROW_SUMMARY,
        file_path,
        {"row_index": row_index},
        priority=TaskPriority.MEDIUM,
        sheet_name=sheet_name
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def generate_workbook_summary(file_path: str) -> Dict[str, Any]:
    """Convenience function to create and run a workbook summary task."""
    result = add_task(
        TaskType.WORKBOOK_SUMMARY,
        file_path,
        {}
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def classify_data(
    file_path: str,
    target_column: str,
    mode: str = "unsupervised",
    label_column: Optional[str] = None,
    class_definitions: Optional[Dict[str, str]] = None,
    sheet_name: Optional[str] = None,
    parallel_processing: bool = False,
    batch_size: int = 50,
    max_workers: int = 5
) -> Dict[str, Any]:
    """
    Convenience function to create and run a classification task.
    
    Args:
        file_path: Path to the Excel or CSV file
        target_column: Column to classify
        mode: Classification mode ('unsupervised', 'few-shot', or 'context')
        label_column: Column with labels for few-shot learning
        class_definitions: Dictionary of category:definition pairs
        sheet_name: Specific sheet to process (for Excel files)
        parallel_processing: Whether to use parallel processing for large datasets
        batch_size: Number of rows to process in each batch
        max_workers: Maximum number of parallel workers
        
    Returns:
        Dictionary with task results
    """
    if mode == "unsupervised":
        task_type = TaskType.CLASSIFICATION_UNSUPERVISED
    elif mode == "few_shot":
        task_type = TaskType.CLASSIFICATION_FEW_SHOT
    elif mode == "context":
        task_type = TaskType.CLASSIFICATION_CONTEXT
    else:
        return {"status": "error", "message": f"Invalid classification mode: {mode}"}
    
    parameters = {
        "target_column": target_column,
        "label_column": label_column,
        "class_definitions": class_definitions,
        "parallel_processing": parallel_processing,
        "batch_size": batch_size,
        "max_workers": max_workers
    }
    
    result = add_task(
        task_type,
        file_path,
        parameters,
        priority=TaskPriority.HIGH,
        sheet_name=sheet_name
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def generate_visualization(
    file_path: str,
    viz_type: Union[VisualizationType, str],
    x_column: str,
    y_column: Optional[str] = None,
    color_by: Optional[str] = None,
    sheet_name: Optional[str] = None,
    additional_params: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """Convenience function to create and run a visualization task."""
    # Convert string type to enum if needed
    if isinstance(viz_type, str):
        try:
            viz_type = VisualizationType(viz_type)
        except ValueError:
            return {"status": "error", "message": f"Invalid visualization type: {viz_type}"}
    
    parameters = {
        "visualization_type": viz_type,
        "x_column": x_column,
        "y_column": y_column,
        "color_by": color_by,
        "additional_params": additional_params or {}
    }
    
    result = add_task(
        TaskType.DATA_VISUALIZATION,
        file_path,
        parameters,
        priority=TaskPriority.MEDIUM,
        sheet_name=sheet_name
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def filter_data(
    file_path: str,
    query: str,
    sheet_name: Optional[str] = None
) -> Dict[str, Any]:
    """Convenience function to create and run a filter query task."""
    result = add_task(
        TaskType.FILTER_QUERY,
        file_path,
        {"query": query},
        priority=TaskPriority.MEDIUM,
        sheet_name=sheet_name
    )
    
    if result["status"] == "error":
        return result
    
    # Run the workflow
    run_result = run_workflow()
    
    if run_result.get("status") == "error":
        return run_result
    
    # Return the task result
    return get_task_result(result["task_id"])

def direct_row_summary(
    file_path: str,
    row_index: int, 
    sheet_name: Optional[str] = None,
    df: Optional[pd.DataFrame] = None,
    explicit_llm_client: Any = None
) -> Dict[str, Any]:
    """
    Generate a row summary directly without using the task queue.
    This is a faster version used by generate_all_row_summaries.
    
    Args:
        file_path: Path to the Excel or CSV file
        row_index: Index of the row to summarize
        sheet_name: Specific sheet to process (for Excel files)
        df: Optional pre-loaded DataFrame to use instead of loading from file
        explicit_llm_client: Optional explicit LLM client to use
        
    Returns:
        Dictionary with summary result
    """
    global workflow_state, llm_client
    
    print(f"Direct row summary for row {row_index}")
    print(f"Explicit llm_client: {explicit_llm_client}")
    print(f"Global llm_client: {llm_client}")
    print(f"Workflow state llm_client: {workflow_state.get('llm_client')}")
    
    # Use explicitly passed LLM client first, then global, then from workflow_state
    current_llm = explicit_llm_client
    if current_llm is None:
        current_llm = llm_client
        if current_llm is None:
            current_llm = workflow_state.get("llm_client")
            print(f"Using workflow_state llm_client: {current_llm}")
        else:
            print(f"Using global llm_client: {current_llm}")
    else:
        print(f"Using explicitly passed llm_client: {current_llm}")
    
    # If no LLM is initialized, return an error
    if current_llm is None:
        print("No LLM client available. Make sure to call initialize_system() first.")
        return {
            "status": "error",
            "message": "LLM client not initialized"
        }
    
    # Load the dataframe if not provided
    active_sheet = sheet_name
    if df is None:
        try:
            print(f"Loading dataframe for {file_path}, sheet: {sheet_name}")
            from .data_utils import load_excel_file
            dfs = load_excel_file(file_path, sheet_name)
            
            if not dfs:
                return {
                    "status": "error",
                    "message": f"No data found in file: {file_path}"
                }
            
            # Get the appropriate sheet
            if sheet_name and sheet_name in dfs:
                df = dfs[sheet_name]
                active_sheet = sheet_name
            else:
                # Use the first sheet if no specific sheet is requested
                active_sheet = next(iter(dfs))
                df = dfs[active_sheet]
                print(f"Using first sheet: {active_sheet}")
                
        except Exception as e:
            print(f"Error loading dataframe: {str(e)}")
            import traceback
            traceback.print_exc()
            return {
                "status": "error",
                "message": f"Error loading file: {str(e)}"
            }
    
    # Check if df is still None
    if df is None:
        print(f"DataFrame is None after loading attempt")
        return {
            "status": "error",
            "message": "Could not load DataFrame"
        }
    
    # Check if row_index is valid
    if row_index < 0 or row_index >= len(df):
        print(f"Invalid row index: {row_index}. Must be between 0 and {len(df)-1}")
        return {
            "status": "error",
            "message": f"Invalid row index: {row_index}. Must be between 0 and {len(df)-1}"
        }
    
    # Prepare the prompt
    try:
        from .processors import prepare_row_summary_prompt
        prompt, error = prepare_row_summary_prompt(df, row_index)
        
        if error:
            return {
                "status": "error",
                "message": error
            }
    except Exception as e:
        print(f"Error preparing prompt: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            "status": "error",
            "message": f"Error preparing prompt: {str(e)}"
        }
    
    # Call the LLM
    try:
        print(f"About to call LLM with prompt of length {len(prompt)} chars")
        response = current_llm.invoke(prompt)
        print(f"LLM response received, type: {type(response)}")
        # Return the result
        return {
            "status": "success",
            "file_path": file_path,
            "sheet_name": active_sheet,
            "row_index": row_index,
            "result": response
        }
    except Exception as e:
        print(f"Error calling LLM: {str(e)}")
        import traceback
        traceback.print_exc()
        return {
            "status": "error",
            "message": f"Error calling LLM: {str(e)}"
        }

def generate_all_row_summaries(
    file_path: str, 
    sheet_name: Optional[str] = None,
    max_rows: Optional[int] = None,
    start_row: int = 0,
    parallel_processing: bool = False,
    batch_size: int = 10,
    max_workers: int = 4
) -> Dict[str, Any]:
    """
    Generate summaries for all rows in a dataset and add them to a new column.
    
    Args:
        file_path: Path to the Excel or CSV file
        sheet_name: Specific sheet to process (for Excel files)
        max_rows: Maximum number of rows to process (default is all rows)
        start_row: Index of first row to process (default is 0)
        parallel_processing: Whether to use parallel processing (default is False)
        batch_size: Number of rows to process in each batch (default is 10)
        max_workers: Maximum number of parallel workers (default is 4)
        
    Returns:
        Dictionary with task results
    """
    global llm_client, workflow_state
    
    # Check if LLM is initialized
    print(f"Starting generate_all_row_summaries. Global llm_client: {llm_client}")
    print(f"Workflow state llm_client: {workflow_state.get('llm_client')}")
    
    # Determine which LLM client to use
    current_llm = llm_client
    if current_llm is None:
        current_llm = workflow_state.get('llm_client')
        
    if current_llm is None:
        return {
            "status": "error",
            "message": "LLM client not initialized. Call initialize_system() first."
        }
    
    # First, load the dataframe using data_utils to ensure consistent handling
    from .data_utils import load_excel_file
    
    try:
        print(f"Loading {file_path}...")
        dfs = load_excel_file(file_path, sheet_name)
        
        if not dfs:
            return {
                "status": "error",
                "message": f"No data found in file: {file_path}"
            }
        
        # If specific sheet was requested, use it, otherwise use the first sheet
        if sheet_name and sheet_name in dfs:
            active_sheet = sheet_name
            df = dfs[active_sheet]
        else:
            active_sheet = next(iter(dfs))
            df = dfs[active_sheet]
            
        print(f"Processing sheet: {active_sheet}")
        
    except Exception as e:
        return {
            "status": "error",
            "message": f"Error loading file: {str(e)}"
        }
    
    # Validate start_row
    if start_row < 0 or start_row >= len(df):
        return {
            "status": "error", 
            "message": f"Invalid start_row: {start_row}. Must be between 0 and {len(df)-1}"
        }
    
    # Determine how many rows to process
    end_row = len(df)
    if max_rows is not None:
        end_row = min(start_row + max_rows, len(df))
    
    total_rows = end_row - start_row
    
    print(f"Generating summaries for {total_rows} rows in {file_path} (rows {start_row} to {end_row-1})")
    
    # Create a new column for summaries
    if 'EXCEL_WORKFLOW_SUMMARY' not in df.columns:
        df['EXCEL_WORKFLOW_SUMMARY'] = None
    
    # Process rows
    row_summaries = []
    
    if parallel_processing:
        try:
            import concurrent.futures
            
            # Function to process each row
            def process_row(row_idx):
                if row_idx < start_row or row_idx >= end_row:
                    return None
                
                # Use direct_row_summary instead of going through the task queue
                result = direct_row_summary(file_path, row_idx, active_sheet, df, explicit_llm_client=current_llm)
                return (row_idx, result)
            
            # Process rows in batches
            for batch_start in range(start_row, end_row, batch_size):
                batch_end = min(batch_start + batch_size, end_row)
                batch_indices = list(range(batch_start, batch_end))
                
                print(f"Processing rows {batch_start} to {batch_end-1}...")
                
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    futures = [executor.submit(process_row, idx) for idx in batch_indices]
                    
                    for future in concurrent.futures.as_completed(futures):
                        result = future.result()
                        if result:
                            row_idx, summary_result = result
                            row_summaries.append(summary_result)
                            
                            # Extract summary text
                            summary_text = ""
                            if summary_result.get("result"):
                                if hasattr(summary_result["result"], "content"):
                                    summary_text = summary_result["result"].content
                                elif isinstance(summary_result["result"], str):
                                    summary_text = summary_result["result"]
                                elif isinstance(summary_result["result"], dict) and "summary" in summary_result["result"]:
                                    summary_text = summary_result["result"]["summary"]
                            
                            # Add to dataframe
                            if summary_text and row_idx < len(df):
                                df.at[row_idx, 'EXCEL_WORKFLOW_SUMMARY'] = summary_text
        
        except ImportError:
            print("Parallel processing not available, falling back to sequential processing")
            parallel_processing = False
    
    # Sequential processing (default or fallback)
    if not parallel_processing:
        for row_idx in range(start_row, end_row):
            print(f"Processing row {row_idx}...")
            # Use direct_row_summary instead of going through the task queue
            result = direct_row_summary(file_path, row_idx, active_sheet, df, explicit_llm_client=current_llm)
            row_summaries.append(result)
            
            # Extract summary text
            summary_text = ""
            if result.get("result"):
                if hasattr(result["result"], "content"):
                    summary_text = result["result"].content
                elif isinstance(result["result"], str):
                    summary_text = result["result"]
                elif isinstance(result["result"], dict) and "summary" in result["result"]:
                    summary_text = result["result"]["summary"]
            
            # Add to dataframe
            if summary_text:
                df.at[row_idx, 'EXCEL_WORKFLOW_SUMMARY'] = summary_text
    
    # Save the dataframe with summaries
    import os
    os.makedirs('output', exist_ok=True)
    
    base_name = os.path.basename(file_path)
    file_name_without_ext = os.path.splitext(base_name)[0]
    timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"output/{file_name_without_ext}_all_summaries_{timestamp}.xlsx"
    
    df.to_excel(output_file, index=False)
    
    return {
        "status": "success",
        "message": f"Generated summaries for {total_rows} rows",
        "output_file": output_file,
        "total_rows": total_rows,
        "rows_with_summaries": sum(df['EXCEL_WORKFLOW_SUMMARY'].notna()),
        "summaries": row_summaries
    }

def save_row_summary_to_excel(task_result: Dict[str, Any]) -> Optional[str]:
    """
    Save row summary results to Excel file with an EXCEL_WORKFLOW_SUMMARY column.
    
    Args:
        task_result: The task result dictionary
        
    Returns:
        Path to the output file or None if there was an error
    """
    # Check if this is a row summary task
    if not task_result.get("type") == TaskType.ROW_SUMMARY.value:
        return None
    
    # Get required values from the task result
    file_path = task_result.get("file_path")
    sheet_name = task_result.get("sheet_name")
    row_index = task_result.get("row_index")
    result = task_result.get("result")
    
    if not file_path or row_index is None or result is None:
        print(f"Missing required fields in task result")
        return None
    
    # Extract the summary text from the result
    summary_text = ""
    if hasattr(result, "content"):
        # This is likely an AIMessage
        summary_text = result.content
        print(f"Extracted content from AIMessage: {summary_text[:50]}...")
    elif isinstance(result, str):
        # This is a direct string
        summary_text = result
        print(f"Using string result directly: {summary_text[:50]}...")
    elif isinstance(result, dict) and "summary" in result:
        # This is a dictionary with a summary key
        summary_text = result["summary"]
        print(f"Extracted summary from dict: {summary_text[:50]}...")
    else:
        # Try to convert to string as a fallback
        try:
            summary_text = str(result)
            print(f"Converted result to string: {summary_text[:50]}...")
        except:
            print(f"Could not extract summary text from result type: {type(result)}")
            return None
    
    if not summary_text:
        print("Summary text is empty")
        return None
        
    try:
        # Create output directory if it doesn't exist
        os.makedirs("output", exist_ok=True)
        
        # Load the original file
        from .data_utils import load_excel_file
        dfs = load_excel_file(file_path, sheet_name)
        
        if not dfs:
            print(f"No data found in file: {file_path}")
            return None
        
        # Get the appropriate sheet
        active_sheet = sheet_name
        if sheet_name and sheet_name in dfs:
            df = dfs[sheet_name]
        else:
            # Use the first sheet if no specific sheet is requested
            active_sheet = next(iter(dfs))
            df = dfs[active_sheet]
        
        # Check if the row index is valid
        if row_index < 0 or row_index >= len(df):
            print(f"Invalid row index: {row_index}, max: {len(df)-1}")
            return None
        
        # Add or update the summary column
        if 'EXCEL_WORKFLOW_SUMMARY' not in df.columns:
            df['EXCEL_WORKFLOW_SUMMARY'] = None
            
        # Add the summary to the specified row
        df.at[row_index, 'EXCEL_WORKFLOW_SUMMARY'] = summary_text
        
        # Create output filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = os.path.basename(file_path)
        file_name_without_ext = os.path.splitext(base_name)[0]
        output_file = f"output/{file_name_without_ext}_summary_{timestamp}.xlsx"
        
        # Save the modified dataframe
        df.to_excel(output_file, sheet_name=active_sheet, index=False)
        print(f"Saved row summary to: {output_file}")
        
        return output_file
        
    except Exception as e:
        print(f"Error saving row summary to Excel: {str(e)}")
        import traceback
        traceback.print_exc()
        return None

def print_task_result(task_result: Dict[str, Any]) -> None:
    """Print task result in a user-friendly format."""
    if not task_result:
        print("No task result available.")
        return
    
    task_type = task_result.get("type")
    task_status = task_result.get("status")
    
    print(f"\nTask Result for {task_type} (Status: {task_status})")
    print("=" * 80)
    
    if task_status == TaskStatus.ERROR.value:
        print(f"Error: {task_result.get('error')}")
        return
    
    # For row summary tasks, save to Excel file
    if task_type == TaskType.ROW_SUMMARY.value:
        output_file = save_row_summary_to_excel(task_result)
        if output_file:
            print(f"Row summary saved to Excel file: {output_file}")
            return
        else:
            print("Failed to save row summary to Excel. Falling back to markdown output.")
    
    # Handle result content appropriately based on task type
    result = task_result.get("result")
    
    # Process different task types
    if task_type == TaskType.COLUMN_SUMMARY.value:
        column_name = task_result.get("column_name")
        print(f"Column Summary for '{column_name}':")
        print("-" * 80)
        _print_ai_response(result)
        
    elif task_type == TaskType.ROW_SUMMARY.value:
        row_index = task_result.get("row_index")
        file_path = task_result.get("file_path")
        sheet_name = task_result.get("sheet_name", "")
        
        print(f"Row Summary for row {row_index} in {file_path} (Sheet: {sheet_name}):")
        print("-" * 80)
        
        # Extract the content and append to markdown file
        content = _extract_ai_content(result)
        
        if content:
            # Create output directory if it doesn't exist
            os.makedirs("output", exist_ok=True)
            
            # Create filename based on the input file
            import os.path
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            base_name = os.path.basename(file_path)
            file_name_without_ext = os.path.splitext(base_name)[0]
            
            output_file = f"output/{file_name_without_ext}_row_{row_index}_{timestamp}.md"
            
            # Save to markdown file
            with open(output_file, 'w') as f:
                f.write(f"# Row {row_index} Summary for {file_path}\n\n")
                f.write(content)
                
            print(content[:500] + "..." if len(content) > 500 else content)
            print("\n" + "-" * 80)
            print(f"Full summary saved to: {output_file}")
        else:
            print("No content available in the result.")
    
    elif task_type == TaskType.WORKBOOK_SUMMARY.value:
        file_path = task_result.get("file_path")
        print(f"Workbook Summary for {file_path}:")
        print("-" * 80)
        _print_ai_response(result)
        
    elif task_type == TaskType.VISUALIZATION.value:
        column_name = task_result.get("column_name", "")
        visualization_type = task_result.get("visualization_type", "")
        print(f"Visualization for '{column_name}' (Type: {visualization_type}):")
        print("-" * 80)
        
        if "visualization_path" in task_result:
            print(f"Visualization saved to: {task_result['visualization_path']}")
        else:
            print("No visualization path available.")
    
    elif task_type == TaskType.CLASSIFICATION.value:
        column_name = task_result.get("column_name", "")
        classification_mode = task_result.get("classification_mode", "")
        print(f"Classification for '{column_name}' (Mode: {classification_mode}):")
        print("-" * 80)
        
        # Handle classification results
        if isinstance(result, dict) and "classifications" in result:
            print("Classifications:")
            for item, classification in result["classifications"].items():
                print(f"  {item}: {classification}")
        else:
            _print_ai_response(result)
    
    else:
        # Generic handling for other task types
        print("Result:")
        print("-" * 80)
        _print_ai_response(result)

def _extract_ai_content(result: Any) -> str:
    """
    Extract content from an AI response, handling different result types.
    
    Args:
        result: The AI result, which could be string, AIMessage, dict, etc.
        
    Returns:
        Extracted content as a string
    """
    if result is None:
        return ""
        
    if hasattr(result, "content"):
        # This is likely an AIMessage
        return result.content
    
    if isinstance(result, str):
        # Direct string result
        return result
        
    if isinstance(result, dict):
        # Dictionary with potential content
        if "content" in result:
            return result["content"]
        elif "summary" in result:
            return result["summary"]
        elif "text" in result:
            return result["text"]
            
    # Try to convert to string as fallback
    try:
        return str(result)
    except:
        return ""

def _print_ai_response(result: Any) -> None:
    """
    Print an AI response in a user-friendly format.
    
    Args:
        result: The AI result, which could be string, AIMessage, dict, etc.
    """
    content = _extract_ai_content(result)
    if content:
        print(content)
    else:
        print("No content available in the result.") 