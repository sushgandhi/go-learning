import pandas as pd
import os
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64

from .state import ExcelWorkflowState, ExcelTask, VisualizationType

def load_excel_file(file_path: str, sheet_name: Optional[str] = None) -> Dict[str, pd.DataFrame]:
    """
    Load an Excel file into pandas DataFrames.
    Returns a dictionary mapping sheet names to DataFrames.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")
    
    if file_path.endswith('.csv'):
        df = pd.read_csv(file_path)
        return {"Sheet1": df}  # For CSV, use a default sheet name
    elif file_path.endswith(('.xls', '.xlsx', '.xlsm')):
        if sheet_name:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            if isinstance(df, pd.DataFrame):
                return {sheet_name: df}
            else:
                return df  # Already a dict of sheet_name -> DataFrame
        else:
            return pd.read_excel(file_path, sheet_name=None)  # Read all sheets
    else:
        raise ValueError(f"Unsupported file format: {file_path}")

def get_dataframe_key(file_path: str, sheet_name: Optional[str] = None) -> str:
    """Create a unique key for the dataframe in the state dictionary."""
    if not sheet_name and (file_path.endswith('.csv')):
        sheet_name = "Sheet1"  # Default sheet name for CSV
    elif not sheet_name:
        sheet_name = "default"  # Fallback
    
    return f"{file_path}:{sheet_name}"

def load_dataframe(state: ExcelWorkflowState, file_path: str, sheet_name: Optional[str] = None) -> ExcelWorkflowState:
    """Load a dataframe into the state."""
    try:
        dfs = load_excel_file(file_path, sheet_name)
        
        # Update the state with loaded dataframes
        for sheet, df in dfs.items():
            df_key = get_dataframe_key(file_path, sheet)
            state["dataframes"][df_key] = df
            if df_key not in state["loaded_sheets"]:
                state["loaded_sheets"].append(df_key)
        
        # Add a processing step
        state["processing_steps"].append(f"Loaded dataframe(s) from {file_path}")
        return state
    
    except Exception as e:
        state["error_message"] = f"Error loading data: {str(e)}"
        state["processing_steps"].append(f"Failed to load data from {file_path}: {str(e)}")
        return state

def get_dataframe_from_task(state: ExcelWorkflowState) -> Tuple[Optional[pd.DataFrame], Optional[str]]:
    """Get the DataFrame associated with the current task."""
    if not state["current_task"]:
        return None, "No current task"
    
    task = state["current_task"]
    file_path = task["file_path"]
    sheet_name = task["sheet_name"]
    
    df_key = get_dataframe_key(file_path, sheet_name)
    
    # Load the dataframe if it's not already loaded
    if df_key not in state["dataframes"]:
        state = load_dataframe(state, file_path, sheet_name)
        if state["error_message"]:
            return None, state["error_message"]
    
    return state["dataframes"].get(df_key), None

def generate_visualization(
    df: pd.DataFrame,
    viz_type: VisualizationType,
    x_column: str,
    y_column: Optional[str] = None,
    color_by: Optional[str] = None,
    **kwargs
) -> Tuple[Optional[str], Optional[str]]:
    """
    Generate a visualization and return it as a base64-encoded string.
    Returns (base64_image, error_message)
    """
    try:
        plt.figure(figsize=(10, 6))
        
        if x_column not in df.columns:
            return None, f"Column '{x_column}' not found"
        
        if y_column and y_column not in df.columns:
            return None, f"Column '{y_column}' not found"
        
        if color_by and color_by not in df.columns:
            return None, f"Column '{color_by}' not found"
        
        # Create different types of plots based on the visualization type
        if viz_type == VisualizationType.BAR_CHART:
            if y_column:
                df.plot(kind='bar', x=x_column, y=y_column, color=df[color_by] if color_by else None)
            else:
                df[x_column].value_counts().plot(kind='bar')
                
        elif viz_type == VisualizationType.HISTOGRAM:
            df[x_column].hist(bins=kwargs.get('bins', 10))
            
        elif viz_type == VisualizationType.LINE_CHART:
            if y_column:
                df.plot(kind='line', x=x_column, y=y_column)
            else:
                df[x_column].plot(kind='line')
                
        elif viz_type == VisualizationType.SCATTER_PLOT:
            if not y_column:
                return None, "Y column is required for scatter plots"
            if color_by:
                plt.scatter(df[x_column], df[y_column], c=df[color_by].astype('category').cat.codes)
            else:
                plt.scatter(df[x_column], df[y_column])
                
        elif viz_type == VisualizationType.PIE_CHART:
            df[x_column].value_counts().plot(kind='pie')
            
        elif viz_type == VisualizationType.HEATMAP:
            if not y_column:
                return None, "Y column is required for heatmaps"
            pivot_table = pd.pivot_table(df, values=kwargs.get('values'), index=x_column, columns=y_column)
            plt.imshow(pivot_table, cmap='viridis')
            plt.colorbar()
            plt.xticks(range(len(pivot_table.columns)), pivot_table.columns, rotation=90)
            plt.yticks(range(len(pivot_table.index)), pivot_table.index)
            
        elif viz_type == VisualizationType.BOX_PLOT:
            if y_column:
                df.boxplot(column=y_column, by=x_column)
            else:
                df.boxplot(column=x_column)
        
        plt.title(kwargs.get('title', f'{viz_type.value} of {x_column}' + (f' vs {y_column}' if y_column else '')))
        plt.xlabel(kwargs.get('xlabel', x_column))
        plt.ylabel(kwargs.get('ylabel', y_column if y_column else 'Frequency'))
        plt.tight_layout()
        
        # Save the plot to a BytesIO object
        buffer = BytesIO()
        plt.savefig(buffer, format='png')
        buffer.seek(0)
        image_png = buffer.getvalue()
        buffer.close()
        plt.close()
        
        # Encode the image as base64
        graph = base64.b64encode(image_png).decode('utf-8')
        return graph, None
        
    except Exception as e:
        plt.close()
        return None, f"Error generating visualization: {str(e)}"

def natural_language_filter(df: pd.DataFrame, query: str, llm_client: Any) -> Tuple[Optional[pd.DataFrame], Optional[str]]:
    """
    Filter a DataFrame based on a natural language query.
    Uses the LLM to convert the query to a pandas query.
    """
    try:
        # Create a prompt for the LLM
        prompt = f"""
        You are a data analysis assistant. Convert the following natural language query into a valid pandas query expression.
        
        DataFrame columns: {', '.join(df.columns.tolist())}
        Sample data (first 5 rows):
        {df.head().to_string()}
        
        User query: "{query}"
        
        Respond with ONLY the pandas query string that can be passed to df.query() or df[...] without any explanation.
        If you need to filter by a string value, make sure to include quotes. For example: `df[df['column'] == 'value']`
        """
        
        # Get the pandas query from the LLM
        response = llm_client.invoke(prompt)
        
        # Clean the response
        pandas_query = response.strip()
        if pandas_query.startswith("```") and pandas_query.endswith("```"):
            pandas_query = pandas_query[3:-3].strip()
        if pandas_query.startswith("python"):
            pandas_query = pandas_query[6:].strip()
            
        # Try to execute the query
        try:
            if pandas_query.startswith("df[") or pandas_query.startswith("df.loc[") or pandas_query.startswith("df.iloc["):
                # Handle direct filtering
                filtered_df = eval(pandas_query, {"df": df, "pd": pd, "np": np})
            else:
                # Handle df.query()
                filtered_df = df.query(pandas_query)
                
            if len(filtered_df) == 0:
                return filtered_df, "Query returned no results"
                
            return filtered_df, None
            
        except Exception as e:
            return None, f"Error executing pandas query '{pandas_query}': {str(e)}"
    
    except Exception as e:
        return None, f"Error processing natural language filter: {str(e)}" 