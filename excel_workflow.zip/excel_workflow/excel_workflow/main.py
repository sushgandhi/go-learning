import argparse
import os
import json
import pandas as pd
from typing import Dict, Any, List, Optional

from .api import (
    initialize_system,
    reset_system,
    load_excel_file,
    get_loaded_files,
    add_task,
    run_workflow,
    get_task_result,
    get_queue_status,
    generate_column_summary,
    generate_row_summary,
    generate_workbook_summary,
    classify_data,
    generate_visualization,
    filter_data,
    generate_all_row_summaries
)

from .state import TaskType, TaskPriority, VisualizationType

def setup_llm():
    """Set up and return an LLM client."""
    # Try to load several possible LLMs in order of preference
    try:
        from langchain_google_genai import ChatGoogleGenerativeAI
        llm = ChatGoogleGenerativeAI(model="gemini-2.0-flash")
        llm.invoke("test")  # Quick test
        print("Successfully initialized Google's Gemini Pro model")
        return llm
    except Exception as e:
        print(f"Could not initialize Gemini: {e}")
    
    try:
        from langchain_community.chat_models import ChatOllama
        llm = ChatOllama(model="llama3")
        llm.invoke("test")  # Quick test
        print("Successfully initialized ChatOllama with llama3")
        return llm
    except Exception as e:
        print(f"Could not initialize ChatOllama: {e}")
    
    try:
        from langchain_openai import ChatOpenAI
        llm = ChatOpenAI()
        llm.invoke("test")  # Quick test
        print("Successfully initialized ChatOpenAI")
        return llm
    except Exception as e:
        print(f"Could not initialize ChatOpenAI: {e}")
    
    # Fallback to the dummy LLM
    from excel_classification import DummyLLM
    print("Using DummyLLM for demonstration purposes")
    return DummyLLM()

def save_row_summary_to_excel(result: Dict[str, Any]) -> None:
    """
    Save row summary results to an Excel file with an added EXCEL_WORKFLOW_SUMMARY column.
    This function takes a result dictionary from a row summary task and exports the 
    original data with the summary added as a new column.
    """
    import pandas as pd
    import os
    
    # Check if this is a row summary task
    if str(result.get('type', '')) != 'row_summary' and not str(result.get('type', '')).endswith('ROW_SUMMARY'):
        print("This function is only for row summary tasks.")
        return
    
    # Extract file path
    file_path = result.get('file_path')
    if not file_path and 'parameters' in result:
        file_path = result['parameters'].get('file_path')
    
    if not file_path:
        print("Error: Could not determine source file path")
        return
    
    # Get row index from parameters
    row_index = None
    if 'parameters' in result and 'row_index' in result['parameters']:
        row_index = result['parameters']['row_index']
    
    if row_index is None:
        print("Error: Could not determine row index")
        return
    
    # Check if result is available
    if not result.get('result'):
        print("Error: No result data available")
        return
    
    # Extract the summary text
    summary_text = ""
    if hasattr(result['result'], 'content'):
        # For AIMessage objects
        summary_text = result['result'].content
    elif isinstance(result['result'], str):
        summary_text = result['result']
    elif isinstance(result['result'], dict) and 'summary' in result['result']:
        summary_text = result['result']['summary']
    else:
        print("Error: Could not extract summary text from result")
        return
    
    # Load the original file
    try:
        if file_path.endswith('.csv'):
            df = pd.read_csv(file_path)
        elif file_path.endswith(('.xlsx', '.xls')):
            # If there's a sheet name in the result, use it, otherwise use default
            sheet_name = result.get('sheet_name', 0)
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        else:
            print(f"Unsupported file type: {file_path}")
            return
    except Exception as e:
        print(f"Error loading file: {e}")
        return
    
    # Check if row index is valid
    if row_index < 0 or row_index >= len(df):
        print(f"Error: Row index {row_index} is out of bounds (0-{len(df)-1})")
        return
    
    # Create output directory if it doesn't exist
    os.makedirs('output', exist_ok=True)
    
    # Add the summary column to the dataframe
    df['EXCEL_WORKFLOW_SUMMARY'] = None
    df.at[row_index, 'EXCEL_WORKFLOW_SUMMARY'] = summary_text
    
    # Generate output file name
    base_name = os.path.basename(file_path)
    file_name_without_ext = os.path.splitext(base_name)[0]
    timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"output/{file_name_without_ext}_with_summary_{timestamp}.xlsx"
    
    # Save to Excel
    df.to_excel(output_file, index=False)
    print(f"Row summary saved to Excel file: {output_file}")

def print_task_result(result: Dict[str, Any]):
    """Pretty print a task result and save it to a markdown file or Excel file for row summaries."""
    # Check if this is a row summary task and save to Excel if it is
    task_type = str(result.get('type', ''))
    if task_type == 'row_summary' or task_type.endswith('ROW_SUMMARY'):
        save_row_summary_to_excel(result)
        return
    
    # Create output directory if it doesn't exist
    os.makedirs('output', exist_ok=True)
    
    # Extract file path from result or parameters
    file_path = result.get('file_path')
    if not file_path and 'parameters' in result:
        # Try to get it from parameters
        file_path = result['parameters'].get('file_path')
    
    # Generate filename based on input file and task type
    if file_path:
        input_file = os.path.basename(file_path)
    else:
        input_file = "unknown_file"
    
    # Get task type, ensuring it's a string
    task_type = str(result.get('type', 'task'))
    if '<' in task_type and '>' in task_type:  # Handle TaskType enum objects
        task_type = task_type.split('.')[1].split(':')[0].lower()
    
    timestamp = pd.Timestamp.now().strftime('%Y%m%d_%H%M%S')
    output_file = f"output/{input_file.split('.')[0]}_{task_type}_{timestamp}.md"
    
    # Prepare output content
    output_content = [
        f"# {task_type.replace('_', ' ').title()} Results",
        f"**Task ID**: {result['id']}",
        f"**Status**: {result['status']}",
        f"**Input File**: {file_path or 'N/A'}",
        f"**Timestamp**: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}"
    ]
    
    # Check for errors (handle both None and actual error message)
    if 'error' in result and result['error'] is not None:
        error_message = result['error']
        print(f"Error: {error_message}")
        output_content.append(f"\n## Error\n{error_message}")
        
        # Write content to markdown file
        with open(output_file, 'w') as f:
            f.write('\n\n'.join(output_content))
        print(f"Error details saved to {output_file}")
        return
    
    # Process results
    if result.get("result"):
        # Handle AIMessage objects from Gemini
        if hasattr(result["result"], "content"):
            print("Result generated successfully (AIMessage format).")
            content = result["result"].content
            output_content.append(f"\n## Result\n{content}")
        elif isinstance(result["result"], str):
            print("Result generated successfully.")
            output_content.append(f"\n## Result\n{result['result']}")
        elif isinstance(result["result"], dict):
            print("Result generated successfully.")
            
            if "image_data" in result["result"]:
                output_content.append("\n## Visualization\nVisualization generated. Use the 'save_visualization' command to save it.")
                print("Visualization generated. To view the visualization, use the 'save_visualization' command.")
            elif "filtered_data" in result["result"]:
                summary = result["result"]["summary"]
                output_content.append(
                    f"\n## Filtered Data\n"
                    f"- Original rows: {summary['original_rows']}\n"
                    f"- Filtered rows: {summary['filtered_rows']}\n"
                    f"- Reduction: {summary['reduction_percentage']}%\n"
                )
                print(f"Filtered data: {summary['filtered_rows']} rows from {summary['original_rows']} ({summary['reduction_percentage']}% reduction)")
            elif "classified_data" in result["result"]:
                output_content.append("\n## Classification Results\n")
                for category, count in result["result"]["summary"]["classification_counts"].items():
                    output_content.append(f"- {category}: {count} rows")
                
                print("Classification completed successfully.")
            elif "summary" in result["result"]:
                # For column and row summaries
                output_content.append(f"\n## Summary\n{result['result']['summary']}")
                
                if "processed_with" in result["result"]:
                    output_content.append(f"\n**Processed with**: {result['result']['processed_with']}")
                
                if "batch_summaries" in result["result"]:
                    output_content.append(f"\n**Number of batches**: {result['result']['num_batches']}")
                    
                print("Summary generated successfully.")
            else:
                output_content.append("\n## Result Details\n```json\n" + json.dumps(result["result"], indent=2) + "\n```")
        else:
            # Handle other non-standard result types
            print(f"Result of type {type(result['result'])} generated.")
            try:
                output_content.append(f"\n## Result\n{str(result['result'])}")
            except:
                output_content.append("\n## Result\nResult contains non-serializable data")
    else:
        output_content.append("\n## Note\nNo detailed results available.")
    
    # Write content to markdown file
    with open(output_file, 'w') as f:
        f.write('\n\n'.join(output_content))
    
    print(f"Results saved to {output_file}")

def save_visualization(task_id: str, output_file: str):
    """Save a visualization to a file."""
    result = get_task_result(task_id)
    
    if "error" in result:
        print(f"Error: {result['error']}")
        return
    
    if not result.get("result") or not result["result"].get("image_data"):
        print("No visualization data found in task result")
        return
    
    import base64
    with open(output_file, "wb") as f:
        f.write(base64.b64decode(result["result"]["image_data"]))
    
    print(f"Visualization saved to {output_file}")

def save_processed_data(task_id: str, output_file: str):
    """Save processed data to a CSV or Excel file."""
    result = get_task_result(task_id)
    
    if "error" in result and result["error"] is not None:
        print(f"Error: {result['error']}")
        return
    
    # Check if this is a row summary task
    task_type = str(result.get('type', ''))
    if task_type == 'row_summary' or task_type.endswith('ROW_SUMMARY'):
        save_row_summary_to_excel(result)
        return
    
    data = None
    
    if result.get("result"):
        if "filtered_data" in result["result"]:
            data = pd.DataFrame(result["result"]["filtered_data"])
        elif "classified_data" in result["result"]:
            data = pd.DataFrame(result["result"]["classified_data"])
    
    if data is None:
        print("No processable data found in task result")
        return
    
    # Save based on file extension
    if output_file.endswith(".csv"):
        data.to_csv(output_file, index=False)
    elif output_file.endswith((".xlsx", ".xls")):
        data.to_excel(output_file, index=False)
    else:
        print(f"Unsupported file format: {output_file}")
        return
    
    print(f"Data saved to {output_file}")

def interactive_mode():
    """Run the system in interactive command-line mode."""
    print("=== Excel Workflow System - Interactive Mode ===")
    print("Type 'help' for a list of commands")
    
    while True:
        command = input("\nCommand> ").strip()
        
        if command == "":
            continue
        
        parts = command.split()
        cmd = parts[0].lower()
        
        if cmd == "exit" or cmd == "quit":
            print("Exiting...")
            break
        
        elif cmd == "help":
            print("""
Available commands:
  load <file_path> [sheet_name]       Load an Excel/CSV file
  files                               List loaded files
  summarize-column <file> <column>    Generate a column summary
      [--batch-size=50]               Batch size for text column processing
  summarize-row <file> <row_index>    Generate a row summary
      [--all-rows]                    Process all rows (ignores row_index if specified)
      [--start-row=N]                 Start row index (for processing a range of rows)
      [--end-row=N]                   End row index (for processing a range of rows)
      [--parallel]                    Use parallel processing for multiple rows
      [--batch-size=10]               Batch size for processing
      [--workers=4]                   Number of workers
  summarize-workbook <file>           Generate a workbook summary
  classify <file> <column> [mode]     Classify data in a column (modes: unsupervised, few-shot, context)
      [--parallel]                    Use parallel processing for large datasets
      [--batch-size=50]               Batch size for classification
      [--workers=4]                   Number of parallel workers
  visualize <file> <type> <x> [y]     Generate a visualization
  filter <file> <query>               Filter data using natural language
  queue                               Show the task queue status
  run                                 Run the workflow to process tasks
  reset                               Reset the system
  save-viz <task_id> <output_file>    Save a visualization to a file
  save-data <task_id> <output_file>   Save processed data to a file
  result <task_id>                    Show detailed result for a task
  exit                                Exit the program
            """)
        
        elif cmd == "load":
            if len(parts) < 2:
                print("Usage: load <file_path> [sheet_name]")
                continue
            
            file_path = parts[1]
            sheet_name = parts[2] if len(parts) > 2 else None
            
            result = load_excel_file(file_path, sheet_name)
            print(f"{result['status'].capitalize()}: {result['message']}")
            
            if result['status'] == 'success' and 'sheets' in result:
                print("Loaded sheets:")
                for sheet in result['sheets']:
                    print(f"  {sheet}")
        
        elif cmd == "files":
            files = get_loaded_files()
            if not files:
                print("No files loaded")
                continue
            
            for file in files:
                print(f"\nFile: {file['file_name']}")
                print(f"Path: {file['file_path']}")
                print(f"Sheets: {len(file['sheets'])}")
                print(f"Total rows: {file['total_rows']}")
                
                for sheet in file['sheets']:
                    print(f"  - {sheet['name']}: {sheet['rows']} rows, {sheet['columns']} columns")
        
        elif cmd == "summarize-column":
            # Parse command and options
            file_path = None
            column_name = None
            sheet_name = None
            batch_size = 50
            
            # Process the command arguments
            i = 1
            while i < len(parts):
                if parts[i].startswith("--"):
                    # Handle options
                    option = parts[i][2:].split("=")
                    if option[0] == "batch-size" and len(option) > 1:
                        try:
                            batch_size = int(option[1])
                        except ValueError:
                            print(f"Invalid batch size value: {option[1]}")
                            batch_size = 50
                elif not file_path:
                    file_path = parts[i]
                elif not column_name:
                    column_name = parts[i]
                elif not sheet_name:
                    sheet_name = parts[i]
                i += 1
            
            if not file_path or not column_name:
                print("Usage: summarize-column <file_path> <column_name> [sheet_name] [--batch-size=50]")
                continue
            
            print(f"Generating summary for column '{column_name}' in {file_path} (batch size: {batch_size})...")
            result = generate_column_summary(file_path, column_name, sheet_name, batch_size=batch_size)
            print_task_result(result)
        
        elif cmd == "summarize-row":
            # Parse command and options
            file_path = None
            row_index = None
            sheet_name = None
            all_rows = False
            start_row = None
            end_row = None
            parallel = False
            batch_size = 10
            workers = 4
            
            # Process the command arguments
            i = 1
            while i < len(parts):
                if parts[i].startswith("--"):
                    # Handle options
                    option = parts[i][2:].split("=")
                    if option[0] == "all-rows":
                        all_rows = True
                    elif option[0] == "start-row" and len(option) > 1:
                        try:
                            start_row = int(option[1])
                        except ValueError:
                            print(f"Invalid start row value: {option[1]}")
                    elif option[0] == "end-row" and len(option) > 1:
                        try:
                            end_row = int(option[1])
                        except ValueError:
                            print(f"Invalid end row value: {option[1]}")
                    elif option[0] == "parallel":
                        parallel = True
                    elif option[0] == "batch-size" and len(option) > 1:
                        try:
                            batch_size = int(option[1])
                        except ValueError:
                            print(f"Invalid batch size value: {option[1]}")
                    elif option[0] == "workers" and len(option) > 1:
                        try:
                            workers = int(option[1])
                        except ValueError:
                            print(f"Invalid workers value: {option[1]}")
                elif not file_path:
                    file_path = parts[i]
                elif row_index is None and not all_rows:
                    try:
                        row_index = int(parts[i])
                    except ValueError:
                        print(f"Invalid row index: {parts[i]}. Using as sheet name.")
                        sheet_name = parts[i]
                elif not sheet_name:
                    sheet_name = parts[i]
                i += 1
            
            if not file_path:
                print("Usage: summarize-row <file_path> [row_index] [sheet_name] [--all-rows] [--start-row=N] [--end-row=N] [--parallel] [--batch-size=10] [--workers=4]")
                continue
            
            # Process all rows or a range of rows
            if all_rows or (start_row is not None and end_row is not None):
                # Process all rows
                max_rows = None
                if start_row is not None and end_row is not None:
                    if end_row < start_row:
                        print(f"Error: end_row ({end_row}) must be greater than or equal to start_row ({start_row})")
                        continue
                    max_rows = end_row - start_row + 1
                
                print(f"Generating summaries for {'all' if all_rows else f'rows {start_row} to {end_row}'} in {file_path}...")
                result = generate_all_row_summaries(
                    file_path,
                    sheet_name=sheet_name,
                    max_rows=max_rows,
                    start_row=start_row if start_row is not None else 0,
                    parallel_processing=parallel,
                    batch_size=batch_size,
                    max_workers=workers
                )
                
                if result["status"] == "success":
                    print(f"Successfully generated summaries for {result['rows_with_summaries']} out of {result['total_rows']} rows")
                    print(f"Output saved to: {result['output_file']}")
                else:
                    print(f"Error: {result['message']}")
            else:
                # Process a single row
                if row_index is None:
                    print("Error: row_index is required when not using --all-rows")
                    continue
                
                print(f"Generating summary for row {row_index} in {file_path}...")
                result = generate_row_summary(file_path, row_index, sheet_name)
                print_task_result(result)
        
        elif cmd == "summarize-workbook":
            if len(parts) < 2:
                print("Usage: summarize-workbook <file_path>")
                continue
            
            file_path = parts[1]
            
            print(f"Generating summary for workbook {file_path}...")
            result = generate_workbook_summary(file_path)
            print_task_result(result)
        
        elif cmd == "classify":
            # Parse command and options
            file_path = None
            column_name = None
            mode = "unsupervised"
            sheet_name = None
            parallel = False
            batch_size = 50
            workers = 4
            class_definitions = None
            
            # Process the command arguments
            i = 1
            while i < len(parts):
                if parts[i].startswith("--"):
                    # Handle options
                    option = parts[i][2:].split("=")
                    if option[0] == "parallel":
                        parallel = True
                    elif option[0] == "batch-size" and len(option) > 1:
                        try:
                            batch_size = int(option[1])
                        except ValueError:
                            print(f"Invalid batch size value: {option[1]}")
                    elif option[0] == "workers" and len(option) > 1:
                        try:
                            workers = int(option[1])
                        except ValueError:
                            print(f"Invalid workers value: {option[1]}")
                    elif option[0] == "definitions" and len(option) > 1:
                        try:
                            import json
                            with open(option[1], 'r') as f:
                                class_definitions = json.load(f)
                            print(f"Loaded {len(class_definitions)} class definitions from {option[1]}")
                        except Exception as e:
                            print(f"Error loading class definitions: {str(e)}")
                elif not file_path:
                    file_path = parts[i]
                elif not column_name:
                    column_name = parts[i]
                elif mode == "unsupervised" and parts[i] in ["unsupervised", "few-shot", "context"]:
                    mode = parts[i]
                elif not sheet_name:
                    sheet_name = parts[i]
                i += 1
            
            if not file_path or not column_name:
                print("Usage: classify <file_path> <column_name> [mode] [sheet_name] [--parallel] [--batch-size=50] [--workers=4] [--definitions=file.json]")
                print("Modes: unsupervised, few-shot, context")
                continue
            
            processing_desc = "parallel" if parallel else "sequential"
            print(f"Classifying data in column '{column_name}' using {mode} mode ({processing_desc} processing)...")
            result = classify_data(
                file_path, 
                column_name, 
                mode, 
                sheet_name=sheet_name,
                class_definitions=class_definitions,
                parallel_processing=parallel,
                batch_size=batch_size,
                max_workers=workers
            )
            print_task_result(result)
        
        elif cmd == "visualize":
            if len(parts) < 4:
                print("Usage: visualize <file_path> <viz_type> <x_column> [y_column] [sheet_name]")
                print("Visualization types: bar_chart, histogram, line_chart, scatter_plot, pie_chart, heatmap, box_plot")
                continue
            
            file_path = parts[1]
            viz_type = parts[2]
            x_column = parts[3]
            y_column = parts[4] if len(parts) > 4 else None
            sheet_name = parts[5] if len(parts) > 5 else None
            
            print(f"Generating {viz_type} visualization for {file_path}...")
            result = generate_visualization(file_path, viz_type, x_column, y_column, sheet_name=sheet_name)
            print_task_result(result)
        
        elif cmd == "filter":
            if len(parts) < 3:
                print("Usage: filter <file_path> <query> [sheet_name]")
                continue
            
            file_path = parts[1]
            query = " ".join(parts[2:])
            
            print(f"Filtering data in {file_path} with query: '{query}'...")
            result = filter_data(file_path, query)
            print_task_result(result)
        
        elif cmd == "queue":
            status = get_queue_status()
            
            print("\nQueue Status:")
            print(f"Pending tasks: {status['pending_tasks']}")
            print(f"Completed tasks: {status['completed_tasks']}")
            
            if status['current_task']:
                print("\nCurrent task:")
                print(f"ID: {status['current_task']['id']}")
                print(f"Type: {status['current_task']['type']}")
                print(f"Status: {status['current_task']['status']}")
                print(f"File: {status['current_task']['file_path']}")
                if status['current_task']['sheet_name']:
                    print(f"Sheet: {status['current_task']['sheet_name']}")
            
            if status['processing_steps']:
                print("\nRecent processing steps:")
                for step in status['processing_steps']:
                    print(f"  {step}")
        
        elif cmd == "run":
            print("Running workflow...")
            result = run_workflow()
            
            print(f"Status: {result.get('status', 'unknown')}")
            
            if result.get('completed_tasks'):
                print(f"Completed {len(result['completed_tasks'])} tasks")
                for task in result['completed_tasks']:
                    print(f"  - {task['id']}: {task['type']} ({task['status']})")
            
            if result.get('pending_tasks'):
                print(f"Pending tasks: {result['pending_tasks']}")
        
        elif cmd == "reset":
            confirm = input("Are you sure you want to reset the system? (y/n) ")
            if confirm.lower() == 'y':
                reset_system()
                print("System reset")
        
        elif cmd == "save-viz":
            if len(parts) < 3:
                print("Usage: save-viz <task_id> <output_file>")
                continue
            
            task_id = parts[1]
            output_file = parts[2]
            
            save_visualization(task_id, output_file)
        
        elif cmd == "save-data":
            if len(parts) < 3:
                print("Usage: save-data <task_id> <output_file>")
                continue
            
            task_id = parts[1]
            output_file = parts[2]
            
            save_processed_data(task_id, output_file)
        
        elif cmd == "result":
            if len(parts) < 2:
                print("Usage: result <task_id>")
                continue
            
            task_id = parts[1]
            result = get_task_result(task_id)
            print_task_result(result)
        
        else:
            print(f"Unknown command: {cmd}")
            print("Type 'help' for a list of commands")

def main():
    parser = argparse.ArgumentParser(description="Excel Workflow System")
    parser.add_argument("--interactive", action="store_true", help="Run in interactive mode")
    parser.add_argument("--file", help="Input Excel/CSV file")
    parser.add_argument("--output", help="Output file path")
    parser.add_argument("--action", choices=[
        "summarize-column", "summarize-row", "summarize-workbook",
        "classify", "visualize", "filter"
    ], help="Action to perform")
    parser.add_argument("--column", help="Target column name")
    parser.add_argument("--row", type=int, help="Target row index")
    parser.add_argument("--sheet", help="Sheet name")
    parser.add_argument("--viz-type", help="Visualization type")
    parser.add_argument("--x-column", help="X-axis column for visualization")
    parser.add_argument("--y-column", help="Y-axis column for visualization")
    parser.add_argument("--query", help="Filter query")
    parser.add_argument("--mode", choices=["unsupervised", "few-shot", "context"], 
                        default="unsupervised", help="Classification mode")
    
    # Advanced options
    parser.add_argument("--batch-size", type=int, default=50, 
                        help="Batch size for processing text columns")
    parser.add_argument("--all-rows", action="store_true",
                        help="Process all rows (for summarize-row action)")
    parser.add_argument("--start-row", type=int,
                        help="Start row index (for processing a range of rows)")
    parser.add_argument("--end-row", type=int,
                        help="End row index (for processing a range of rows)")
    parser.add_argument("--parallel", action="store_true", 
                        help="Use parallel processing for classification or multiple rows")
    parser.add_argument("--workers", type=int, default=4, 
                        help="Number of parallel workers")
    parser.add_argument("--definitions", help="Path to JSON file with class definitions")
    
    args = parser.parse_args()
    
    # Initialize the LLM
    llm = setup_llm()
    initialize_system(llm)
    
    if args.interactive:
        interactive_mode()
        return
    
    # Non-interactive mode
    if args.file:
        print(f"Loading file: {args.file}")
        result = load_excel_file(args.file, args.sheet)
        print(f"{result['status'].capitalize()}: {result['message']}")
        
        if result['status'] != 'success':
            return
        
        # Load class definitions if provided
        class_definitions = None
        if args.definitions and args.action == "classify" and args.mode == "context":
            try:
                with open(args.definitions, 'r') as f:
                    import json
                    class_definitions = json.load(f)
                print(f"Loaded {len(class_definitions)} class definitions from {args.definitions}")
            except Exception as e:
                print(f"Error loading class definitions: {e}")
                return
        
        if args.action == "summarize-column":
            if not args.column:
                print("Error: --column is required for summarize-column action")
                return
            
            print(f"Generating summary for column '{args.column}'...")
            result = generate_column_summary(args.file, args.column, args.sheet, batch_size=args.batch_size)
            print_task_result(result)
            
        elif args.action == "summarize-row":
            # Handle row summaries with various options
            if not args.all_rows and args.row is None and args.start_row is None and args.end_row is None:
                print("Error: --row, --all-rows, or --start-row/--end-row is required for summarize-row action")
                return
            
            # Process all rows or a range of rows
            if args.all_rows or (args.start_row is not None and args.end_row is not None):
                # Validate range if specified
                max_rows = None
                start_row = 0
                
                if args.start_row is not None and args.end_row is not None:
                    if args.end_row < args.start_row:
                        print(f"Error: --end-row ({args.end_row}) must be greater than or equal to --start-row ({args.start_row})")
                        return
                    max_rows = args.end_row - args.start_row + 1
                    start_row = args.start_row
                
                print(f"Generating summaries for {'all' if args.all_rows else f'rows {args.start_row} to {args.end_row}'} in {args.file}...")
                result = generate_all_row_summaries(
                    args.file, 
                    sheet_name=args.sheet,
                    max_rows=max_rows,
                    start_row=start_row,
                    parallel_processing=args.parallel,
                    batch_size=args.batch_size,
                    max_workers=args.workers
                )
                
                if result["status"] == "success":
                    print(f"Successfully generated summaries for {result['rows_with_summaries']} out of {result['total_rows']} rows")
                    print(f"Output saved to: {result['output_file']}")
                else:
                    print(f"Error: {result['message']}")
            else:
                # Process a single row
                print(f"Generating summary for row {args.row}...")
                result = generate_row_summary(args.file, args.row, args.sheet)
                print_task_result(result)
            
        elif args.action == "summarize-workbook":
            print(f"Generating summary for workbook...")
            result = generate_workbook_summary(args.file)
            print_task_result(result)
            
        elif args.action == "classify":
            if not args.column:
                print("Error: --column is required for classify action")
                return
            
            print(f"Classifying data in column '{args.column}' using {args.mode} mode...")
            result = classify_data(
                args.file, 
                args.column, 
                args.mode, 
                sheet_name=args.sheet,
                class_definitions=class_definitions,
                parallel_processing=args.parallel,
                batch_size=args.batch_size,
                max_workers=args.workers
            )
            print(result)
            print_task_result(result)
            
            if args.output and result.get("result", {}).get("classified_data"):
                import pandas as pd
                df = pd.DataFrame(result["result"]["classified_data"])
                if args.output.endswith('.csv'):
                    df.to_csv(args.output, index=False)
                elif args.output.endswith(('.xlsx', '.xls')):
                    df.to_excel(args.output, index=False)
                print(f"Classified data saved to {args.output}")
            
        elif args.action == "visualize":
            if not args.viz_type:
                print("Error: --viz-type is required for visualize action")
                return
            
            if not args.x_column:
                print("Error: --x-column is required for visualize action")
                return
            
            print(f"Generating {args.viz_type} visualization...")
            result = generate_visualization(
                args.file, 
                args.viz_type, 
                args.x_column, 
                args.y_column, 
                sheet_name=args.sheet
            )
            print_task_result(result)
            
            if args.output and result.get("result", {}).get("image_data"):
                save_visualization(result["id"], args.output)
            
        elif args.action == "filter":
            if not args.query:
                print("Error: --query is required for filter action")
                return
            
            print(f"Filtering data in {args.file} with query: '{args.query}'...")
            result = filter_data(args.file, args.query, args.sheet)
            print_task_result(result)
            
            if args.output and result.get("result", {}).get("filtered_data"):
                import pandas as pd
                df = pd.DataFrame(result["result"]["filtered_data"])
                if args.output.endswith('.csv'):
                    df.to_csv(args.output, index=False)
                elif args.output.endswith(('.xlsx', '.xls')):
                    df.to_excel(args.output, index=False)
                print(f"Filtered data saved to {args.output}")
        
    else:
        parser.print_help()

if __name__ == "__main__":
    main() 