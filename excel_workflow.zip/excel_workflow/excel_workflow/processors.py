from typing import Any, Dict, List, Optional, Tuple
import pandas as pd
import re

from .state import ExcelWorkflowState, ExcelTask, TaskType, TaskStatus, ClassificationMode
from .data_utils import get_dataframe_from_task, natural_language_filter, generate_visualization
from .task_queue import update_task_status

def prepare_column_summary_prompt(df: pd.DataFrame, column_name: str, batch_size: int = 50) -> Tuple[Optional[str], Optional[str]]:
    """
    Prepare a prompt for generating a column summary.
    For text columns, concatenates data in batches for better context and analysis.
    """
    if column_name not in df.columns:
        return None, f"Column '{column_name}' not found in the DataFrame"
    
    column_data = df[column_name]
    data_type = str(column_data.dtype)
    non_null_count = column_data.count()
    null_count = column_data.isna().sum()
    unique_values = len(column_data.unique())
    
    # Prepare statistics and sample data based on data type
    if pd.api.types.is_numeric_dtype(column_data):
        # For numeric data, focus on statistical analysis
        stats = {
            "min": column_data.min(),
            "max": column_data.max(),
            "mean": column_data.mean(),
            "median": column_data.median(),
            "std": column_data.std(),
            "25th percentile": column_data.quantile(0.25),
            "75th percentile": column_data.quantile(0.75)
        }
        most_common = column_data.value_counts().head(5).to_dict() if unique_values < 100 else "Too many values"
        sample_data = f"Sample Values (first 10):\n{column_data.head(10).tolist()}"
        
        prompt = f"""
        Analyze the following numerical column from a dataset and provide a detailed summary:
        
        Column Name: {column_name}
        Data Type: {data_type}
        Total Rows: {len(df)}
        Non-null Values: {non_null_count}
        Null Values: {null_count}
        Unique Values: {unique_values}
        
        Statistics:
        {stats}
        
        Most Common Values:
        {most_common}
        
        {sample_data}
        
        Please provide:
        1. A concise summary of what this column represents and its distribution
        2. Key observations about the data (range, central tendency, dispersion)
        3. Any potential issues, outliers, or anomalies
        4. Insights about how this numeric data might be used in analysis
        
        Format your response as a well-structured report with clear sections.
        """
    
    elif pd.api.types.is_string_dtype(column_data) or pd.api.types.is_object_dtype(column_data):
        # For text data, process in batches to capture more context
        # Text statistics
        non_empty_data = column_data.dropna().astype(str)
        if len(non_empty_data) > 0:
            text_stats = {
                "min_length": non_empty_data.str.len().min(),
                "max_length": non_empty_data.str.len().max(),
                "avg_length": non_empty_data.str.len().mean(),
                "median_length": non_empty_data.str.len().median()
            }
        else:
            text_stats = {"note": "No non-empty text values to analyze"}
        
        most_common = column_data.value_counts().head(5).to_dict() if unique_values < 100 else "Too many unique values"
        
        # Process text data in batches for better context
        batch_texts = []
        total_batches = min(5, (len(df) + batch_size - 1) // batch_size)  # Cap at 5 batches maximum
        
        for i in range(total_batches):
            start_idx = i * batch_size
            end_idx = min(start_idx + batch_size, len(df))
            batch_data = column_data.iloc[start_idx:end_idx].dropna().astype(str)
            if not batch_data.empty:
                batch_sample = "\n".join([f"- {text[:100]}..." if len(text) > 100 else f"- {text}" for text in batch_data.head(10)])
                batch_texts.append(f"Batch {i+1} (rows {start_idx}-{end_idx-1}):\n{batch_sample}")
        
        batched_text_data = "\n\n".join(batch_texts)
        
        prompt = f"""
        Analyze the following text column from a dataset and provide a detailed summary:
        
        Column Name: {column_name}
        Data Type: {data_type}
        Total Rows: {len(df)}
        Non-null Values: {non_null_count}
        Null Values: {null_count}
        Unique Values: {unique_values}
        
        Text Statistics:
        {text_stats}
        
        Most Common Values (if few unique values):
        {most_common}
        
        Text Data Samples (by batches):
        {batched_text_data}
        
        Please provide:
        1. A comprehensive summary of what this text column represents
        2. Common themes, patterns, or categories you can identify
        3. The nature and structure of the text (sentences, phrases, codes, etc.)
        4. Any quality issues, inconsistencies, or anomalies
        5. How this text data might be used for analysis (sentiment, classification, etc.)
        
        Format your response as a well-structured report with clear sections.
        """
    
    else:
        # For other data types (dates, booleans, etc.)
        if pd.api.types.is_datetime64_any_dtype(column_data):
            stats = {
                "min_date": column_data.min(),
                "max_date": column_data.max(),
                "date_range": f"{(column_data.max() - column_data.min()).days} days" if not pd.isna(column_data.min()) and not pd.isna(column_data.max()) else "N/A"
            }
        else:
            stats = {}
        
        most_common = column_data.value_counts().head(5).to_dict() if unique_values < 100 else "Too many values"
        sample_data = f"Sample Values (first 10):\n{column_data.head(10).tolist()}"
        
        prompt = f"""
        Analyze the following column from a dataset and provide a detailed summary:
        
        Column Name: {column_name}
        Data Type: {data_type}
        Total Rows: {len(df)}
        Non-null Values: {non_null_count}
        Null Values: {null_count}
        Unique Values: {unique_values}
        
        Statistics:
        {stats}
        
        Most Common Values:
        {most_common}
        
        {sample_data}
        
        Please provide:
        1. A concise summary of what this column represents
        2. Key observations about the data distribution
        3. Any potential issues or anomalies
        4. Suggestions for how this column might be used in analysis
        
        Format your response as a well-structured report with clear sections.
        """
    
    return prompt, None

def summarize_batched_column(df: pd.DataFrame, column_name: str, llm_client: Any, batch_size: int = 50) -> Tuple[str, List[str]]:
    """
    Process a column in batches for more thorough analysis, especially for text columns.
    Returns the aggregated summary and batch summaries.
    """
    column_data = df[column_name]
    total_rows = len(df)
    
    # For small columns, process all at once
    if total_rows <= batch_size:
        prompt, error = prepare_column_summary_prompt(df, column_name)
        if error:
            return f"Error preparing summary: {error}", []
        
        try:
            full_response = llm_client.invoke(prompt)
            return full_response, [full_response]
        except Exception as e:
            return f"Error generating summary: {str(e)}", []
    
    # For larger columns, especially text data, process in batches
    if pd.api.types.is_string_dtype(column_data) or pd.api.types.is_object_dtype(column_data):
        # Process in batches
        batch_summaries = []
        num_batches = (total_rows + batch_size - 1) // batch_size
        
        # Limit to a reasonable number of batches to avoid overloading the LLM
        max_batches = 10
        processed_batches = min(num_batches, max_batches)
        
        for i in range(processed_batches):
            start_idx = i * batch_size
            end_idx = min(start_idx + batch_size, total_rows)
            
            print(f"Processing batch {i+1}/{processed_batches} for column '{column_name}' (rows {start_idx}-{end_idx-1})")
            
            batch_df = df.iloc[start_idx:end_idx].copy()
            batch_prompt = f"""
            Analyze this batch ({i+1}/{processed_batches}) of text data from column '{column_name}' (rows {start_idx}-{end_idx-1}):
            
            {batch_df[column_name].dropna().astype(str).tolist()[:50]}
            
            Provide a concise summary of the key patterns, themes, or characteristics in this batch.
            Keep your response focused and under 200 words.
            """
            
            try:
                batch_response = llm_client.invoke(batch_prompt)
                batch_summaries.append(batch_response)
            except Exception as e:
                batch_summaries.append(f"Error processing batch {i+1}: {str(e)}")
        
        # Create a final summary that aggregates all batch summaries
        if batch_summaries:
            aggregation_prompt = f"""
            You have analyzed the column '{column_name}' in {processed_batches} batches.
            Below are the summaries from each batch:
            
            {"".join([f"\nBatch {i+1}:\n{summary}\n" for i, summary in enumerate(batch_summaries)])}
            
            Based on these batch summaries, provide a comprehensive final summary of the entire column.
            Include:
            1. The overall nature of the text data
            2. Common themes or patterns across batches
            3. Noticeable variations between batches
            4. Key insights for analysis purposes
            5. Any potential data quality issues
            
            Format your response as a well-structured report.
            """
            
            try:
                final_summary = llm_client.invoke(aggregation_prompt)
                return final_summary, batch_summaries
            except Exception as e:
                return f"Error generating final summary: {str(e)}", batch_summaries
        
        return "Could not generate summaries for any batches.", batch_summaries
    
    # For numeric or other columns, just use the regular approach
    prompt, error = prepare_column_summary_prompt(df, column_name)
    if error:
        return f"Error preparing summary: {error}", []
    
    try:
        full_response = llm_client.invoke(prompt)
        return full_response, [full_response]
    except Exception as e:
        return f"Error generating summary: {str(e)}", []

def process_column_summary(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """Process a column summary task with improved handling for text columns."""
    df, error = get_dataframe_from_task(state)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to get DataFrame: {error}")
        return state
    
    # Get the column name from task parameters
    column_name = state["current_task"]["parameters"].get("column_name")
    if not column_name:
        state["error_message"] = "No column name specified in task parameters"
        state["processing_steps"].append("Missing column_name parameter")
        return state
    
    # Check if the column exists
    if column_name not in df.columns:
        state["error_message"] = f"Column '{column_name}' not found in the DataFrame"
        state["processing_steps"].append(f"Column not found: {column_name}")
        return state
    
    # Get the batch size parameter or use default
    batch_size = state["current_task"]["parameters"].get("batch_size", 50)
    
    # Determine if we should use batched processing
    column_data = df[column_name]
    use_batched = (
        (pd.api.types.is_string_dtype(column_data) or pd.api.types.is_object_dtype(column_data)) and 
        len(df) > batch_size
    )
    
    state["processing_steps"].append(f"Processing column '{column_name}' with {'batched' if use_batched else 'standard'} approach")
    
    try:
        if use_batched:
            # Use batched processing for text columns
            summary, batch_summaries = summarize_batched_column(df, column_name, llm_client, batch_size)
            state["llm_response"] = summary
            
            # Update the task with the result including batch details
            if state["current_task"]:
                state["current_task"] = update_task_status(
                    state["current_task"],
                    TaskStatus.COMPLETED,
                    result={
                        "summary": summary,
                        "batch_summaries": batch_summaries,
                        "processed_with": "batched_approach",
                        "num_batches": len(batch_summaries)
                    }
                )
        else:
            # Use standard approach for numeric columns or small text columns
            prompt, error = prepare_column_summary_prompt(df, column_name)
            if error:
                state["error_message"] = error
                state["processing_steps"].append(f"Failed to prepare prompt: {error}")
                return state
            
            state["llm_prompt"] = prompt
            state["processing_steps"].append(f"Prepared standard column summary prompt for '{column_name}'")
            
            response = llm_client.invoke(prompt)
            state["llm_response"] = response
            
            # Update the task with the result
            if state["current_task"]:
                state["current_task"] = update_task_status(
                    state["current_task"],
                    TaskStatus.COMPLETED,
                    result=response
                )
        
        state["processing_steps"].append(f"Generated column summary for '{column_name}'")
        return state
    
    except Exception as e:
        state["error_message"] = f"LLM invocation failed: {str(e)}"
        state["processing_steps"].append(f"LLM error: {str(e)}")
        return state

def prepare_row_summary_prompt(df: pd.DataFrame, row_index: int) -> Tuple[Optional[str], Optional[str]]:
    """
    Prepare a prompt for generating a detailed row summary.
    Provides comprehensive context with all column values for the row.
    """
    if row_index < 0 or row_index >= len(df):
        return None, f"Row index {row_index} is out of bounds (0-{len(df)-1})"
    
    # Get the row data
    row = df.iloc[row_index]
    
    # Get column types
    column_types = df.dtypes.to_dict()
    
    # Get dataset context
    total_rows = len(df)
    total_columns = len(df.columns)
    
    # Format row data with field types for better context
    formatted_row_data = []
    for col_name, value in row.items():
        col_type = str(column_types.get(col_name))
        
        # Format based on data type
        if pd.isna(value):
            formatted_value = "NULL/NA"
        elif pd.api.types.is_numeric_dtype(column_types.get(col_name)):
            formatted_value = str(value)
            # Add context for numeric columns
            if len(df) > 1:  # If there are other rows to compare with
                col_values = df[col_name].dropna()
                if len(col_values) > 0:
                    percentile = None
                    try:
                        min_val = col_values.min()
                        max_val = col_values.max()
                        mean_val = col_values.mean()
                        
                        # Calculate percentile if possible
                        if not pd.isna(value) and isinstance(value, (int, float)):
                            smaller_values = (col_values <= value).sum()
                            percentile = (smaller_values / len(col_values)) * 100
                        
                        range_info = f" (min: {min_val}, max: {max_val}, mean: {mean_val}"
                        if percentile is not None:
                            range_info += f", approx. {percentile:.1f}th percentile"
                        range_info += ")"
                        formatted_value += range_info
                    except:
                        pass  # Skip if there's an error calculating stats
        elif isinstance(value, str) and len(value) > 200:
            # Truncate long text
            formatted_value = f"{value[:200]}... [truncated, full length: {len(value)} chars]"
        else:
            formatted_value = str(value)
        
        formatted_row_data.append(f"{col_name} ({col_type}): {formatted_value}")
    
    # Get adjacent rows for context, if available
    adjacent_context = ""
    if total_rows > 1:
        prev_row_idx = max(0, row_index - 1)
        next_row_idx = min(total_rows - 1, row_index + 1)
        
        if prev_row_idx != row_index:
            prev_row = df.iloc[prev_row_idx]
            prev_row_summary = ", ".join([f"{col}: {val}" for col, val in prev_row.items() if not pd.isna(val)][:5])
            if len(prev_row) > 5:
                prev_row_summary += "... (more columns)"
            adjacent_context += f"\nPrevious Row ({prev_row_idx}): {prev_row_summary}\n"
        
        if next_row_idx != row_index:
            next_row = df.iloc[next_row_idx]
            next_row_summary = ", ".join([f"{col}: {val}" for col, val in next_row.items() if not pd.isna(val)][:5])
            if len(next_row) > 5:
                next_row_summary += "... (more columns)"
            adjacent_context += f"\nNext Row ({next_row_idx}): {next_row_summary}\n"
    
    # Prepare the prompt
    prompt = f"""
    Analyze the following row from a dataset and provide a detailed summary:
    
    Dataset: {total_rows} rows x {total_columns} columns
    Row Index: {row_index} (Row {row_index + 1} in 1-indexed systems)
    
    --- ROW DATA (COMPLETE) ---
    {chr(10).join(formatted_row_data)}
    
    --- ADJACENT CONTEXT ---
    {adjacent_context if adjacent_context else "No adjacent rows available."}
    
    Please provide:
    1. A comprehensive summary of what this row represents as a whole
    2. The most significant information or values in this row
    3. Unusual or noteworthy values (outliers, missing data, etc.)
    4. How this row relates to the dataset context 
    5. Any patterns, relationships, or insights from the combination of values
    
    Format your response as a well-structured, detailed analysis.
    """
    
    return prompt, None

def prepare_workbook_summary_prompt(dataframes: Dict[str, pd.DataFrame]) -> Tuple[Optional[str], Optional[str]]:
    """Prepare a prompt for generating a summary of all sheets in a workbook."""
    if not dataframes:
        return None, "No dataframes provided"
    
    sheets_summary = []
    for sheet_key, df in dataframes.items():
        sheet_name = sheet_key.split(":")[-1]
        sheet_summary = {
            "name": sheet_name,
            "rows": len(df),
            "columns": len(df.columns),
            "column_names": df.columns.tolist(),
            "column_types": {col: str(dtype) for col, dtype in df.dtypes.items()},
            "sample_data": df.head(2).to_dict(orient="records")
        }
        sheets_summary.append(sheet_summary)
    
    # Prepare the prompt
    prompt = f"""
    Analyze the following Excel workbook containing {len(dataframes)} sheets and provide a comprehensive summary:
    
    Workbook Summary:
    {sheets_summary}
    
    Please provide:
    1. An overview of the entire workbook and what it appears to contain
    2. A summary of each sheet's purpose and content
    3. Relationships between different sheets (if any)
    4. Key observations about the data structure and organization
    5. Suggestions for how this data might be analyzed
    
    Format your response as a well-structured report with clear sections for each sheet.
    """
    
    return prompt, None

def process_row_summary(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """Process a row summary task with comprehensive row data."""
    df, error = get_dataframe_from_task(state)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to get DataFrame: {error}")
        return state
    
    # Get the row index from task parameters
    row_index = state["current_task"]["parameters"].get("row_index")
    if row_index is None:
        state["error_message"] = "No row index specified in task parameters"
        state["processing_steps"].append("Missing row_index parameter")
        return state
    
    # Handle string row index (convert to int if possible)
    if isinstance(row_index, str):
        try:
            row_index = int(row_index)
        except ValueError:
            state["error_message"] = f"Invalid row index: {row_index}. Must be an integer."
            state["processing_steps"].append(f"Invalid row index: {row_index}")
            return state
    
    # Check for valid range
    if row_index < 0 or row_index >= len(df):
        state["error_message"] = f"Row index {row_index} is out of bounds (0-{len(df)-1})"
        state["processing_steps"].append(f"Row index out of bounds: {row_index}")
        return state
    
    # Prepare the prompt
    prompt, error = prepare_row_summary_prompt(df, row_index)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to prepare prompt: {error}")
        return state
    
    state["llm_prompt"] = prompt
    state["processing_steps"].append(f"Prepared comprehensive row summary prompt for row {row_index}")
    
    # Invoke the LLM
    try:
        response = llm_client.invoke(prompt)
        state["llm_response"] = response
        state["processing_steps"].append(f"Generated detailed row summary for row {row_index}")
        
        # Get the actual row data for reference
        row_data = df.iloc[row_index].to_dict()
        
        # Update the task with the result
        if state["current_task"]:
            state["current_task"] = update_task_status(
                state["current_task"],
                TaskStatus.COMPLETED,
                result={
                    "summary": response,
                    "row_index": row_index,
                    "row_data": row_data
                }
            )
        
        return state
    except Exception as e:
        state["error_message"] = f"LLM invocation failed: {str(e)}"
        state["processing_steps"].append(f"LLM error: {str(e)}")
        return state

def process_workbook_summary(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """Process a workbook summary task."""
    # Get all dataframes for the file
    file_path = state["current_task"]["file_path"]
    relevant_dfs = {k: v for k, v in state["dataframes"].items() if k.startswith(file_path)}
    
    if not relevant_dfs:
        # Try to load the dataframes
        state["processing_steps"].append(f"No loaded dataframes found for {file_path}, attempting to load")
        from .data_utils import load_dataframe
        state = load_dataframe(state, file_path)
        
        if state["error_message"]:
            return state
        
        # Get the loaded dataframes again
        relevant_dfs = {k: v for k, v in state["dataframes"].items() if k.startswith(file_path)}
        
        if not relevant_dfs:
            state["error_message"] = f"No dataframes could be loaded from {file_path}"
            state["processing_steps"].append("Failed to load any dataframes")
            return state
    
    # Prepare the prompt
    prompt, error = prepare_workbook_summary_prompt(relevant_dfs)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to prepare prompt: {error}")
        return state
    
    state["llm_prompt"] = prompt
    state["processing_steps"].append(f"Prepared workbook summary prompt for {file_path}")
    
    # Invoke the LLM
    try:
        response = llm_client.invoke(prompt)
        state["llm_response"] = response
        state["processing_steps"].append("Generated workbook summary with LLM")
        
        # Update the task with the result
        if state["current_task"]:
            state["current_task"] = update_task_status(
                state["current_task"],
                TaskStatus.COMPLETED,
                result=response
            )
        
        return state
    except Exception as e:
        state["error_message"] = f"LLM invocation failed: {str(e)}"
        state["processing_steps"].append(f"LLM error: {str(e)}")
        return state

def prepare_classification_prompt(
    row_data: Dict[str, Any],
    target_column: str,
    classification_mode: str,
    class_definitions: Optional[Dict[str, str]] = None,
    examples: Optional[List[Dict[str, Any]]] = None,
    label_column: Optional[str] = None
) -> str:
    """
    Prepare a classification prompt with comprehensive row context.
    This provides better context than just the target column text.
    """
    # Get the text to classify from the target column
    text_to_classify = str(row_data.get(target_column, ""))
    
    # Format the row data for context (excluding the target column itself)
    row_context = []
    for col_name, value in row_data.items():
        if col_name != target_column and not pd.isna(value):
            if isinstance(value, str) and len(value) > 100:
                # Truncate long text values
                formatted_value = f"{value[:100]}... [truncated]"
            else:
                formatted_value = str(value)
            row_context.append(f"{col_name}: {formatted_value}")
    
    row_context_str = "\n".join(row_context)
    
    # Create mode-specific prompts
    if classification_mode == "unsupervised_anomaly":
        prompt = f"""
        Analyze and classify the following text data from a dataset:
        
        --- TEXT TO CLASSIFY ---
        {text_to_classify}
        
        --- ADDITIONAL ROW CONTEXT ---
        {row_context_str}
        
        Based on this text and context, determine the most appropriate category for this data point.
        Consider if this entry is anomalous compared to what you would typically expect.
        
        Respond with:
        Category: <Your Category>
        Reasoning: <Your detailed reasoning>
        
        If the entry appears anomalous or unusual, use 'Category: Anomaly'.
        If the text is empty or clearly invalid, use 'Category: Empty/Invalid'.
        Otherwise, suggest an appropriate general category.
        """
    
    elif classification_mode == "few_shot_examples":
        if not examples or not label_column:
            return "Error: Examples or label column missing for few-shot classification"
        
        # Format examples for few-shot learning
        formatted_examples = []
        for ex in examples:
            ex_text = str(ex.get(target_column, ""))
            ex_label = str(ex.get(label_column, "UnknownLabel"))
            
            # Format example row context
            ex_context = []
            for col_name, value in ex.items():
                if col_name != target_column and col_name != label_column and not pd.isna(value):
                    ex_context.append(f"{col_name}: {value}")
            
            ex_context_str = ", ".join(ex_context)
            formatted_examples.append(f"Text: \"{ex_text}\"\nContext: {ex_context_str}\nCategory: {ex_label}")
        
        examples_str = "\n\n".join(formatted_examples)
        categories = set(ex.get(label_column, 'UnknownLabel') for ex in examples)
        
        prompt = f"""
        You are an expert text classifier. Use the following examples to learn classification patterns:
        
        === EXAMPLES ===
        {examples_str}
        
        === CATEGORIES SEEN IN EXAMPLES ===
        {', '.join(sorted(list(categories)))}
        
        Now, classify this new data:
        
        --- TEXT TO CLASSIFY ---
        {text_to_classify}
        
        --- ADDITIONAL ROW CONTEXT ---
        {row_context_str}
        
        Based on the examples and the patterns they demonstrate, classify this new text and context.
        Respond with only the category name. If unsure or if it doesn't match any example pattern, respond with 'Uncertain'.
        """
    
    elif classification_mode == "definition_based":
        if not class_definitions:
            return "Error: Class definitions missing for definition-based classification"
        
        # Format the class definitions
        formatted_definitions = []
        for cat, desc in class_definitions.items():
            formatted_definitions.append(f"{cat}: {desc}")
        
        definitions_str = "\n".join(formatted_definitions)
        category_names = list(class_definitions.keys())
        
        prompt = f"""
        You are an expert classifier. Use ONLY the following category definitions to classify the text:
        
        === CATEGORY DEFINITIONS ===
        {definitions_str}
        
        Now, classify this data:
        
        --- TEXT TO CLASSIFY ---
        {text_to_classify}
        
        --- ADDITIONAL ROW CONTEXT ---
        {row_context_str}
        
        Based on these definitions, classify the text and context into the most appropriate category.
        Consider both the primary text and the additional context in your classification.
        
        Respond with the most fitting category name from this list: {', '.join(category_names)}.
        If none fit well, respond with 'Uncategorized'.
        """
    
    else:
        prompt = f"Error: Unknown classification mode '{classification_mode}'"
    
    return prompt

def process_classification(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """
    Process a classification task using comprehensive row context.
    Builds on the existing excel_classification.py functionality with enhancements.
    """
    from excel_classification import (
        determine_classification_strategy,
        validate_row_data,
        quality_check_node
    )
    
    df, error = get_dataframe_from_task(state)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to get DataFrame: {error}")
        return state
    
    # Get parameters from task
    task_params = state["current_task"]["parameters"]
    target_column = task_params.get("target_column")
    label_column = task_params.get("label_column")
    class_definitions = task_params.get("class_definitions")
    examples = task_params.get("examples")
    
    if not target_column:
        state["error_message"] = "No target column specified in task parameters"
        state["processing_steps"].append("Missing target_column parameter")
        return state
    
    # Check if target column exists
    if target_column not in df.columns:
        state["error_message"] = f"Target column '{target_column}' not found in DataFrame"
        state["processing_steps"].append(f"Invalid target column: {target_column}")
        return state
    
    # Prepare for parallel processing if enabled
    parallel_processing = task_params.get("parallel_processing", False)
    batch_size = task_params.get("batch_size", 10)  # Process this many rows at once
    max_workers = task_params.get("max_workers", 5)  # Maximum parallel workers
    
    # Track results
    results = []
    total_rows = len(df)
    
    # Log the classification approach
    state["processing_steps"].append(
        f"Classifying {total_rows} rows using target column '{target_column}' with "
        f"{'parallel' if parallel_processing else 'sequential'} processing"
    )
    
    if parallel_processing:
        try:
            import concurrent.futures
            state["processing_steps"].append(f"Using parallel processing with max {max_workers} workers")
            
            # Process rows in batches to avoid memory issues
            for batch_start in range(0, total_rows, batch_size):
                batch_end = min(batch_start + batch_size, total_rows)
                batch_indices = list(range(batch_start, batch_end))
                
                state["processing_steps"].append(f"Processing batch of rows {batch_start} to {batch_end-1}")
                
                # Function for parallel execution
                def process_row(row_idx):
                    row_dict = df.iloc[row_idx].to_dict()
                    
                    # Create initial classification state
                    from excel_classification import ExcelRowClassificationState
                    classification_state: ExcelRowClassificationState = {
                        "input_row": row_dict,
                        "target_column_for_classification": target_column,
                        "label_column_name": label_column,
                        "provided_examples": examples,
                        "class_definitions": class_definitions,
                        "all_rows_data": None,  # Not using all rows to save memory
                        "classification_mode": None,
                        "llm_prompt": None,
                        "classification_category": None,
                        "confidence_score": None,
                        "llm_reasoning": None,
                        "error_message": None,
                        "processing_steps": []
                    }
                    
                    # Determine classification strategy
                    classification_state = determine_classification_strategy(classification_state)
                    if classification_state.get("error_message"):
                        return row_dict, classification_state
                        
                    # Validate row data
                    classification_state = validate_row_data(classification_state)
                    if classification_state.get("error_message"):
                        return row_dict, classification_state
                    
                    # Use our enhanced prompt preparation instead of the original
                    mode = classification_state.get("classification_mode")
                    prompt = prepare_classification_prompt(
                        row_dict,
                        target_column,
                        mode,
                        class_definitions,
                        examples,
                        label_column
                    )
                    
                    if prompt.startswith("Error:"):
                        classification_state["error_message"] = prompt
                        return row_dict, classification_state
                        
                    classification_state["llm_prompt"] = prompt
                    
                    # Invoke LLM directly
                    try:
                        raw_llm_response = llm_client.invoke(prompt)
                        
                        # Parse response similar to excel_classification.py
                        parsed_category = "Error: Parsing Failed"
                        parsed_reasoning = None
                        parsed_confidence = 0.75
                        
                        if isinstance(raw_llm_response, str):
                            raw_llm_response = raw_llm_response.strip()
                            if mode == "unsupervised_anomaly":
                                category_match = re.search(r"Category:\s*(.*)", raw_llm_response, re.IGNORECASE)
                                reasoning_match = re.search(r"Reasoning:\s*(.*)", raw_llm_response, re.IGNORECASE)
                                if category_match:
                                    parsed_category = category_match.group(1).strip()
                                if reasoning_match:
                                    parsed_reasoning = reasoning_match.group(1).strip()
                                if parsed_category == "Anomaly": 
                                    parsed_confidence = 0.9
                                elif parsed_category == "Empty/Invalid": 
                                    parsed_confidence = 0.5
                                else: 
                                    parsed_confidence = 0.65
                            elif mode in ["few_shot_examples", "definition_based"]:
                                if raw_llm_response.lower().startswith("category:"):
                                    parsed_category = raw_llm_response.split(":", 1)[1].strip()
                                else:
                                    parsed_category = raw_llm_response
                                
                                if parsed_category == "Uncertain" or parsed_category == "Uncategorized":
                                    parsed_confidence = 0.4
                                elif class_definitions and parsed_category in class_definitions:
                                    parsed_confidence = 0.85
                                elif examples and any(ex.get(label_column) == parsed_category for ex in examples):
                                    parsed_confidence = 0.88
                                else:
                                    parsed_confidence = 0.60
                                    
                            classification_state["classification_category"] = parsed_category
                            classification_state["llm_reasoning"] = parsed_reasoning if parsed_reasoning else "N/A"
                            classification_state["confidence_score"] = parsed_confidence
                        else:
                            classification_state["error_message"] = "LLM response was not a string. Cannot parse."
                            classification_state["classification_category"] = "Error: LLM Output Type"
                            classification_state["llm_reasoning"] = str(raw_llm_response)
                            
                    except Exception as e:
                        classification_state["error_message"] = f"LLM call/parsing failed: {str(e)}"
                        classification_state["classification_category"] = "Error: LLM Exception"
                        classification_state["llm_reasoning"] = None
                        classification_state["confidence_score"] = 0.0
                    
                    # Apply quality check
                    classification_state = quality_check_node(classification_state)
                    
                    return row_dict, classification_state
                
                # Process batch in parallel
                with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
                    future_to_idx = {executor.submit(process_row, idx): idx for idx in batch_indices}
                    for future in concurrent.futures.as_completed(future_to_idx):
                        idx = future_to_idx[future]
                        try:
                            row_dict, classification_state = future.result()
                            
                            # Store results
                            result_row = row_dict.copy()
                            result_row["classification_mode_used"] = classification_state.get("classification_mode")
                            result_row["llm_classification"] = classification_state.get("classification_category")
                            result_row["llm_confidence"] = classification_state.get("confidence_score")
                            result_row["llm_reasoning_output"] = classification_state.get("llm_reasoning")
                            result_row["processing_error"] = classification_state.get("error_message")
                            results.append(result_row)
                            
                        except Exception as e:
                            # Handle any errors in parallel processing
                            row_dict = df.iloc[idx].to_dict()
                            result_row = row_dict.copy()
                            result_row["classification_mode_used"] = "error"
                            result_row["llm_classification"] = "Error: Parallel Processing"
                            result_row["llm_confidence"] = 0.0
                            result_row["llm_reasoning_output"] = None
                            result_row["processing_error"] = f"Parallel processing error: {str(e)}"
                            results.append(result_row)
                
                state["processing_steps"].append(f"Completed batch {batch_start}-{batch_end-1}")
            
        except ImportError:
            # Fall back to sequential processing if concurrent.futures isn't available
            state["processing_steps"].append("Parallel processing not available, falling back to sequential")
            parallel_processing = False
    
    # Sequential processing (default or fallback)
    if not parallel_processing:
        for index, row in df.iterrows():
            row_dict = row.to_dict()
            
            # Create the initial state for the classification system
            from excel_classification import ExcelRowClassificationState
            
            classification_state: ExcelRowClassificationState = {
                "input_row": row_dict,
                "target_column_for_classification": target_column,
                "label_column_name": label_column,
                "provided_examples": examples,
                "class_definitions": class_definitions,
                "all_rows_data": df.to_dict(orient="records") if len(df) < 1000 else None,  # Only for small datasets
                "classification_mode": None,
                "llm_prompt": None,
                "classification_category": None,
                "confidence_score": None,
                "llm_reasoning": None,
                "error_message": None,
                "processing_steps": []
            }
            
            # Apply the classification steps
            classification_state = determine_classification_strategy(classification_state)
            if not classification_state.get("error_message"):
                classification_state = validate_row_data(classification_state)
            
            if not classification_state.get("error_message"):
                # Use our enhanced prompt instead of the original
                mode = classification_state.get("classification_mode")
                prompt = prepare_classification_prompt(
                    row_dict,
                    target_column,
                    mode,
                    class_definitions,
                    examples,
                    label_column
                )
                
                if prompt.startswith("Error:"):
                    classification_state["error_message"] = prompt
                else:
                    classification_state["llm_prompt"] = prompt
                    
                    # Invoke LLM
                    try:
                        raw_llm_response = llm_client.invoke(prompt)
                        
                        # Parse the LLM response (similar to the original)
                        parsed_category = "Error: Parsing Failed"
                        parsed_reasoning = None
                        parsed_confidence = 0.75
                        
                        if isinstance(raw_llm_response, str):
                            raw_llm_response = raw_llm_response.strip()
                            if mode == "unsupervised_anomaly":
                                category_match = re.search(r"Category:\s*(.*)", raw_llm_response, re.IGNORECASE)
                                reasoning_match = re.search(r"Reasoning:\s*(.*)", raw_llm_response, re.IGNORECASE)
                                if category_match:
                                    parsed_category = category_match.group(1).strip()
                                if reasoning_match:
                                    parsed_reasoning = reasoning_match.group(1).strip()
                                if parsed_category == "Anomaly": 
                                    parsed_confidence = 0.9
                                elif parsed_category == "Empty/Invalid": 
                                    parsed_confidence = 0.5
                                else: 
                                    parsed_confidence = 0.65
                                    
                            elif mode in ["few_shot_examples", "definition_based"]:
                                if raw_llm_response.lower().startswith("category:"):
                                    parsed_category = raw_llm_response.split(":", 1)[1].strip()
                                else:
                                    parsed_category = raw_llm_response
                                
                                if parsed_category == "Uncertain" or parsed_category == "Uncategorized":
                                    parsed_confidence = 0.4
                                elif class_definitions and parsed_category in class_definitions:
                                    parsed_confidence = 0.85
                                elif examples and any(ex.get(label_column) == parsed_category for ex in examples):
                                    parsed_confidence = 0.88
                                else:
                                    parsed_confidence = 0.60
                                    
                            classification_state["classification_category"] = parsed_category
                            classification_state["llm_reasoning"] = parsed_reasoning if parsed_reasoning else "N/A"
                            classification_state["confidence_score"] = parsed_confidence
                        else:
                            classification_state["error_message"] = "LLM response was not a string. Cannot parse."
                            classification_state["classification_category"] = "Error: LLM Output Type"
                            classification_state["llm_reasoning"] = str(raw_llm_response)
                            
                    except Exception as e:
                        classification_state["error_message"] = f"LLM call/parsing failed: {str(e)}"
                        classification_state["classification_category"] = "Error: LLM Exception"
                        classification_state["llm_reasoning"] = None
                        classification_state["confidence_score"] = 0.0
            
            # Apply quality check
            if not classification_state.get("error_message"):
                classification_state = quality_check_node(classification_state)
            
            # Store the results
            result_row = row_dict.copy()
            result_row["classification_mode_used"] = classification_state.get("classification_mode")
            result_row["llm_classification"] = classification_state.get("classification_category")
            result_row["llm_confidence"] = classification_state.get("confidence_score")
            result_row["llm_reasoning_output"] = classification_state.get("llm_reasoning")
            result_row["processing_error"] = classification_state.get("error_message")
            results.append(result_row)
            
            # Update the processing steps with information about this row
            if index % 10 == 0 or index == len(df) - 1:  # Log every 10 rows to avoid too much output
                state["processing_steps"].append(
                    f"Classified row {index}/{len(df)-1} as '{classification_state.get('classification_category')}' "
                    f"using {classification_state.get('classification_mode')} mode"
                )
    
    # Create a new DataFrame with the results
    results_df = pd.DataFrame(results)
    
    # Update the task with the results
    if state["current_task"]:
        state["current_task"] = update_task_status(
            state["current_task"],
            TaskStatus.COMPLETED,
            result={
                "classified_data": results_df.to_dict(orient="records"),
                "summary": {
                    "total_rows": len(results_df),
                    "classification_counts": results_df["llm_classification"].value_counts().to_dict()
                },
                "processed_with": "parallel" if parallel_processing else "sequential"
            }
        )
    
    state["processing_steps"].append(f"Completed classification of {len(results_df)} rows")
    return state

def process_visualization(state: ExcelWorkflowState) -> ExcelWorkflowState:
    """Process a data visualization task."""
    df, error = get_dataframe_from_task(state)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to get DataFrame: {error}")
        return state
    
    # Get parameters from task
    task_params = state["current_task"]["parameters"]
    viz_type = task_params.get("visualization_type")
    x_column = task_params.get("x_column")
    y_column = task_params.get("y_column")
    color_by = task_params.get("color_by")
    additional_params = task_params.get("additional_params", {})
    
    if not viz_type:
        state["error_message"] = "No visualization type specified in task parameters"
        state["processing_steps"].append("Missing visualization_type parameter")
        return state
    
    if not x_column:
        state["error_message"] = "No x_column specified in task parameters"
        state["processing_steps"].append("Missing x_column parameter")
        return state
    
    # Generate the visualization
    from .data_utils import generate_visualization
    from .state import VisualizationType
    
    viz_type_enum = getattr(VisualizationType, viz_type.upper()) if isinstance(viz_type, str) else viz_type
    
    image_data, error = generate_visualization(
        df, viz_type_enum, x_column, y_column, color_by, **additional_params
    )
    
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to generate visualization: {error}")
        return state
    
    # Update the task with the result
    if state["current_task"]:
        state["current_task"] = update_task_status(
            state["current_task"],
            TaskStatus.COMPLETED,
            result={
                "image_data": image_data,
                "type": viz_type,
                "parameters": {
                    "x_column": x_column,
                    "y_column": y_column,
                    "color_by": color_by,
                    **additional_params
                }
            }
        )
    
    state["processing_steps"].append(f"Generated {viz_type} visualization")
    return state

def process_filter_query(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """Process a natural language filter/query task."""
    df, error = get_dataframe_from_task(state)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Failed to get DataFrame: {error}")
        return state
    
    # Get the query from task parameters
    query = state["current_task"]["parameters"].get("query")
    if not query:
        state["error_message"] = "No query specified in task parameters"
        state["processing_steps"].append("Missing query parameter")
        return state
    
    # Process the natural language query
    filtered_df, error = natural_language_filter(df, query, llm_client)
    if error:
        state["error_message"] = error
        state["processing_steps"].append(f"Filter error: {error}")
        return state
    
    # Update the task with the result
    if state["current_task"]:
        state["current_task"] = update_task_status(
            state["current_task"],
            TaskStatus.COMPLETED,
            result={
                "filtered_data": filtered_df.to_dict(orient="records"),
                "original_query": query,
                "summary": {
                    "original_rows": len(df),
                    "filtered_rows": len(filtered_df),
                    "reduction_percentage": round((1 - len(filtered_df) / len(df)) * 100, 2)
                }
            }
        )
    
    state["processing_steps"].append(f"Filtered data: {len(filtered_df)} rows from {len(df)} original rows")
    return state 