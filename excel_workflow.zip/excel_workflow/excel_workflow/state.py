from typing import TypedDict, Dict, Any, List, Optional, Union, Literal
from enum import Enum
import pandas as pd

class TaskType(str, Enum):
    """Types of tasks that can be performed on Excel data."""
    COLUMN_SUMMARY = "column_summary"
    ROW_SUMMARY = "row_summary"
    CLASSIFICATION_CONTEXT = "classification_context"
    CLASSIFICATION_UNSUPERVISED = "classification_unsupervised"
    CLASSIFICATION_FEW_SHOT = "classification_few_shot"
    WORKBOOK_SUMMARY = "workbook_summary"
    DATA_VISUALIZATION = "data_visualization"
    FILTER_QUERY = "filter_query"

class TaskStatus(str, Enum):
    """Possible statuses for a task in the queue."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELED = "canceled"

class TaskPriority(str, Enum):
    """Priority levels for tasks."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    URGENT = "urgent"

class VisualizationType(str, Enum):
    """Types of visualizations that can be generated."""
    BAR_CHART = "bar_chart"
    HISTOGRAM = "histogram"
    LINE_CHART = "line_chart"
    SCATTER_PLOT = "scatter_plot"
    PIE_CHART = "pie_chart"
    HEATMAP = "heatmap"
    BOX_PLOT = "box_plot"

class ClassificationMode(str, Enum):
    """Possible classification modes."""
    UNSUPERVISED_ANOMALY = "unsupervised_anomaly"
    FEW_SHOT_EXAMPLES = "few_shot_examples"
    DEFINITION_BASED = "definition_based"

class ExcelTask(TypedDict):
    """Represents a task to be performed on Excel data."""
    id: str
    type: TaskType
    status: TaskStatus
    priority: TaskPriority
    created_at: str
    updated_at: str
    file_path: str
    sheet_name: Optional[str]
    parameters: Dict[str, Any]
    result: Optional[Any]
    error: Optional[str]
    user_id: Optional[str]

class ExcelWorkflowState(TypedDict):
    """Main state object for the Excel workflow system."""
    # Task management
    current_task: Optional[ExcelTask]
    task_queue: List[ExcelTask]
    completed_tasks: List[ExcelTask]
    
    # Data
    dataframes: Dict[str, pd.DataFrame]  # Maps file_path:sheet_name to loaded dataframes
    loaded_sheets: List[str]  # List of "file_path:sheet_name" that are currently loaded
    
    # Classification-specific state (when needed)
    classification_mode: Optional[ClassificationMode]
    target_column: Optional[str]
    label_column: Optional[str]
    class_definitions: Optional[Dict[str, str]]
    examples: Optional[List[Dict[str, Any]]]
    
    # Visualization-specific state (when needed)
    visualization_type: Optional[VisualizationType]
    x_column: Optional[str]
    y_column: Optional[str]
    color_by: Optional[str]
    
    # Processing state
    llm_prompt: Optional[str]
    llm_response: Optional[str]
    processing_steps: List[str]
    error_message: Optional[str]
    llm_client: Optional[Any] 