import uuid
import datetime
from typing import List, Dict, Any, Optional
import heapq
from .state import ExcelTask, TaskStatus, TaskPriority, TaskType, ExcelWorkflowState

class PriorityQueue:
    """A priority queue for Excel tasks, ordered by priority and creation time."""
    
    def __init__(self):
        self.tasks = []  # heap queue
        self.task_lookup = {}  # for O(1) access to tasks by ID
        self.priority_map = {
            TaskPriority.URGENT: 0,
            TaskPriority.HIGH: 1,
            TaskPriority.MEDIUM: 2,
            TaskPriority.LOW: 3
        }
    
    def add_task(self, task: ExcelTask) -> None:
        """Add a task to the priority queue."""
        priority_value = self.priority_map.get(task["priority"], 999)
        created_at = task["created_at"]
        # Use a tuple of (priority_value, created_at, task_id) as the heap key
        entry = (priority_value, created_at, task["id"], task)
        heapq.heappush(self.tasks, entry)
        self.task_lookup[task["id"]] = entry
    
    def get_next_task(self) -> Optional[ExcelTask]:
        """Get the highest priority task from the queue."""
        if not self.tasks:
            return None
        
        while self.tasks:
            _, _, task_id, task = heapq.heappop(self.tasks)
            if task_id in self.task_lookup:  # Make sure it wasn't removed
                del self.task_lookup[task_id]
                return task
        return None
    
    def remove_task(self, task_id: str) -> bool:
        """Remove a task from the queue by ID."""
        if task_id not in self.task_lookup:
            return False
        
        # Mark for removal by setting the ID to None
        # We don't need to modify the heap as we'll skip it when popped
        self.task_lookup.pop(task_id)
        return True
    
    def get_all_tasks(self) -> List[ExcelTask]:
        """Get all tasks in the queue (for inspection only)."""
        return [task for _, _, _, task in self.tasks if task["id"] in self.task_lookup]
    
    def is_empty(self) -> bool:
        """Check if the queue is empty."""
        return len(self.task_lookup) == 0

def create_task(
    task_type: TaskType,
    file_path: str,
    parameters: Dict[str, Any],
    priority: TaskPriority = TaskPriority.MEDIUM,
    sheet_name: Optional[str] = None,
    user_id: Optional[str] = None
) -> ExcelTask:
    """Create a new Excel task with a unique ID and timestamps."""
    now = datetime.datetime.now().isoformat()
    return {
        "id": str(uuid.uuid4()),
        "type": task_type,
        "status": TaskStatus.PENDING,
        "priority": priority,
        "created_at": now,
        "updated_at": now,
        "file_path": file_path,
        "sheet_name": sheet_name,
        "parameters": parameters,
        "result": None,
        "error": None,
        "user_id": user_id
    }

def update_task_status(task: ExcelTask, status: TaskStatus, result: Any = None, error: str = None) -> ExcelTask:
    """Update a task's status, result, and error fields."""
    updated_task = task.copy()
    updated_task["status"] = status
    updated_task["updated_at"] = datetime.datetime.now().isoformat()
    
    if result is not None:
        updated_task["result"] = result
    
    if error is not None:
        updated_task["error"] = error
    
    return updated_task

def get_next_task(state: ExcelWorkflowState) -> ExcelWorkflowState:
    """Get the next task from the queue and update the state."""
    if not state["task_queue"]:
        state["current_task"] = None
        state["error_message"] = "Task queue is empty"
        return state
    
    # Get the highest priority task
    priority_queue = PriorityQueue()
    for task in state["task_queue"]:
        priority_queue.add_task(task)
    
    next_task = priority_queue.get_next_task()
    if not next_task:
        state["current_task"] = None
        state["error_message"] = "Failed to get next task from queue"
        return state
    
    # Remove task from queue
    state["task_queue"] = [t for t in state["task_queue"] if t["id"] != next_task["id"]]
    
    # Update the task status
    next_task = update_task_status(next_task, TaskStatus.IN_PROGRESS)
    state["current_task"] = next_task
    
    # Reset any task-specific state
    state["llm_prompt"] = None
    state["llm_response"] = None
    state["error_message"] = None
    state["processing_steps"] = []
    
    return state 