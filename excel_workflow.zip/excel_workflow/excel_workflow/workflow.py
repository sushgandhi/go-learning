from typing import Optional, List, Dict, Any
from langgraph.graph import StateGraph, END

from .state import ExcelWorkflowState, ExcelTask, TaskType, TaskStatus
from .task_queue import get_next_task, update_task_status
from .processors import (
    process_column_summary,
    process_row_summary,
    process_workbook_summary,
    process_classification,
    process_visualization,
    process_filter_query
)

def initialize_workflow_state() -> ExcelWorkflowState:
    """Initialize the workflow state with empty values."""
    return {
        "current_task": None,
        "task_queue": [],
        "completed_tasks": [],
        "dataframes": {},
        "loaded_sheets": [],
        "classification_mode": None,
        "target_column": None,
        "label_column": None,
        "class_definitions": None,
        "examples": None,
        "visualization_type": None,
        "x_column": None,
        "y_column": None,
        "color_by": None,
        "llm_prompt": None,
        "llm_response": None,
        "processing_steps": [],
        "error_message": None,
        "llm_client": None
    }

def check_queue_node(state: ExcelWorkflowState) -> ExcelWorkflowState:
    """Check if there are tasks in the queue and get the next one."""
    print("---CHECKING TASK QUEUE---")
    
    # Skip if there's already a current task
    if state["current_task"] and state["current_task"]["status"] == TaskStatus.IN_PROGRESS:
        state["processing_steps"].append("check_queue_node: Already processing a task")
        return state
    
    # Try to get the next task
    state = get_next_task(state)
    
    if state["current_task"]:
        state["processing_steps"].append(f"check_queue_node: Got task {state['current_task']['id']} of type {state['current_task']['type']}")
    else:
        state["processing_steps"].append("check_queue_node: No tasks in queue")
    
    return state

def process_task_node(state: ExcelWorkflowState, llm_client: Any) -> ExcelWorkflowState:
    """Process the current task based on its type."""
    print("---PROCESSING TASK---")
    
    if not state["current_task"]:
        state["processing_steps"].append("process_task_node: No current task to process")
        return state
    
    if state.get("error_message"):
        state["processing_steps"].append(f"process_task_node: Skipping due to error: {state['error_message']}")
        return state
    
    task_type = state["current_task"]["type"]
    state["processing_steps"].append(f"process_task_node: Processing task of type {task_type}")
    
    # Route to the appropriate processor based on task type
    try:
        if task_type == TaskType.COLUMN_SUMMARY:
            state = process_column_summary(state, llm_client)
        
        elif task_type == TaskType.ROW_SUMMARY:
            state = process_row_summary(state, llm_client)
        
        elif task_type == TaskType.WORKBOOK_SUMMARY:
            state = process_workbook_summary(state, llm_client)
        
        elif task_type in [TaskType.CLASSIFICATION_CONTEXT, TaskType.CLASSIFICATION_UNSUPERVISED, TaskType.CLASSIFICATION_FEW_SHOT]:
            state = process_classification(state, llm_client)
        
        elif task_type == TaskType.DATA_VISUALIZATION:
            state = process_visualization(state)
        
        elif task_type == TaskType.FILTER_QUERY:
            state = process_filter_query(state, llm_client)
        
        else:
            state["error_message"] = f"Unknown task type: {task_type}"
            state["processing_steps"].append(f"process_task_node: FAILED - Unknown task type {task_type}")
    
    except Exception as e:
        state["error_message"] = f"Task processing error: {str(e)}"
        state["processing_steps"].append(f"process_task_node: FAILED - Exception: {str(e)}")
    
    return state

def complete_task_node(state: ExcelWorkflowState) -> ExcelWorkflowState:
    """Complete the current task or mark it as failed."""
    print("---COMPLETING TASK---")
    
    if not state["current_task"]:
        state["processing_steps"].append("complete_task_node: No current task to complete")
        return state
    
    current_task = state["current_task"]
    
    # Check if there was an error
    if state.get("error_message"):
        current_task = update_task_status(
            current_task,
            TaskStatus.FAILED,
            error=state["error_message"]
        )
        state["processing_steps"].append(f"complete_task_node: Marked task as FAILED due to error")
    
    # If the task is still in progress, mark it as completed
    elif current_task["status"] == TaskStatus.IN_PROGRESS:
        current_task = update_task_status(
            current_task,
            TaskStatus.COMPLETED
        )
        state["processing_steps"].append(f"complete_task_node: Marked task as COMPLETED")
    
    # Move the task from current to completed
    state["completed_tasks"].append(current_task)
    state["current_task"] = None
    
    return state

def decide_next_step(state: ExcelWorkflowState) -> str:
    """Decide the next step in the workflow."""
    print("---DECIDING NEXT STEP---")
    
    if state["current_task"]:
        # Still processing a task
        return "process_task"
    
    if state["task_queue"]:
        # More tasks to process
        return "check_queue"
    
    # No current task and no tasks in queue, so we're done
    print("---WORKFLOW COMPLETE---")
    return END

def error_handling_node(state: ExcelWorkflowState) -> ExcelWorkflowState:
    """Handle errors that occur during task processing."""
    print("---ERROR HANDLER---")
    
    error = state.get("error_message", "Unknown error")
    print(f"An error occurred during processing: {error}")
    
    # If there's a current task, mark it as failed
    if state["current_task"]:
        state["current_task"] = update_task_status(
            state["current_task"],
            TaskStatus.FAILED,
            error=error
        )
        state["completed_tasks"].append(state["current_task"])
        state["current_task"] = None
    
    state["processing_steps"].append(f"error_handling_node: Logged - {error}")
    return state

def create_workflow_graph(llm_client: Any) -> StateGraph:
    """Create the workflow graph with all nodes and edges."""
    workflow = StateGraph(ExcelWorkflowState)
    
    # Add nodes
    workflow.add_node("check_queue", check_queue_node)
    workflow.add_node("process_task", lambda state: process_task_node(state, llm_client))
    workflow.add_node("complete_task", complete_task_node)
    workflow.add_node("error_handler", error_handling_node)
    
    # Set the entry point
    workflow.set_entry_point("check_queue")
    
    # Add standard edges
    workflow.add_edge("check_queue", "process_task")
    workflow.add_edge("process_task", "complete_task")
    
    # Add conditional edges to determine the next step
    workflow.add_conditional_edges(
        "complete_task",
        decide_next_step,
        {
            "check_queue": "check_queue",
            "process_task": "process_task",
            END: END
        }
    )
    
    # Handle errors by routing to the error handler
    workflow.add_edge("error_handler", "check_queue")
    
    # Compile the graph
    return workflow.compile() 