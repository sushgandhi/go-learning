# Tasktype.Classification Unsupervised Results

**Task ID**: 2511a5ac-dc2c-402b-8328-cfd21e8b9b14

**Status**: TaskStatus.FAILED

**Input File**: cleaned_salaries.xlsx

**Timestamp**: 2025-05-16 02:56:49


## Error
Task processing error: 'NoneType' object has no attribute 'columns'