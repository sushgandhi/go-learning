# Tasktype.Classification Unsupervised Results

**Task ID**: 160a4501-75a7-47d0-9f71-6da4df3aee27

**Status**: TaskStatus.FAILED

**Input File**: cleaned_salaries.xlsx

**Timestamp**: 2025-05-16 08:52:16


## Error
Task processing error: 'NoneType' object has no attribute 'columns'