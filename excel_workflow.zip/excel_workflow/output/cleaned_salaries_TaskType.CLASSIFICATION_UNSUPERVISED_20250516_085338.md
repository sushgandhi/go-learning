# Tasktype.Classification Unsupervised Results

**Task ID**: f79b6e12-f458-4d9d-92b9-c50723add28a

**Status**: TaskStatus.FAILED

**Input File**: cleaned_salaries.xlsx

**Timestamp**: 2025-05-16 08:53:38


## Error
Task processing error: 'NoneType' object has no attribute 'columns'