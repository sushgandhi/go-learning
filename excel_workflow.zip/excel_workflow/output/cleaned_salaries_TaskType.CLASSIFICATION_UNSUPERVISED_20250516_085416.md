# Tasktype.Classification Unsupervised Results

**Task ID**: fc1c1486-09c6-4ce7-9058-e09e16150314

**Status**: TaskStatus.FAILED

**Input File**: cleaned_salaries.xlsx

**Timestamp**: 2025-05-16 08:54:16


## Error
Task processing error: 'NoneType' object has no attribute 'columns'